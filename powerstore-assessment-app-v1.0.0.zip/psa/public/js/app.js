'use strict';
// PowerStore Assessment front end. Plain JavaScript; all dynamic text goes through textContent
// (never innerHTML), and every URL is relative so the app also works behind a path-based reverse proxy.

const $ = (sel, root = document) => root.querySelector(sel);

function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null) e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return e;
}

const fmtBytes = (b) => {
  if (b == null) return '';
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let v = b;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
};
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString([], { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
const fmtDay = (iso) => (iso ? new Date(iso).toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' }) : '');

let config = { pinRequired: false };
let currentId = null;
const state = { customers: [], customerId: '', q: '', limit: 25, loaded: 0, total: 0 };

async function api(path, opts = {}) {
  const res = await fetch(`api/${path}`, opts);
  let body = null;
  try { body = await res.json(); } catch { /* not JSON */ }
  if (!res.ok) {
    const err = new Error((body && body.error) || `Request failed (${res.status})`);
    err.status = res.status;
    err.pinRequired = !!(body && body.pinRequired);
    throw err;
  }
  return body;
}

// ---- admin PIN (only asked for when the server requires it) --------------------------------------
async function withPin(run) {
  const saved = sessionStorage.getItem('adminPin') || '';
  try {
    return await run(saved);
  } catch (e) {
    if (!e.pinRequired) throw e;
    const pin = window.prompt('Enter the admin PIN:');
    if (pin == null) throw new Error('Cancelled.');
    sessionStorage.setItem('adminPin', pin);
    return run(pin);
  }
}

// ---- header ---------------------------------------------------------------------------------------
function setupHeader() {
  const logo = $('#logo');
  const text = $('#logoText');
  logo.addEventListener('load', () => { logo.hidden = false; text.hidden = true; });
  logo.addEventListener('error', () => { logo.hidden = true; text.hidden = false; });
  logo.src = config.logoUrl || 'img/teknicor-logo.png';
  $('#ver').textContent = `v${config.version}`;
  if (config.portalUrl) { const a = $('#portalLink'); a.href = config.portalUrl; a.hidden = false; }
  $('#footer').textContent = `PowerStore Assessment ${config.version} · collector ${config.collectorVersion} · analyzer ${config.analyzerVersion}`;
}

// ---- step 1: downloads ---------------------------------------------------------------------------
function copyButton(text) {
  const b = h('button', { class: 'btn small', type: 'button', text: 'Copy', 'aria-label': 'Copy command' });
  b.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(text); b.textContent = 'Copied'; } catch { b.textContent = 'Select and copy'; }
    setTimeout(() => { b.textContent = 'Copy'; }, 1500);
  });
  return b;
}

async function loadDownloads() {
  const box = $('#downloads');
  try {
    const items = await api('downloads');
    box.replaceChildren(...items.map((d) => {
      const meta = d.available
        ? `${fmtBytes(d.size)} · collector ${d.version}${d.downloads ? ` · downloaded ${d.downloads}×` : ''}`
        : d.note;
      return h('div', { class: `dl${d.available ? '' : ' off'}` },
        h('h3', { text: d.label }),
        h('div', { class: 'meta', text: d.blurb }),
        h('div', { class: 'meta', text: meta }),
        d.available ? h('div', { class: 'meta' }, 'SHA-256 ', h('code', { text: d.sha256.slice(0, 16) + '…', title: d.sha256 })) : null,
        h('a', { class: 'btn primary', href: d.available ? `download/${d.id}` : null, 'aria-disabled': d.available ? null : 'true', text: d.available ? `Download ${d.filename}` : 'Not available', download: d.available ? d.filename : null }),
        h('div', { class: 'meta', text: 'Run:' }),
        ...d.run.map((line) => h('div', { class: 'cmd' }, h('code', { text: line }), copyButton(line))));
    }));
  } catch (e) {
    box.replaceChildren(h('p', { class: 'status err', text: `Could not load the download list: ${e.message}` }));
  }
}

// ---- step 2: upload ------------------------------------------------------------------------------
let chosen = null;

function updateGenerate() {
  $('#generate').disabled = !(chosen && $('#customer').value.trim());
}

function chooseFile(file) {
  chosen = file || null;
  const drop = $('#drop');
  drop.classList.toggle('has', !!chosen);
  $('#fileLabel').textContent = chosen ? chosen.name : 'Drop the collector output here, or click to choose';
  $('#fileSub').textContent = chosen ? `${fmtBytes(chosen.size)} · ready` : '.json, or the .zip the collector wrote';
  setStatus('');
  updateGenerate();
}

function setStatus(msg, kind = '') {
  const s = $('#status');
  s.textContent = msg;
  s.className = `status ${kind}`;
}

function uploadFile(file, customer, note, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const qs = new URLSearchParams({ customer, filename: file.name, note });
    xhr.open('POST', `api/reports?${qs}`);
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.addEventListener('progress', (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total); });
    xhr.upload.addEventListener('load', () => onProgress(1));
    xhr.addEventListener('load', () => {
      let body = null;
      try { body = JSON.parse(xhr.responseText); } catch { /* not JSON */ }
      if (xhr.status >= 200 && xhr.status < 300 && body) resolve(body);
      else reject(new Error((body && body.error) || `Upload failed (${xhr.status}).`));
    });
    xhr.addEventListener('error', () => reject(new Error('The upload failed. Check the connection to the server and try again.')));
    xhr.send(file);
  });
}

async function onGenerate(ev) {
  ev.preventDefault();
  const customer = $('#customer').value.trim();
  if (!chosen || !customer) return;
  const btn = $('#generate');
  const prog = $('#progress');
  btn.disabled = true;
  prog.hidden = false;
  prog.classList.remove('busy');
  $('#progressBar').style.width = '0';
  setStatus('Uploading…');
  try {
    const out = await uploadFile(chosen, customer, $('#note').value.trim(), (f) => {
      $('#progressBar').style.width = `${Math.round(f * 100)}%`;
      if (f >= 1) { prog.classList.add('busy'); setStatus('Analyzing and building the report…'); }
    });
    const r = out.report;
    const done = out.duplicate ? 'This collector output was already uploaded for this customer; showing the stored report.' : 'Report generated and saved.';
    await openReport(r.id, out.duplicate
      ? `Already stored for ${r.customer} on ${fmtDate(r.created_at)}. Nothing new was saved. Use Regenerate to rebuild it with the current analyzer.`
      : null);
    $('#note').value = '';
    chooseFile(null);
    $('#file').value = '';
    setStatus(done, 'ok');
    await refreshCustomers();
    await loadHistory(true);
  } catch (e) {
    setStatus(e.message, 'err');
  } finally {
    prog.hidden = true;
    prog.classList.remove('busy');
    updateGenerate();
  }
}

function setupUpload() {
  const drop = $('#drop');
  const input = $('#file');
  input.addEventListener('change', () => chooseFile(input.files[0]));
  ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) chooseFile(e.dataTransfer.files[0]); });
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
  $('#customer').addEventListener('input', updateGenerate);
  $('#uploadForm').addEventListener('submit', onGenerate);
}

// ---- report viewer -------------------------------------------------------------------------------
function chip(text) { return h('span', { class: 'chip', text }); }

function badges(r) {
  const b = (n, cls, label) => h('span', { class: `badge ${cls}${n ? '' : ' zero'}`, title: label, text: String(n) });
  return h('span', { class: 'badges' }, b(r.signals_action, 'a', 'Action signals'), b(r.signals_attention, 't', 'Attention signals'), b(r.signals_info, 'i', 'Information signals'));
}

async function openReport(id, notice) {
  currentId = id;
  const r = await api(`reports/${id}`);
  const view = $('#viewer');
  view.hidden = false;
  $('#hv').textContent = `${r.customer}${r.cluster_name ? ` · ${r.cluster_name}` : ''}`;
  $('#viewerMeta').replaceChildren(
    ...[r.model, r.service_tag && `service tag ${r.service_tag}`, r.os_version && `PowerStoreOS ${r.os_version}`, r.collected_at && `collected ${fmtDate(r.collected_at)}`,
      r.collector_version && `collector ${r.collector_version}`, r.analyzer_version && `analyzer ${r.analyzer_version}`, r.note && `note: ${r.note}`].filter(Boolean).map(chip),
    badges(r));
  const base = `api/reports/${id}`;
  $('#frame').src = `${base}/html`;
  const full = $('#vFull'); full.href = `${base}/html`;
  $('#vDownload').href = `${base}/html?download=1`;
  $('#vBundle').href = `${base}/bundle`;
  const n = $('#viewerNote');
  n.hidden = !notice;
  n.textContent = notice || '';
  highlightRow();
  view.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function setupViewer() {
  $('#vClose').addEventListener('click', () => { $('#viewer').hidden = true; $('#frame').removeAttribute('src'); currentId = null; highlightRow(); });
  $('#vRegen').addEventListener('click', () => regenerate(currentId));
}

async function regenerate(id) {
  if (id == null) return;
  try {
    await api(`reports/${id}/regenerate`, { method: 'POST' });
    await openReport(id, 'Report rebuilt from the stored collector output with the current analyzer.');
    await loadHistory(true);
  } catch (e) {
    window.alert(`Could not regenerate: ${e.message}`);
  }
}

async function removeReport(r) {
  if (!window.confirm(`Delete the report and the stored collector output for ${r.customer}${r.cluster_name ? ` (${r.cluster_name})` : ''}, collected ${fmtDate(r.collected_at || r.created_at)}?\n\nThis cannot be undone.`)) return;
  try {
    await withPin((pin) => api(`reports/${r.id}`, { method: 'DELETE', headers: { 'X-Admin-Pin': pin } }));
    if (currentId === r.id) $('#vClose').click();
    await refreshCustomers();
    await loadHistory(true);
  } catch (e) {
    window.alert(`Could not delete: ${e.message}`);
  }
}

// ---- history -------------------------------------------------------------------------------------
function highlightRow() {
  document.querySelectorAll('#historyBody tbody tr').forEach((tr) => tr.classList.toggle('cur', Number(tr.dataset.id) === currentId));
}

function link(text, onclick, cls = '') { return h('button', { class: `link ${cls}`, type: 'button', onclick, text }); }

function historyRow(r) {
  return h('tr', { 'data-id': r.id },
    h('td', { text: fmtDate(r.created_at) }),
    h('td', { text: r.customer }),
    h('td', { text: r.cluster_name || '' }),
    h('td', { text: r.model || '' }),
    h('td', { text: r.os_version || '' }),
    h('td', { text: fmtDay(r.collected_at) }),
    h('td', {}, badges(r)),
    h('td', { text: r.original_filename || '', title: r.note || '' }),
    h('td', {}, h('div', { class: 'rowact' },
      link('View', () => openReport(r.id)),
      h('a', { class: 'link', href: `api/reports/${r.id}/html?download=1`, text: 'Report' }),
      h('a', { class: 'link', href: `api/reports/${r.id}/bundle`, text: 'Collector output' }),
      link('Regenerate', () => regenerate(r.id)),
      link('Delete', () => removeReport(r), 'danger'))));
}

async function loadHistory(reset) {
  const body = $('#historyBody');
  if (reset) state.loaded = 0;
  const qs = new URLSearchParams({ limit: String(state.limit), offset: String(state.loaded) });
  if (state.customerId) qs.set('customer_id', state.customerId);
  if (state.q) qs.set('q', state.q);
  try {
    const { total, rows } = await api(`reports?${qs}`);
    state.total = total;
    if (reset || !body.firstChild || !body.querySelector('tbody')) {
      if (!rows.length) {
        body.replaceChildren(h('p', { class: 'empty', text: total === 0 && !state.q && !state.customerId ? 'No reports yet. Upload a collector output above to create the first one.' : 'No reports match.' }));
      } else {
        body.replaceChildren(h('div', { class: 'tw' }, h('table', {},
          h('thead', {}, h('tr', {}, ['Uploaded', 'Customer', 'Cluster', 'Model', 'PowerStoreOS', 'Collected', 'Signals', 'File', ''].map((t) => h('th', { text: t })))),
          h('tbody', {}, rows.map(historyRow)))));
      }
    } else {
      body.querySelector('tbody').append(...rows.map(historyRow));
    }
    state.loaded += rows.length;
    $('#more').hidden = state.loaded >= total;
    $('#historyCount').textContent = total ? `Showing ${state.loaded} of ${total}` : '';
    highlightRow();
  } catch (e) {
    body.replaceChildren(h('p', { class: 'status err', text: `Could not load reports: ${e.message}` }));
  }
}

async function refreshCustomers() {
  state.customers = await api('customers');
  $('#customerList').replaceChildren(...state.customers.map((c) => h('option', { value: c.name })));
  const sel = $('#fCustomer');
  const keep = state.customerId;
  sel.replaceChildren(h('option', { value: '', text: 'All customers' }), ...state.customers.map((c) => h('option', { value: String(c.id), text: `${c.name} (${c.reports})` })));
  sel.value = state.customers.some((c) => String(c.id) === keep) ? keep : '';
  state.customerId = sel.value;
  $('#fRename').hidden = !state.customerId;
}

function setupHistory() {
  $('#fCustomer').addEventListener('change', (e) => { state.customerId = e.target.value; $('#fRename').hidden = !state.customerId; loadHistory(true); });
  let timer;
  $('#fSearch').addEventListener('input', (e) => { clearTimeout(timer); timer = setTimeout(() => { state.q = e.target.value.trim(); loadHistory(true); }, 250); });
  $('#more').addEventListener('click', () => loadHistory(false));
  $('#fRename').addEventListener('click', async () => {
    const c = state.customers.find((x) => String(x.id) === state.customerId);
    if (!c) return;
    const name = window.prompt(`Rename customer "${c.name}" to:`, c.name);
    if (!name || name.trim() === c.name) return;
    try {
      await withPin((pin) => api(`customers/${c.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'X-Admin-Pin': pin }, body: JSON.stringify({ name }) }));
      await refreshCustomers();
      await loadHistory(true);
      if (currentId != null) await openReport(currentId, 'Customer renamed. Use Regenerate to show the new name in the report header.');
    } catch (e) {
      window.alert(`Could not rename: ${e.message}`);
    }
  });
}

// ---- start ---------------------------------------------------------------------------------------
async function init() {
  try { config = await api('config'); } catch { /* keep defaults */ }
  setupHeader();
  setupUpload();
  setupViewer();
  setupHistory();
  await Promise.all([loadDownloads(), refreshCustomers().catch(() => {})]);
  await loadHistory(true);
}

init();

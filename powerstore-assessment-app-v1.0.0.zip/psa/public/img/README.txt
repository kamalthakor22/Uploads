Put the Teknicor logo here as teknicor-logo.png (copy it from the public/img folder of QuoteDelta or Quote Summary).
Until it exists, the blue bar shows the word TEKNICOR instead. To use a URL instead, set LOGO_URL in .env.

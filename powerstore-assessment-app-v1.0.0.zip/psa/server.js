'use strict';
const os = require('node:os');
const { loadConfig } = require('./src/config');
const { openDb } = require('./src/db');
const { createApp } = require('./src/app');

const cfg = loadConfig(__dirname);
const db = openDb(cfg.dbPath);
const app = createApp(cfg, db);
const server = app.listen(cfg.port, '0.0.0.0', () => {
  console.log(`PowerStore Assessment ${cfg.version} (collector ${cfg.collectorVersion})`);
  console.log(`  database:  ${cfg.dbPath}`);
  console.log(`  downloads: ${cfg.downloadsDir}`);
  console.log(`  open:      http://localhost:${cfg.port}   or   http://${os.hostname()}:${cfg.port}`);
});
const stop = () => { server.close(() => { db.close(); process.exit(0); }); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

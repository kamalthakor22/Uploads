'use strict';
// Downloads the Teknicor logo into public/img/teknicor-logo.png from a URL you give it
// (run on a machine with internet access, then copy the file if the server has none):
//   npm run fetch-logo -- https://www.teknicor.com/path/to/logo.png
const fs = require('node:fs');
const path = require('node:path');

(async () => {
  const url = process.argv[2];
  if (!url) { console.error('Usage: npm run fetch-logo -- <logo-image-url>'); process.exit(2); }
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok) { console.error(`Download failed: HTTP ${res.status}`); process.exit(1); }
  const type = res.headers.get('content-type') || '';
  if (!/^image\//.test(type)) { console.error(`That URL returned ${type || 'an unknown type'}, not an image.`); process.exit(1); }
  const out = path.join(__dirname, '..', 'public', 'img', 'teknicor-logo.png');
  fs.writeFileSync(out, Buffer.from(await res.arrayBuffer()));
  console.log(`Saved ${out} (${type}). Reload the page.`);
})().catch((e) => { console.error(e.message); process.exit(1); });

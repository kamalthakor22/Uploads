'use strict';
// SQLite storage (built-in node:sqlite). One row per uploaded collector output, per customer:
// the collector output itself (gzip) and the generated report (gzip) live in the same row.
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS customers (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
  created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id        INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  created_at         TEXT NOT NULL,
  note               TEXT,
  original_filename  TEXT,
  upload_bytes       INTEGER,
  bundle_sha256      TEXT NOT NULL,
  collector_version  TEXT,
  bundle_schema      TEXT,
  collected_at       TEXT,
  cluster_name       TEXT,
  model              TEXT,
  service_tag        TEXT,
  os_version         TEXT,
  signals_action     INTEGER NOT NULL DEFAULT 0,
  signals_attention  INTEGER NOT NULL DEFAULT 0,
  signals_info       INTEGER NOT NULL DEFAULT 0,
  analyzer_version   TEXT,
  report_generated_at TEXT,
  bundle_gz          BLOB NOT NULL,
  report_gz          BLOB NOT NULL,
  UNIQUE (customer_id, bundle_sha256)
);
CREATE INDEX IF NOT EXISTS idx_reports_customer ON reports(customer_id, created_at DESC);
CREATE TABLE IF NOT EXISTS download_log (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  file  TEXT NOT NULL,
  at    TEXT NOT NULL
);
`;

const META_COLUMNS = `r.id, r.customer_id, c.name AS customer, r.created_at, r.note, r.original_filename, r.upload_bytes, r.bundle_sha256,
  r.collector_version, r.bundle_schema, r.collected_at, r.cluster_name, r.model, r.service_tag, r.os_version,
  r.signals_action, r.signals_attention, r.signals_info, r.analyzer_version, r.report_generated_at,
  length(r.bundle_gz) AS bundle_stored_bytes, length(r.report_gz) AS report_stored_bytes`;

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  const s = (sql) => db.prepare(sql);
  const now = () => new Date().toISOString();
  const tx = (fn) => {
    db.exec('BEGIN');
    try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
  };

  const q = {
    customerByName: s('SELECT id, name, created_at FROM customers WHERE name = ?'),
    customerById: s('SELECT id, name, created_at FROM customers WHERE id = ?'),
    insertCustomer: s('INSERT INTO customers (name, created_at) VALUES (?, ?)'),
    renameCustomer: s('UPDATE customers SET name = ? WHERE id = ?'),
    customers: s(`SELECT c.id, c.name, c.created_at, COUNT(r.id) AS reports, MAX(r.created_at) AS last_upload
                  FROM customers c LEFT JOIN reports r ON r.customer_id = c.id GROUP BY c.id ORDER BY c.name COLLATE NOCASE`),
    reportByHash: s(`SELECT ${META_COLUMNS} FROM reports r JOIN customers c ON c.id = r.customer_id WHERE r.customer_id = ? AND r.bundle_sha256 = ?`),
    reportMeta: s(`SELECT ${META_COLUMNS} FROM reports r JOIN customers c ON c.id = r.customer_id WHERE r.id = ?`),
    insertReport: s(`INSERT INTO reports (customer_id, created_at, note, original_filename, upload_bytes, bundle_sha256, collector_version, bundle_schema, collected_at,
                       cluster_name, model, service_tag, os_version, signals_action, signals_attention, signals_info, analyzer_version, report_generated_at, bundle_gz, report_gz)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`),
    blob: (col) => s(`SELECT ${col} AS data FROM reports WHERE id = ?`),
    updateReport: s('UPDATE reports SET report_gz = ?, analyzer_version = ?, report_generated_at = ?, signals_action = ?, signals_attention = ?, signals_info = ? WHERE id = ?'),
    deleteReport: s('DELETE FROM reports WHERE id = ?'),
    logDownload: s('INSERT INTO download_log (file, at) VALUES (?, ?)'),
    downloadStats: s('SELECT file, COUNT(*) AS n, MAX(at) AS last FROM download_log GROUP BY file'),
  };

  return {
    raw: db,
    close: () => db.close(),
    tx,
    getCustomerByName: (name) => q.customerByName.get(name),
    getCustomer: (id) => q.customerById.get(id),
    /** Case-insensitive get-or-create; returns {id, name, created: boolean}. */
    ensureCustomer(name) {
      const found = q.customerByName.get(name);
      if (found) return { ...found, created: false };
      const r = q.insertCustomer.run(name, now());
      return { id: Number(r.lastInsertRowid), name, created: true };
    },
    renameCustomer: (id, name) => q.renameCustomer.run(name, id),
    listCustomers: () => q.customers.all(),
    findReportByHash: (customerId, sha) => q.reportByHash.get(customerId, sha),
    getReport: (id) => q.reportMeta.get(id),
    insertReport(r) {
      const res = q.insertReport.run(r.customer_id, now(), r.note || null, r.original_filename || null, r.upload_bytes ?? null, r.bundle_sha256, r.collector_version || null,
        r.bundle_schema || null, r.collected_at || null, r.cluster_name || null, r.model || null, r.service_tag || null, r.os_version || null, r.signals_action, r.signals_attention,
        r.signals_info, r.analyzer_version, now(), r.bundle_gz, r.report_gz);
      return Number(res.lastInsertRowid);
    },
    getBlob(id, col) {
      if (col !== 'bundle_gz' && col !== 'report_gz') throw new Error('bad column');
      const row = q.blob(col).get(id);
      return row ? Buffer.from(row.data) : null;
    },
    updateReport: (id, r) => q.updateReport.run(r.report_gz, r.analyzer_version, now(), r.signals_action, r.signals_attention, r.signals_info, id),
    deleteReport: (id) => q.deleteReport.run(id),
    /** filters: customerId, q (matches customer, cluster, tag, filename, note), limit, offset */
    listReports({ customerId, q: text, limit = 50, offset = 0 } = {}) {
      const where = [];
      const args = [];
      if (customerId) { where.push('r.customer_id = ?'); args.push(customerId); }
      if (text) {
        const like = `%${String(text).replace(/[%_\\]/g, (m) => '\\' + m)}%`;
        where.push("(c.name LIKE ? ESCAPE '\\' OR r.cluster_name LIKE ? ESCAPE '\\' OR r.service_tag LIKE ? ESCAPE '\\' OR r.original_filename LIKE ? ESCAPE '\\' OR r.note LIKE ? ESCAPE '\\')");
        args.push(like, like, like, like, like);
      }
      const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
      const total = db.prepare(`SELECT COUNT(*) AS n FROM reports r JOIN customers c ON c.id = r.customer_id ${w}`).get(...args).n;
      const rows = db.prepare(`SELECT ${META_COLUMNS} FROM reports r JOIN customers c ON c.id = r.customer_id ${w} ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset);
      return { total, rows };
    },
    logDownload: (file) => q.logDownload.run(file, now()),
    downloadStats: () => Object.fromEntries(q.downloadStats.all().map((r) => [r.file, { count: r.n, last: r.last }])),
  };
}

module.exports = { openDb };

'use strict';
// Settings from environment variables, with an optional .env file (no dotenv dependency).
const fs = require('node:fs');
const path = require('node:path');

function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

function loadConfig(root = path.join(__dirname, '..'), env = process.env) {
  loadEnvFile(path.join(root, '.env'));
  const abs = (p, dflt) => path.resolve(root, p || dflt);
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  let collectorVersion = 'unknown';
  try { collectorVersion = JSON.parse(fs.readFileSync(path.join(root, 'collector', 'package.json'), 'utf8')).version; } catch { /* optional */ }
  return {
    root,
    version: pkg.version,
    collectorVersion,
    port: Number(env.PORT) || 3015,
    dbPath: abs(env.DB_PATH, './data/assessments.sqlite'),
    downloadsDir: abs(env.DOWNLOADS_DIR, './downloads'),
    collectorDir: path.join(root, 'collector'),
    publicDir: path.join(root, 'public'),
    maxUploadBytes: (Number(env.MAX_UPLOAD_MB) || 200) * 1024 * 1024,
    adminPin: env.ADMIN_PIN || '',
    logoUrl: env.LOGO_URL || '',
    portalUrl: env.PORTAL_URL || '',
  };
}

module.exports = { loadConfig, loadEnvFile };

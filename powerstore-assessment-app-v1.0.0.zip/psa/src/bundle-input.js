'use strict';
// Turns an uploaded file (collector JSON, a .zip made by the collector or by Windows
// "Send to compressed folder", or a .gz) into the bundle's JSON text.
const zlib = require('node:zlib');

class InputError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}

const SIG_EOCD = 0x06054b50;
const SIG_CEN = 0x02014b50;
const SIG_LOC = 0x04034b50;

/** Extract the first .json entry of a ZIP (stored or deflate; no zip64, no encryption). */
function unzipFirstJson(buf, maxBytes) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) {
    if (buf.readUInt32LE(i) === SIG_EOCD) { eocd = i; break; }
  }
  if (eocd < 0) throw new InputError('This looks like a damaged ZIP file (no directory found).');
  const entries = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  if (entries === 0xffff || p === 0xffffffff) throw new InputError('ZIP64 archives are not supported; upload the .json file instead.');
  for (let n = 0; n < entries; n++) {
    if (buf.readUInt32LE(p) !== SIG_CEN) throw new InputError('This looks like a damaged ZIP file (bad directory entry).');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOff = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;
    if (!/\.json$/i.test(name) || /\/$/.test(name) || /^__MACOSX\//.test(name)) continue;
    if (flags & 1) throw new InputError('Password-protected ZIP files are not supported.');
    if (buf.readUInt32LE(localOff) !== SIG_LOC) throw new InputError('This looks like a damaged ZIP file (bad file header).');
    const start = localOff + 30 + buf.readUInt16LE(localOff + 26) + buf.readUInt16LE(localOff + 28);
    const data = buf.subarray(start, start + compSize);
    try {
      if (method === 0) return data;
      if (method === 8) return zlib.inflateRawSync(data, { maxOutputLength: maxBytes });
    } catch (e) {
      if (e.code === 'ERR_BUFFER_TOO_LARGE') throw new InputError('The collector output is too large once unzipped.', 413);
      throw new InputError('Could not unzip the file (it may be damaged).');
    }
    throw new InputError(`Unsupported ZIP compression method ${method}; upload the .json file instead.`);
  }
  throw new InputError('The ZIP file does not contain a .json file. Upload the collector output (.json or the .zip it wrote).');
}

/** @returns {string} the bundle JSON text */
function decodeUpload(buf, { maxBytes = 400 * 1024 * 1024 } = {}) {
  if (!buf || buf.length === 0) throw new InputError('The uploaded file is empty.');
  let raw = buf;
  if (buf.length > 4 && buf.readUInt32LE(0) === SIG_LOC) raw = unzipFirstJson(buf, maxBytes);
  else if (buf[0] === 0x1f && buf[1] === 0x8b) {
    try { raw = zlib.gunzipSync(buf, { maxOutputLength: maxBytes }); } catch (e) {
      throw new InputError(e.code === 'ERR_BUFFER_TOO_LARGE' ? 'The collector output is too large once decompressed.' : 'Could not decompress the .gz file.', e.code === 'ERR_BUFFER_TOO_LARGE' ? 413 : 400);
    }
  }
  let text = raw.toString('utf8');
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1); // UTF-8 BOM (Windows editors)
  if (!/^\s*\{/.test(text)) throw new InputError('That file is not collector output. Upload the .json (or .zip) that pstore-assess wrote to its out folder.');
  return text;
}

module.exports = { decodeUpload, unzipFirstJson, InputError };

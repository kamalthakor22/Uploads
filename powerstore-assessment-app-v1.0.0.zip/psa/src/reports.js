'use strict';
// Bundle text -> analyzed model -> HTML report + the summary stored in the database.
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { parseBundle } = require('../analyzer/normalize');
const { buildModel } = require('../analyzer/model');
const { evaluate } = require('../analyzer/rules');
const { render } = require('../analyzer/report');
const { ANALYZER_VERSION } = require('../analyzer/version');
const { InputError } = require('./bundle-input');

const sha256 = (text) => crypto.createHash('sha256').update(text, 'utf8').digest('hex');
const gz = (textOrBuf) => zlib.gzipSync(Buffer.isBuffer(textOrBuf) ? textOrBuf : Buffer.from(textOrBuf, 'utf8'), { level: 6 });
const gunzipText = (buf) => zlib.gunzipSync(buf).toString('utf8');

/** Validate and analyze; throws InputError for anything the user can fix. */
function analyzeBundle(text, customer) {
  let parsed;
  try {
    parsed = parseBundle(text);
  } catch (e) {
    if (e instanceof SyntaxError) throw new InputError('The file is not valid JSON (it may be cut off or edited). Upload the collector output unchanged.');
    throw new InputError(e.message.includes('vendor') ? `${e.message}. This tool only reads PowerStore collector output.` : `This is not collector output: ${e.message}.`);
  }
  const { bundle, unsafeInts } = parsed;
  if (!/^[12]-/.test(String(bundle.schema_version || ''))) {
    throw new InputError(`Unsupported collector output version "${bundle.schema_version}". Download the current collector from this page and collect again.`);
  }
  let model;
  let findings;
  let html;
  try {
    model = buildModel(bundle, { unsafeInts });
    model.collection.customer = customer;
    model.collection.analyzerVersion = ANALYZER_VERSION;
    findings = evaluate(model);
    html = render(model, findings);
  } catch (e) {
    throw new InputError(`The file was read but could not be analyzed (${e.message}). Collect again with the current collector, or send the file to the tool owner.`, 422);
  }
  const a0 = model.inventory.appliances[0] || {};
  const count = (sev) => findings.filter((f) => f.severity === sev).length;
  return {
    html,
    summary: {
      cluster_name: model.inventory.cluster ? model.inventory.cluster.name : null,
      model: a0.model || null,
      service_tag: a0.serviceTag || null,
      os_version: (model.collection.detectedOS || []).join(', ') || null,
      collected_at: bundle.started_at || null,
      collector_version: bundle.tool ? bundle.tool.version : null,
      bundle_schema: bundle.schema_version,
      signals_action: count('action'),
      signals_attention: count('attention'),
      signals_info: count('info'),
      analyzer_version: ANALYZER_VERSION,
    },
  };
}

module.exports = { analyzeBundle, sha256, gz, gunzipText, ANALYZER_VERSION };

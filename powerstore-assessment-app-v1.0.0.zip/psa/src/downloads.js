'use strict';
// The collector files offered on the page. Binaries are files in DOWNLOADS_DIR; the Node source zip is
// built from the collector/ folder on first request.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { zipFiles } = require('./zipmulti');

const CATALOG = [
  {
    id: 'windows', label: 'Windows (64-bit)', file: 'pstore-assess-win-x64.exe', kind: 'binary',
    blurb: 'Single executable, nothing to install.',
    run: ['pstore-assess-win-x64.exe --host <cluster-ip> --user <operator-user> --insecure --zip'],
  },
  {
    id: 'linux', label: 'Linux (64-bit)', file: 'pstore-assess-linux-x64', kind: 'binary',
    blurb: 'Single executable, nothing to install.',
    run: ['chmod +x pstore-assess-linux-x64', './pstore-assess-linux-x64 --host <cluster-ip> --user <operator-user> --insecure --zip'],
  },
  {
    id: 'source', label: 'Node.js source (any OS)', file: 'pstore-assess-collector-source.zip', kind: 'source', generated: true,
    blurb: 'Needs Node.js 22 or newer. No npm install required.',
    run: ['node src/cli.js --host <cluster-ip> --user <operator-user> --insecure --zip'],
  },
];

const README = `PowerStore collector (read-only)

Run:   node src/cli.js --host <cluster-management-ip> --user <operator-user> --insecure --zip
You are asked for the password (hidden). The collector writes pstore-<host>-<time>.json (and .zip) into the out folder.
Upload that file on the assessment page to get the report.

Only GET requests and the metrics query (POST /api/rest/metrics/generate) are ever sent; see "node src/cli.js --list-calls".
Use an account with the read-only Operator role. Add --all-resources to read every other collection the array offers
(credentials, certificates, users and similar are never read).
`;

function walk(dir, base = '') {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const rel = path.posix.join(base, ent.name);
    if (ent.isDirectory()) out.push(...walk(path.join(dir, ent.name), rel));
    else out.push(rel);
  }
  return out;
}

function createDownloads(cfg) {
  const hashCache = new Map(); // file -> {key, sha}
  let sourceZip = null;

  function buildSource() {
    if (sourceZip) return sourceZip;
    const entries = [{ name: 'README.txt', data: Buffer.from(README, 'utf8') }];
    for (const rel of ['package.json', ...walk(path.join(cfg.collectorDir, 'src')).map((f) => path.posix.join('src', f))]) {
      const full = path.join(cfg.collectorDir, rel);
      if (fs.existsSync(full)) entries.push({ name: rel, data: fs.readFileSync(full) });
    }
    const data = zipFiles(entries);
    sourceZip = { data, sha: crypto.createHash('sha256').update(data).digest('hex') };
    return sourceZip;
  }

  function sha256File(full, stat) {
    const key = `${stat.size}:${stat.mtimeMs}`;
    const c = hashCache.get(full);
    if (c && c.key === key) return c.sha;
    const h = crypto.createHash('sha256');
    h.update(fs.readFileSync(full));
    const sha = h.digest('hex');
    hashCache.set(full, { key, sha });
    return sha;
  }

  function describe(item) {
    const base = { id: item.id, label: item.label, filename: item.file, kind: item.kind, blurb: item.blurb, run: item.run, version: cfg.collectorVersion };
    if (item.generated) {
      let hasSrc = false;
      try { hasSrc = fs.existsSync(path.join(cfg.collectorDir, 'src', 'cli.js')); } catch { /* none */ }
      if (!hasSrc) return { ...base, available: false, note: 'The collector source folder is missing from this installation.' };
      const z = buildSource();
      return { ...base, available: true, size: z.data.length, sha256: z.sha };
    }
    const full = path.join(cfg.downloadsDir, item.file);
    let stat;
    try { stat = fs.statSync(full); } catch { stat = null; }
    if (!stat || !stat.isFile()) return { ...base, available: false, note: `Not installed yet: copy ${item.file} into the downloads folder (run "npm run build" in the collector project to create it).` };
    return { ...base, available: true, size: stat.size, sha256: sha256File(full, stat) };
  }

  return {
    list: () => CATALOG.map(describe),
    /** @returns {{filename, stream?: string, data?: Buffer, size: number} | null} */
    resolve(id) {
      const item = CATALOG.find((c) => c.id === id);
      if (!item) return null;
      const d = describe(item);
      if (!d.available) return { unavailable: d.note };
      if (item.generated) return { filename: item.file, data: buildSource().data, size: d.size };
      return { filename: item.file, path: path.join(cfg.downloadsDir, item.file), size: d.size };
    },
  };
}

module.exports = { createDownloads, CATALOG };

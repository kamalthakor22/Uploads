'use strict';
const crypto = require('node:crypto');
const express = require('express');
const { decodeUpload, InputError } = require('./bundle-input');
const { analyzeBundle, sha256, gz, gunzipText, ANALYZER_VERSION } = require('./reports');
const { createDownloads } = require('./downloads');

const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const slug = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'x';
const intParam = (v) => (/^\d+$/.test(String(v)) ? Number(v) : null);

function createApp(cfg, db) {
  const app = express();
  const downloads = createDownloads(cfg);
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    next();
  });

  // ---- admin PIN (only when ADMIN_PIN is set) ----------------------------------------------------
  function requirePin(req, res, next) {
    if (!cfg.adminPin) return next();
    const given = Buffer.from(String(req.get('x-admin-pin') || ''));
    const want = Buffer.from(cfg.adminPin);
    if (given.length === want.length && crypto.timingSafeEqual(given, want)) return next();
    return res.status(401).json({ error: 'The admin PIN is required for this action.', pinRequired: true });
  }

  const reportOr404 = (req, res) => {
    const id = intParam(req.params.id);
    const meta = id == null ? null : db.getReport(id);
    if (!meta) { res.status(404).json({ error: 'Report not found.' }); return null; }
    return meta;
  };
  const fileBase = (m) => `teknicor-powerstore-assessment_${slug(m.customer)}_${slug(m.cluster_name || 'cluster')}_${String(m.collected_at || m.created_at).slice(0, 10)}`;

  // ---- configuration the page needs --------------------------------------------------------------
  app.get('/api/config', (req, res) => {
    res.json({
      version: cfg.version, collectorVersion: cfg.collectorVersion, analyzerVersion: ANALYZER_VERSION,
      logoUrl: cfg.logoUrl || '', portalUrl: cfg.portalUrl || '', pinRequired: !!cfg.adminPin, maxUploadMb: Math.round(cfg.maxUploadBytes / 1048576),
    });
  });

  // ---- collector downloads -----------------------------------------------------------------------
  app.get('/api/downloads', (req, res) => {
    const stats = db.downloadStats();
    res.json(downloads.list().map((d) => ({ ...d, downloads: (stats[d.filename] || {}).count || 0 })));
  });
  app.get('/download/:id', (req, res, next) => {
    const f = downloads.resolve(req.params.id);
    if (!f) return res.status(404).json({ error: 'Unknown download.' });
    if (f.unavailable) return res.status(404).json({ error: f.unavailable });
    db.logDownload(f.filename);
    res.setHeader('Content-Disposition', `attachment; filename="${f.filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Length', String(f.size));
    if (f.data) return res.end(f.data);
    return res.sendFile(f.path, { headers: { 'Content-Disposition': `attachment; filename="${f.filename}"`, 'Content-Type': 'application/octet-stream' } }, (err) => { if (err) next(err); });
  });

  // ---- customers ---------------------------------------------------------------------------------
  app.get('/api/customers', (req, res) => res.json(db.listCustomers()));
  app.patch('/api/customers/:id', express.json({ limit: '10kb' }), requirePin, (req, res) => {
    const id = intParam(req.params.id);
    const cust = id == null ? null : db.getCustomer(id);
    if (!cust) return res.status(404).json({ error: 'Customer not found.' });
    const name = clean(req.body && req.body.name, 120);
    if (!name) return res.status(400).json({ error: 'Enter a customer name.' });
    const clash = db.getCustomerByName(name);
    if (clash && clash.id !== id) return res.status(409).json({ error: `A customer named "${clash.name}" already exists.` });
    db.renameCustomer(id, name);
    res.json(db.getCustomer(id));
  });

  // ---- upload + generate -------------------------------------------------------------------------
  app.post('/api/reports', express.raw({ type: () => true, limit: cfg.maxUploadBytes }), (req, res) => {
    const name = clean(req.query.customer, 120);
    if (!name) throw new InputError('Enter the customer name before generating the report.');
    const note = clean(req.query.note, 500);
    const filename = clean(req.query.filename, 255);
    const text = decodeUpload(req.body, { maxBytes: Math.max(cfg.maxUploadBytes * 2, 400 * 1024 * 1024) });
    const sha = sha256(text);

    const existing = db.getCustomerByName(name);
    if (existing) {
      const dup = db.findReportByHash(existing.id, sha);
      if (dup) return res.json({ duplicate: true, report: dup });
    }
    const canonical = existing ? existing.name : name;
    const { html, summary } = analyzeBundle(text, canonical);
    const id = db.tx(() => {
      const c = db.ensureCustomer(canonical);
      return db.insertReport({ ...summary, customer_id: c.id, note, original_filename: filename, upload_bytes: req.body.length, bundle_sha256: sha, bundle_gz: gz(text), report_gz: gz(html) });
    });
    res.status(201).json({ duplicate: false, report: db.getReport(id) });
  });

  app.get('/api/reports', (req, res) => {
    const customerId = req.query.customer_id ? intParam(req.query.customer_id) : null;
    const limit = Math.min(200, Math.max(1, intParam(req.query.limit) ?? 50));
    const offset = intParam(req.query.offset) ?? 0;
    res.json(db.listReports({ customerId, q: clean(req.query.q, 100), limit, offset }));
  });
  app.get('/api/reports/:id', (req, res) => { const m = reportOr404(req, res); if (m) res.json(m); });

  app.get('/api/reports/:id/html', (req, res) => {
    const m = reportOr404(req, res);
    if (!m) return;
    const html = gunzipText(db.getBlob(m.id, 'report_gz'));
    // Reports contain no scripts; the policy makes sure of it even if a name in the data tried something.
    res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; img-src data:; frame-ancestors 'self'");
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    if (req.query.download) res.setHeader('Content-Disposition', `attachment; filename="${fileBase(m)}.html"`);
    res.send(html);
  });
  app.get('/api/reports/:id/bundle', (req, res) => {
    const m = reportOr404(req, res);
    if (!m) return;
    const text = gunzipText(db.getBlob(m.id, 'bundle_gz'));
    const base = (m.original_filename || `${fileBase(m)}-collector-output`).replace(/\.(json|zip|gz)$/gi, '');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${base.replace(/[^\w.\- ]+/g, '_')}.json"`);
    res.send(text);
  });

  app.post('/api/reports/:id/regenerate', (req, res) => {
    const m = reportOr404(req, res);
    if (!m) return;
    const { html, summary } = analyzeBundle(gunzipText(db.getBlob(m.id, 'bundle_gz')), m.customer);
    db.updateReport(m.id, { report_gz: gz(html), analyzer_version: summary.analyzer_version, signals_action: summary.signals_action, signals_attention: summary.signals_attention, signals_info: summary.signals_info });
    res.json({ report: db.getReport(m.id) });
  });
  app.delete('/api/reports/:id', requirePin, (req, res) => {
    const m = reportOr404(req, res);
    if (!m) return;
    db.deleteReport(m.id);
    res.json({ deleted: m.id });
  });

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
  app.use(express.static(cfg.publicDir, { index: 'index.html', maxAge: 0 }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status || (err.type === 'entity.too.large' ? 413 : 500);
    if (status >= 500) console.error(err);
    const message = status === 413 ? `The file is larger than the ${Math.round(cfg.maxUploadBytes / 1048576)} MB limit.` : status >= 500 ? 'Something went wrong on the server.' : err.message;
    res.status(status).json({ error: message });
  });
  return app;
}

module.exports = { createApp };

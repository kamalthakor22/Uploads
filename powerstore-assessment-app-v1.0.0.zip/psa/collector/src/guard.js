'use strict';
// Read-only guard. Runs before any network I/O.
// Allowed:  GET  /api/rest/*
//           POST /api/rest/metrics/generate   (query-only: the body selects entity/interval)
// Everything else is refused here and never sent to the array.

class BlockedError extends Error {
  constructor(message) {
    super(message);
    this.name = 'BlockedError';
  }
}

const METRICS_PATH = '/metrics/generate';

// relPath is relative to /api/rest and must start with "/".
function checkAllowed(method, relPath) {
  if (typeof relPath !== 'string' || !relPath.startsWith('/') || relPath.includes('..')) {
    throw new BlockedError(`blocked by read-only guard: bad path ${JSON.stringify(relPath)}`);
  }
  if (method === 'GET') return;
  if (method === 'POST' && relPath === METRICS_PATH) return;
  throw new BlockedError(`blocked by read-only guard: ${method} ${relPath}`);
}

function policy() {
  return [
    'GET  /api/rest/*                (inventory and configuration reads)',
    'POST /api/rest/metrics/generate (metrics query only; body selects entity/interval)',
    'All other methods and paths are refused by the client before any request is sent.',
  ];
}

module.exports = { BlockedError, checkAllowed, policy, METRICS_PATH };

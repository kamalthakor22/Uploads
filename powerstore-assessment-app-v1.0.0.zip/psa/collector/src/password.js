'use strict';
// Read a password without echo using only Node built-ins (raw-mode TTY), so
// the same code works on Windows, Linux and macOS and inside a packaged exe.

function readPassword(prompt, stdin = process.stdin, out = process.stderr) {
  return new Promise((resolve, reject) => {
    out.write(prompt);

    if (!stdin.isTTY || typeof stdin.setRawMode !== 'function') {
      // Piped input: read one line (no echo concern).
      let buf = '';
      stdin.setEncoding('utf8');
      const onData = (d) => {
        buf += d;
        const nl = buf.indexOf('\n');
        if (nl >= 0) {
          cleanup();
          resolve(buf.slice(0, nl).replace(/\r$/, ''));
        }
      };
      const onEnd = () => {
        cleanup();
        buf ? resolve(buf.replace(/\r?\n$/, '')) : reject(new Error('no password provided on stdin'));
      };
      const cleanup = () => {
        stdin.off('data', onData);
        stdin.off('end', onEnd);
        stdin.pause();
      };
      stdin.on('data', onData);
      stdin.on('end', onEnd);
      stdin.resume();
      return;
    }

    let pw = '';
    stdin.setRawMode(true);
    stdin.setEncoding('utf8');
    stdin.resume();
    const done = (fn, v) => {
      stdin.off('data', onData);
      stdin.setRawMode(false);
      stdin.pause();
      out.write('\n');
      fn(v);
    };
    const onData = (chunk) => {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n') return done(resolve, pw);
        if (ch === '\u0003') {
          done(() => {}, null);
          process.exit(130); // Ctrl-C
        }
        if (ch === '\u007f' || ch === '\b') pw = pw.slice(0, -1);
        else if (ch >= ' ') pw += ch;
      }
    };
    stdin.on('data', onData);
  });
}

module.exports = { readPassword };

'use strict';
// Bundle = raw API responses + audit log of every call.
//
// Design rule: response bodies are stored as the exact text the array sent
// (inserted verbatim into the output JSON), so no number is reformatted or
// rounded by JavaScript's float parsing. Normalization happens later, in the
// analyzer, so wrong field mappings can be fixed without re-collecting.

const fs = require('node:fs');
const path = require('node:path');
const { zipSingleFile } = require('./zip');

const SCHEMA_VERSION = '2-draft';

// Returns the response text as valid JSON text. Non-JSON bodies (HTML error
// pages etc.) are stored as a JSON string so the bundle always stays valid.
function rawJsonText(buf) {
  if (!buf || buf.length === 0) return null;
  const text = buf.toString('utf8');
  try {
    JSON.parse(text);
    return text.trim();
  } catch {
    return JSON.stringify(text);
  }
}

class Recorder {
  constructor(tool, vendor, target) {
    this.b = {
      schema_version: SCHEMA_VERSION,
      tool,
      vendor,
      target,
      started_at: new Date().toISOString(),
      finished_at: null,
      detected_os: [],
      warnings: [],
      provisional_notes: [],
      // Per-resource outcome (what was asked for, how many objects came back).
      coverage: [],
      // Optional resources/entities this release does not offer (HTTP 400/404). Not an error.
      unavailable: [],
      // Collections deliberately not collected (sensitive-name denylist or --skip).
      skipped_resources: [],
    };
    this.records = [];
  }
  add(rec) {
    this.records.push({ seq: this.records.length + 1, ...rec });
  }
  warn(msg) { this.b.warnings.push(msg); }
  cover(entry) { this.b.coverage.push(entry); }
  unavail(name, reason) { this.b.unavailable.push({ name, reason }); }
  skipped(list) { this.b.skipped_resources.push(...list); }
  note(msg) { this.b.provisional_notes.push(msg); }
  setDetectedOS(list) { this.b.detected_os = list; }
  finish() {
    this.b.finished_at = new Date().toISOString();
    return { ...this.b, records: this.records };
  }
}

function counts(bundle) {
  let ok = 0;
  let failed = 0;
  for (const r of bundle.records) {
    if (!r.error && r.status >= 200 && r.status < 300) ok++;
    else failed++;
  }
  return { ok, failed };
}

// Serialize with raw bodies spliced in verbatim. One record per line.
function serialize(bundle) {
  const { records, ...head } = bundle;
  const headText = JSON.stringify(head, null, 2);
  const lines = records.map((r) => {
    const { body_raw, ...rest } = r;
    let s = JSON.stringify(rest);
    if (body_raw != null) s = s.slice(0, -1) + ',"body":' + body_raw + '}';
    return '    ' + s;
  });
  const recText = records.length ? '[\n' + lines.join(',\n') + '\n  ]' : '[]';
  return headText.slice(0, -2) + ',\n  "records": ' + recText + '\n}\n';
}

function write(dir, baseName, bundle, asZip) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const text = serialize(bundle);
  const jsonPath = path.join(dir, baseName + '.json');
  writeAtomic(jsonPath, text);
  let zipPath = null;
  if (asZip) {
    zipPath = path.join(dir, baseName + '.zip');
    writeAtomic(zipPath, zipSingleFile(baseName + '.json', Buffer.from(text, 'utf8')));
  }
  return { jsonPath, zipPath };
}

function writeAtomic(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, data, { mode: 0o600 });
  fs.renameSync(tmp, file);
}

module.exports = { SCHEMA_VERSION, Recorder, rawJsonText, counts, serialize, write };

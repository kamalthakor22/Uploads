'use strict';
// Which PowerStore REST collections the collector reads.
//
// Resource names come from Dell's own Go client (gopowerstore) and the Dell
// REST API developer guide examples; field names for each are validated only
// where the README says so. Every non-core resource is OPTIONAL: a 400/404
// (resource not offered on this release) is recorded as "unavailable", not as
// an error, and a 403 is raised as a warning because it may mean the account's
// role cannot read it.

const CORE = ['cluster', 'appliance', 'node', 'hardware'];

// Order matters only for progress output.
const OPTIONAL = [
  'software_installed', 'license', 'limit',
  'volume', 'volume_group', 'storage_container', 'virtual_machine',
  'host', 'host_group', 'initiator', 'host_volume_mapping',
  'policy', 'performance_policy', 'snapshot_rule', 'replication_rule', 'remote_system', 'replication_session',
  'nas_server', 'nfs_server', 'smb_server', 'file_system', 'file_interface', 'nfs_export', 'smb_share',
  'fc_port', 'eth_port',
  'alert',
];

// Cap very large collections so one run stays bounded.
const MAX_ITEMS = { alert: 1000 };

const RESOURCES = [...CORE.map((name) => ({ name, path: '/' + name, core: true })), ...OPTIONAL.map((name) => ({ name, path: '/' + name, core: false, maxItems: MAX_ITEMS[name] }))];

// Extra "probe" reads with nested selects. Nested select syntax is documented
// (e.g. software_installed(id,release_version), volume_groups(name)). Each
// returns a thin projection used to join objects; failure only loses the join.
const PROBES = [
  { name: 'appliance_os', path: '/appliance', select: 'id,name,model,service_tag,software_installed(id,release_version)' },
  { name: 'volume_groups_by_volume', path: '/volume', select: 'id,volume_groups(id,name)' },
  { name: 'host_initiators', path: '/host', select: 'id,name,host_initiators(port_name,port_type)' },
];

// --all-resources discovery never reads collections whose names suggest
// credentials, certificates, user accounts, notification endpoints or support
// access. The skipped names are listed in the bundle (skipped_resources).
const SENSITIVE = /(user|ldap|kerberos|certificate|chap|credential|password|secret|snmp|kmip|smtp|email|syslog|security|ssh|remote_support|vcenter|session|token|key)/i;
// Not useful, or very heavy: internal "view" resources, metrics, docs.
const NOISE = /(_view$|^metrics$|^openapi|^login_session$|^event$|^job$)/i;

function isSensitive(name) { return SENSITIVE.test(name); }
function isNoise(name) { return NOISE.test(name); }

/** Collection names (no path parameters, with GET) from an OpenAPI/Swagger document. */
function collectionsFromSpec(spec) {
  const names = [];
  for (const [p, ops] of Object.entries((spec && spec.paths) || {})) {
    const m = /^\/([a-z][a-z0-9_]*)$/.exec(p);
    if (m && ops && ops.get) names.push(m[1]);
  }
  return [...new Set(names)].sort();
}

module.exports = { RESOURCES, PROBES, CORE, isSensitive, isNoise, collectionsFromSpec };

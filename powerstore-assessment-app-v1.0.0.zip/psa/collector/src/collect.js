'use strict';
// PowerStore collection plan.
//   1. read the curated REST collections (select=*), plus a few nested-select probes
//   2. optionally discover every other readable collection from the array's own
//      OpenAPI document (--all-resources), minus a sensitive-name denylist
//   3. pull metrics (space, performance, wear, file, per-volume) at the retained windows
// The client records every exchange raw; this module only decides WHAT to call.
// Optional resources and entities fail soft: unavailable ones are noted, a 403
// becomes a warning (the account's role may not be allowed to read it).

const { RESOURCES, PROBES, isSensitive, isNoise, collectionsFromSpec } = require('./resources');

const DEFAULT_INTERVALS = ['Five_Mins', 'One_Hour', 'One_Day'];
const DEFAULT_TOP_VOLUMES = 25;

const isUnavailable = (e) => e && (e.status === 400 || e.status === 404);
const isDenied = (e) => e && (e.status === 401 || e.status === 403);

/** Record the outcome of one collection read; returns the items. */
function settle(rec, spec, result, { core }) {
  const { items, incomplete, truncated, error } = result;
  const cov = { resource: spec.name, path: spec.path, select: spec.select || '*', items: items.length };
  if (error) {
    if (!core && isUnavailable(error)) {
      cov.status = 'unavailable';
      rec.unavail(spec.name, error.message);
    } else if (isDenied(error)) {
      cov.status = 'denied';
      rec.warn(`${spec.path}: ${error.message}; the account's role may not be allowed to read this resource`);
    } else {
      cov.status = 'error';
      rec.warn(`${spec.path}: ${error.message}`);
    }
  } else if (truncated && incomplete) {
    cov.status = 'truncated';
    rec.warn(`${spec.path}: stopped at ${spec.maxItems} items (collection is larger)`);
  } else if (incomplete) {
    cov.status = 'partial';
    rec.warn(`${spec.path}: partial content that could not be paged; inventory may be incomplete`);
  } else {
    cov.status = 'ok';
  }
  rec.cover(cov);
  return items;
}

async function readResource(client, rec, spec, core) {
  const res = await client.getAll(spec.path, { select: spec.select || '*' }, { maxItems: spec.maxItems });
  return settle(rec, spec, res, { core });
}

async function readProbe(client, rec, probe) {
  const res = await client.getAll(probe.path, { select: probe.select });
  return settle(rec, { name: probe.name, path: probe.path, select: probe.select }, res, { core: false });
}

function osVersions(probeItems) {
  const seen = new Set();
  for (const a of probeItems) for (const s of (a && a.software_installed) || []) if (s && s.release_version) seen.add(s.release_version);
  return [...seen];
}

const ids = (rows) => rows.filter((r) => r && r.id != null && r.id !== '').map((r) => String(r.id));

// Assumptions still NOT validated on a real array. Validated on 2026-11-05 against a
// PowerStore 500T running 4.4.0.0 (admin account): session + CSRF token, metrics POST,
// cluster/appliance/node/hardware shapes, drives and wear, space and performance fields.
function provisionalNotes(intervals) {
  return [
    'validated only on PowerStoreOS 4.4.0.0 (PowerStore 500T, admin account) and only for cluster, appliance, node, hardware, drives and cluster/appliance/node metrics; other releases are unvalidated.',
    "resources added in v0.3 (volume, volume_group, host, host_group, host_volume_mapping, policy, snapshot_rule, replication_rule, replication_session, remote_system, nas_server, file_system, nfs_export, smb_share, alert, ports, virtual_machine, storage_container, license, limit) use field names from Dell's Go client and docs; the demo array had no such objects, so their live shapes are unvalidated.",
    'file-protocol metrics (performance_metrics_file_by_cluster / _by_appliance) and per-volume metrics (space_metrics_by_volume, performance_metrics_by_volume) are requested but their live responses have not been seen.',
    "nested-select probes (volume_groups(id,name), host_initiators(port_name,port_type)) follow Dell's documented nested-select syntax but are unvalidated for these resources.",
    'Operator role not yet tested: the validation run used the admin account, so access for a read-only role is unconfirmed (a 403 on any resource is raised as a warning).',
    "paging beyond the 100-item default follows Dell's documented limit/offset and the Content-Range format its own client parses, but has not been observed.",
    'expansion enclosures: no expansion-enclosure hardware type was seen (only Link_Control_Card objects named ExpansionEnclosure_*).',
    'io_workload_cpu_utilization unit unconfirmed (Dell docs say percentage; observed values were 0-0.3 on a nearly idle array).',
    `metrics intervals requested: ${intervals.join(', ')}.`,
  ];
}

/**
 * @param {import('./client').Client} client  (already logged in)
 * @param {import('./bundle').Recorder} rec
 * @param {{intervals?:string[], progress?:(m:string)=>void, signal?:AbortSignal, allResources?:boolean,
 *          topVolumes?:number, volumeMetrics?:boolean, skip?:string[]}} [opt]
 */
async function run(client, rec, opt = {}) {
  const intervals = opt.intervals?.length ? opt.intervals : DEFAULT_INTERVALS;
  const topVolumes = opt.topVolumes ?? DEFAULT_TOP_VOLUMES;
  const volumeMetrics = opt.volumeMetrics !== false && topVolumes > 0;
  const skip = new Set((opt.skip || []).map((s) => s.trim()).filter(Boolean));
  const say = opt.progress || (() => {});
  const aborted = () => { if (opt.signal?.aborted) throw new Error('aborted'); };
  provisionalNotes(intervals).forEach((n) => rec.note(n));

  // --- 1. curated collections ------------------------------------------------
  const data = {};
  const skippedNames = [];
  for (const spec of RESOURCES) {
    aborted();
    if (!spec.core && skip.has(spec.name)) { skippedNames.push({ name: spec.name, reason: 'excluded with --skip' }); continue; }
    say(`reading ${spec.name}`);
    data[spec.name] = await readResource(client, rec, spec, spec.core);
  }

  // --- 2. probes (nested selects) and OS version -----------------------------
  const probes = {};
  for (const p of PROBES) {
    aborted();
    if (skip.has(p.name)) continue;
    say(`probing ${p.name}`);
    probes[p.name] = await readProbe(client, rec, p);
  }
  const os = osVersions(probes.appliance_os || []);
  rec.setDetectedOS(os);
  if (os.length === 0) rec.warn('could not detect PowerStoreOS version from appliance software_installed');

  // --- 3. optional discovery of everything else ------------------------------
  if (opt.allResources) {
    say("discovering collections from the array's OpenAPI document");
    const known = new Set([...RESOURCES.map((r) => r.name), 'login_session']);
    let spec = null;
    try {
      const resp = await client.get('/openapi.json', null, { omitBody: true });
      if (resp.status === 200) spec = JSON.parse(resp.body.toString('utf8'));
      else rec.warn(`--all-resources: GET /openapi.json returned HTTP ${resp.status}; extra collections not discovered`);
    } catch (e) {
      rec.warn(`--all-resources: could not read the OpenAPI document (${e.message}); extra collections not discovered`);
    }
    for (const name of collectionsFromSpec(spec)) {
      if (known.has(name) || skip.has(name)) continue;
      if (isSensitive(name)) { skippedNames.push({ name, reason: 'sensitive-name denylist' }); continue; }
      if (isNoise(name)) { skippedNames.push({ name, reason: 'internal or very large resource' }); continue; }
      aborted();
      say(`reading ${name} (discovered)`);
      data[name] = await readResource(client, rec, { name, path: '/' + name, maxItems: 2000 }, false);
    }
  }
  if (skippedNames.length) rec.skipped(skippedNames);

  // --- 4. identifiers for metrics ---------------------------------------------
  const clusterIds = ids(data.cluster || []);
  const applianceIds = ids(data.appliance || []);
  const nodeIds = ids(data.node || []);
  const hardware = data.hardware || [];
  const driveIds = hardware.filter((h) => String(h.type || '').toLowerCase() === 'drive').map((h) => String(h.id));
  if (hardware.length > 0 && driveIds.length === 0) rec.warn(`hardware inventory returned ${hardware.length} objects but none had type "Drive"; per-drive wear metrics skipped`);
  if (clusterIds.length === 0) rec.warn('no clusters discovered; cluster-level metrics skipped');
  if (applianceIds.length === 0) rec.warn('no appliances discovered; appliance-level metrics skipped');

  const hasFile = (data.nas_server || []).length > 0 || (data.file_system || []).length > 0;
  const volumesForMetrics = (data.volume || [])
    .filter((v) => v && v.id && v.type !== 'Snapshot')
    .sort((a, b) => (Number(b.logical_used) || 0) - (Number(a.logical_used) || 0))
    .slice(0, volumeMetrics ? topVolumes : 0);

  // [entity, ids, intervals, optional]
  const jobs = [
    ['space_metrics_by_cluster', clusterIds, intervals, false],
    ['space_metrics_by_appliance', applianceIds, intervals, false],
    ['performance_metrics_by_cluster', clusterIds, intervals, false],
    ['performance_metrics_by_appliance', applianceIds, intervals, false],
    ['performance_metrics_by_node', nodeIds, intervals, false],
    // Drive wear changes slowly; the daily interval is enough.
    ['wear_metrics_by_drive', driveIds, ['One_Day'], false],
  ];
  if (hasFile) {
    jobs.push(['performance_metrics_file_by_cluster', clusterIds, intervals, true]);
    jobs.push(['performance_metrics_file_by_appliance', applianceIds, intervals, true]);
  }
  if (volumesForMetrics.length) {
    const vids = volumesForMetrics.map((v) => String(v.id));
    jobs.push(['space_metrics_by_volume', vids, ['One_Day'], true]);
    jobs.push(['performance_metrics_by_volume', vids, ['One_Day'], true]);
  }

  // --- 5. metrics (sequential on purpose: low, predictable load on the array) --
  const dead = new Set(); // optional entities that proved unavailable: stop asking
  for (const [entity, entityIds, ivs, optional] of jobs) {
    for (const id of entityIds) {
      for (const iv of ivs) {
        aborted();
        if (dead.has(entity)) continue;
        say(`${entity} ${id} ${iv}`);
        try {
          const resp = await client.postMetrics(entity, id, iv);
          if (resp.status >= 200 && resp.status < 300) continue;
          if (optional && (resp.status === 400 || resp.status === 404)) {
            rec.unavail(entity, `HTTP ${resp.status}`);
            dead.add(entity);
          } else {
            rec.warn(`${entity} id=${id} interval=${iv}: HTTP ${resp.status}`);
          }
        } catch (e) {
          rec.warn(`${entity} id=${id} interval=${iv}: ${e.message}`);
        }
      }
    }
  }
}

module.exports = { run, DEFAULT_INTERVALS, DEFAULT_TOP_VOLUMES };

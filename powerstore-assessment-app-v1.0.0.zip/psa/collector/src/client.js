'use strict';
// Minimal PowerStore REST client (Node built-ins only).
//
// Session model (see README "Validation status"):
//   GET /api/rest/login_session with HTTP Basic auth returns a session cookie
//   and a DELL-EMC-TOKEN response header. GETs work with the cookie alone, but
//   POSTs (metrics/generate) are rejected with 403 unless the DELL-EMC-TOKEN
//   header is also sent. This client sends both on every request after login.

const https = require('node:https');
const fs = require('node:fs');
const { checkAllowed, METRICS_PATH } = require('./guard');
const { rawJsonText } = require('./bundle');

const API_PREFIX = '/api/rest';
const TOKEN_HEADER = 'DELL-EMC-TOKEN';
const MAX_BODY_BYTES = 128 * 1024 * 1024;
const MAX_PAGES = 200;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// PowerStore filter syntax ("select=a,b(c)", "type=eq.Primary") needs commas,
// parentheses and dots left literal, so escape only what would break a URL.
function encodeQuery(q) {
  if (!q) return '';
  return Object.keys(q)
    .sort()
    .map((k) => {
      const vals = Array.isArray(q[k]) ? q[k] : [q[k]];
      return vals
        .map((v) => encodeURIComponent(k) + '=' + String(v).replace(/%/g, '%25').replace(/ /g, '%20').replace(/&/g, '%26').replace(/#/g, '%23'))
        .join('&');
    })
    .join('&');
}

class Client {
  /**
   * @param {object} o
   * @param {string} o.host        host or host:port of the cluster management address
   * @param {string} o.user
   * @param {string} o.password
   * @param {boolean} [o.insecure] skip TLS verification (recorded in the bundle)
   * @param {string} [o.caFile]    PEM file to trust
   * @param {number} [o.timeoutMs]
   * @param {number} [o.retryDelayMs]
   * @param {(msg:string)=>void} [o.trace]  method/path/status only; never headers or bodies
   * @param {import('./bundle').Recorder} [o.recorder]
   */
  constructor(o) {
    if (!o.host) throw new Error('host is required');
    this.host = o.host.replace(/^https?:\/\//, '').replace(/\/+$/, '');
    const [hostname, port] = splitHostPort(this.host);
    this.hostname = hostname;
    this.port = port;
    this.user = o.user;
    this.password = o.password;
    this.timeoutMs = o.timeoutMs ?? 60000;
    this.retryDelayMs = o.retryDelayMs ?? 1000;
    this.trace = o.trace;
    this.recorder = o.recorder;
    this.token = '';
    this.cookies = new Map();

    const agentOpts = { keepAlive: true, minVersion: 'TLSv1.2', rejectUnauthorized: !o.insecure };
    if (o.caFile) {
      const pem = fs.readFileSync(o.caFile);
      if (!/-----BEGIN CERTIFICATE-----/.test(pem.toString('utf8'))) {
        throw new Error('CA file contains no usable certificates');
      }
      agentOpts.ca = pem;
    }
    this.agent = new https.Agent(agentOpts);
  }

  close() {
    this.agent.destroy();
  }

  // Opens a session. The login response body is recorded: it normally names the
  // authenticated user and role, which is evidence the run used a read-only account.
  async login() {
    this.token = '';
    this.cookies.clear();
    const resp = await this._send('GET', '/login_session', null, null, { basicAuth: true });
    if (resp.status !== 200) throw new Error(`login failed: HTTP ${resp.status}`);
    this.token = resp.headers['dell-emc-token'] || '';
    if (!this.token) {
      throw new Error(`login succeeded but no ${TOKEN_HEADER} header was returned; POST requests would be rejected`);
    }
  }

  get(relPath, query, opts) {
    return this._do('GET', relPath, query, null, opts);
  }

  postMetrics(entity, entityId, interval) {
    return this._do('POST', METRICS_PATH, null, { entity, entity_id: entityId, interval });
  }

  async _do(method, relPath, query, body, opts = {}) {
    checkAllowed(method, relPath); // throws BlockedError before any I/O
    let resp = await this._attempt(method, relPath, query, body, opts);
    // Session expired mid-run: log in once more and retry once.
    if (resp.status === 401 && relPath !== '/login_session') {
      await this.login();
      resp = await this._attempt(method, relPath, query, body, opts);
    }
    return resp;
  }

  async _attempt(method, relPath, query, body, opts) {
    let lastErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) await sleep(this.retryDelayMs * 2 ** (attempt - 1));
      try {
        const resp = await this._send(method, relPath, query, body, opts);
        if ([502, 503, 504].includes(resp.status)) {
          lastErr = new Error(`HTTP ${resp.status}`);
          continue;
        }
        return resp;
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr;
  }

  _send(method, relPath, query, body, opts = {}) {
    const payload = body == null ? null : JSON.stringify(body);
    const qs = encodeQuery(query);
    const fullPath = API_PREFIX + relPath + (qs ? '?' + qs : '');
    const headers = { Accept: 'application/json' };
    if (payload != null) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(payload);
    }
    if (this.token) headers[TOKEN_HEADER] = this.token;
    if (this.cookies.size) headers.Cookie = [...this.cookies].map(([k, v]) => `${k}=${v}`).join('; ');
    if (opts.basicAuth) {
      headers.Authorization = 'Basic ' + Buffer.from(`${this.user}:${this.password}`).toString('base64');
    }

    const started = Date.now();
    const rec = {
      method,
      path: relPath,
      ...(qs ? { query: qs } : {}),
      ...(payload != null ? { request_body: JSON.parse(payload) } : {}),
      fetched_at: new Date(started).toISOString(),
    };

    return new Promise((resolve, reject) => {
      const finishErr = (err) => {
        rec.status = 0;
        rec.duration_ms = Date.now() - started;
        rec.error = err.message;
        this._record(rec);
        this._trace(`${method} ${API_PREFIX}${relPath} -> error: ${err.message}`);
        reject(err);
      };
      const req = https.request(
        { hostname: this.hostname, port: this.port, path: fullPath, method, headers, agent: this.agent },
        (res) => {
          const chunks = [];
          let size = 0;
          res.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY_BYTES) {
              req.destroy(new Error(`response exceeds ${MAX_BODY_BYTES} bytes`));
              return;
            }
            chunks.push(c);
          });
          res.on('error', finishErr);
          res.on('end', () => {
            const data = Buffer.concat(chunks);
            this._storeCookies(res.headers['set-cookie']);
            rec.status = res.statusCode;
            rec.duration_ms = Date.now() - started;
            if (res.headers['content-range']) rec.content_range = res.headers['content-range'];
            if (opts.omitBody) rec.body_omitted_bytes = data.length; // e.g. the OpenAPI document
            else {
              const raw = rawJsonText(data);
              if (raw != null) rec.body_raw = raw;
            }
            this._record(rec);
            this._trace(`${method} ${API_PREFIX}${relPath} -> ${res.statusCode} (${rec.duration_ms} ms, ${data.length} bytes)`);
            resolve({ status: res.statusCode, headers: res.headers, body: data, contentRange: res.headers['content-range'] || '' });
          });
        },
      );
      req.setTimeout(this.timeoutMs, () => req.destroy(new Error(`timeout after ${this.timeoutMs} ms`)));
      req.on('error', finishErr);
      if (payload != null) req.write(payload);
      req.end();
    });
  }

  _storeCookies(setCookie) {
    if (!setCookie) return;
    for (const line of setCookie) {
      const pair = line.split(';', 1)[0];
      const eq = pair.indexOf('=');
      if (eq > 0) this.cookies.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
    }
  }

  _record(rec) {
    if (this.recorder) this.recorder.add(rec);
  }

  _trace(msg) {
    if (this.trace) this.trace(`[trace] ${msg}`);
  }

  /**
   * Fetch a whole collection, following partial-content (206) responses.
   *
   * Dell's REST guide documents: default page size 100, `limit` 1-2000 and
   * `offset` URL parameters, and a 206 response with a Content-Range header
   * ("first-last/total", the same format Dell's own Go client parses). We
   * request limit=2000 up front. Paging itself has not been observed on a real
   * array yet (the 4.4.0.0 test array had fewer than 100 objects per
   * collection). If the header can't be parsed, the first page is returned
   * with incomplete=true so the caller warns instead of silently
   * under-collecting.
   * @returns {Promise<{items: any[], incomplete: boolean, error?: Error}>}
   */
  async getAll(relPath, query = {}, { maxItems = Infinity, omitBody = false } = {}) {
    const items = [];
    let offset = 0;
    const fail = (message, status) => ({ items, incomplete: true, error: Object.assign(new Error(message), { status }) });
    for (let page = 0; page < MAX_PAGES; page++) {
      const q = { limit: '2000', ...query };
      if (offset > 0) q.offset = String(offset);
      let resp;
      try {
        resp = await this.get(relPath, q, { omitBody });
      } catch (error) {
        return { items, incomplete: true, error };
      }
      if (resp.status !== 200 && resp.status !== 206) return fail(`GET ${relPath}: HTTP ${resp.status}`, resp.status);
      let arr;
      try {
        arr = JSON.parse(resp.body.toString('utf8'));
        if (!Array.isArray(arr)) throw new Error('not an array');
      } catch (e) {
        return fail(`GET ${relPath}: body is not a JSON array (${e.message})`, resp.status);
      }
      items.push(...arr);
      if (items.length >= maxItems) return { items: items.slice(0, maxItems), incomplete: resp.status === 206 || items.length > maxItems, truncated: true };
      if (resp.status === 200) return { items, incomplete: false };
      const m = /(\d+)-(\d+)\/(\d+)/.exec(resp.contentRange);
      if (!m) return { items, incomplete: true };
      const last = Number(m[2]);
      const total = Number(m[3]);
      if (last + 1 >= total || arr.length === 0) return { items, incomplete: false };
      offset = last + 1;
    }
    return { items, incomplete: true };
  }
}

function splitHostPort(hostport) {
  const m = /^(\[[^\]]+\]|[^:]+)(?::(\d+))?$/.exec(hostport);
  if (!m) throw new Error(`bad host ${JSON.stringify(hostport)}`);
  return [m[1].replace(/^\[|\]$/g, ''), m[2] ? Number(m[2]) : 443];
}

module.exports = { Client, encodeQuery };

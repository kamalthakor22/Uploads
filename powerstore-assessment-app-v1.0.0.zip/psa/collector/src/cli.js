#!/usr/bin/env node
'use strict';
// pstore-assess: read-only Dell PowerStore collector. Writes one JSON bundle.

const fs = require('node:fs');
const { parseArgs } = require('node:util');
const { Client } = require('./client');
const { Recorder, counts, write } = require('./bundle');
const { run: collect } = require('./collect');
const { readPassword } = require('./password');
const { policy } = require('./guard');

const VERSION = '0.3.0-dev';

const HELP = `pstore-assess ${VERSION} - read-only PowerStore data collector

Usage:
  pstore-assess --host <cluster-ip> --user <operator-user> [flags]

Flags:
  --host <addr>           cluster management address (host or host:port)
  --user <name>           PowerStore username (use a read-only role such as Operator)
  --password-file <path>  read the password from a file (env PSTORE_PASSWORD also works; default is a hidden prompt)
  --insecure              do not verify the array's TLS certificate (recorded in the bundle)
  --ca-file <path>        PEM file with the CA certificate(s) to trust
  --out <dir>             output directory (default: out)
  --zip                   also write a .zip of the bundle
  --timeout <seconds>     per-request timeout (default: 60)
  --all-resources         also read every other collection the array's OpenAPI document lists (sensitive-name denylist applies; skipped names are recorded in the bundle)
  --top-volumes <n>       collect per-volume space and performance metrics for the n largest volumes (default: 25; 0 disables)
  --skip <a,b,c>          do not read these optional resources (for example: alert,virtual_machine)
  --trace                 print each request (method, path, status) to stderr; never credentials or bodies
  --list-calls            print the exact request policy this tool enforces, then exit
  --version               print version and exit
`;

function sanitize(s) {
  return s.replace(/[^A-Za-z0-9._-]+/g, '_');
}

function stamp(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}-${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
}

async function getPassword(file) {
  if (file) return fs.readFileSync(file, 'utf8').replace(/\r?\n$/, '');
  if (process.env.PSTORE_PASSWORD) return process.env.PSTORE_PASSWORD;
  const pw = await readPassword('Password: ');
  if (!pw) throw new Error('empty password');
  return pw;
}

async function main(argv) {
  let args;
  try {
    args = parseArgs({
      args: argv,
      options: {
        host: { type: 'string' },
        user: { type: 'string' },
        'password-file': { type: 'string' },
        insecure: { type: 'boolean', default: false },
        'ca-file': { type: 'string' },
        out: { type: 'string', default: 'out' },
        zip: { type: 'boolean', default: false },
        timeout: { type: 'string', default: '60' },
        trace: { type: 'boolean', default: false },
        'all-resources': { type: 'boolean', default: false },
        'top-volumes': { type: 'string', default: '25' },
        skip: { type: 'string', default: '' },
        'list-calls': { type: 'boolean', default: false },
        version: { type: 'boolean', default: false },
        help: { type: 'boolean', short: 'h', default: false },
      },
    }).values;
  } catch (e) {
    console.error(`error: ${e.message}\n`);
    console.error(HELP);
    return 2;
  }

  if (args.version) return console.log('pstore-assess', VERSION), 0;
  if (args['list-calls']) return policy().forEach((l) => console.log(l)), 0;
  if (args.help || !args.host || !args.user) {
    console.error(HELP);
    return args.help ? 0 : 2;
  }

  let password;
  try {
    password = await getPassword(args['password-file']);
  } catch (e) {
    console.error('error:', e.message);
    return 2;
  }

  const rec = new Recorder({ name: 'pstore-assess', version: VERSION }, 'dell-powerstore', {
    host: args.host,
    user: args.user,
    tls_verified: !args.insecure,
  });
  let client;
  try {
    client = new Client({
      host: args.host,
      user: args.user,
      password,
      insecure: args.insecure,
      caFile: args['ca-file'],
      timeoutMs: Number(args.timeout) * 1000,
      trace: args.trace ? (m) => console.error(m) : undefined,
      recorder: rec,
    });
  } catch (e) {
    console.error('error:', e.message);
    return 2;
  }
  if (args.insecure) console.error('[warning] TLS verification is disabled (--insecure); this is recorded in the bundle.');

  const ac = new AbortController();
  process.once('SIGINT', () => ac.abort());

  console.error(`Connecting to ${args.host} as ${args.user} ...`);
  try {
    await client.login();
  } catch (e) {
    console.error('error: login:', e.message);
    client.close();
    return 1;
  }

  let runErr;
  try {
    await collect(client, rec, {
      progress: (m) => console.error('  ' + m),
      signal: ac.signal,
      allResources: args['all-resources'],
      topVolumes: Number.isFinite(Number(args['top-volumes'])) ? Number(args['top-volumes']) : 25,
      skip: args.skip.split(','),
    });
  } catch (e) {
    runErr = e;
    rec.warn(`run ended early: ${e.message}`);
  }
  client.close();

  const b = rec.finish();
  const name = `pstore-${sanitize(args.host)}-${stamp(new Date(b.started_at))}`;
  let paths;
  try {
    paths = write(args.out, name, b, args.zip);
  } catch (e) {
    console.error('error writing bundle:', e.message);
    return 1;
  }
  const { ok, failed } = counts(b);
  console.error(`\nDone. ${ok} requests OK, ${failed} failed, ${b.warnings.length} warning(s).`);
  if (b.detected_os.length) console.error(`Detected PowerStoreOS: ${b.detected_os.join(', ')}`);
  const okRes = b.coverage.filter((c) => c.status === 'ok' && !/^(appliance_os|volume_groups_by_volume|host_initiators)$/.test(c.resource));
  console.error(`Resources read: ${okRes.length} (${okRes.reduce((a, c) => a + c.items, 0)} objects); unavailable on this release: ${b.unavailable.length}; skipped: ${b.skipped_resources.length}`);
  b.warnings.forEach((w) => console.error('  warning:', w));
  console.error('Bundle:', paths.jsonPath);
  if (paths.zipPath) console.error('Zip:   ', paths.zipPath);
  console.error('Review the bundle before sending it; it contains hostnames, IPs and object names from the array.');
  return runErr ? 1 : 0;
}

if (require.main === module) {
  main(process.argv.slice(2)).then(
    (code) => { process.exitCode = code; },
    (e) => { console.error('fatal:', e && e.stack ? e.stack : e); process.exitCode = 1; },
  );
}

module.exports = { main };

'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');
const { zipFiles } = require('../src/zipmulti');
const { decodeUpload, unzipFirstJson } = require('../src/bundle-input');

const ROOT = path.join(__dirname, '..');
const MOCK = fs.readFileSync(path.join(__dirname, 'fixtures', 'mock-bundle.json'));
const REAL = fs.readFileSync(path.join(__dirname, 'fixtures', 'bundle-real-sanitized.json'));

async function start(over = {}) {
  const dl = fs.mkdtempSync(path.join(os.tmpdir(), 'psa-dl-'));
  fs.writeFileSync(path.join(dl, 'pstore-assess-win-x64.exe'), 'MZ-fake-exe');
  const cfg = { ...loadConfig(ROOT, {}), dbPath: ':memory:', downloadsDir: dl, maxUploadBytes: 20 * 1024 * 1024, adminPin: '', ...over };
  const db = openDb(':memory:');
  const server = createApp(cfg, db).listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = (customer, body, extra = '') => fetch(`${base}/api/reports?customer=${encodeURIComponent(customer)}&filename=out.json${extra}`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body });
  return { base, db, cfg, post, close: () => new Promise((r) => { server.closeAllConnections(); server.close(() => { db.close(); r(); }); }) };
}

test('upload generates a report, stores it per customer, and serves it back', async (t) => {
  const s = await start(); t.after(s.close);
  const res = await s.post('Acme Corp', MOCK);
  assert.equal(res.status, 201);
  const { report, duplicate } = await res.json();
  assert.equal(duplicate, false);
  assert.equal(report.customer, 'Acme Corp');
  assert.equal(report.model, 'PowerStore 500T');
  assert.equal(report.os_version, '4.4.0.0');
  assert.ok(report.signals_attention >= 1);
  assert.match(report.bundle_sha256, /^[0-9a-f]{64}$/);

  const html = await (await fetch(`${s.base}/api/reports/${report.id}/html`)).text();
  assert.ok(html.includes('PowerStore Assessment'));
  assert.ok(html.includes('Acme Corp'), 'customer name appears in the report header');
  assert.ok(html.includes('<h2>Protection and replication</h2>'));
  const r = await fetch(`${s.base}/api/reports/${report.id}/html`);
  assert.match(r.headers.get('content-security-policy'), /default-src 'none'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');

  const bundle = await fetch(`${s.base}/api/reports/${report.id}/bundle`);
  assert.match(bundle.headers.get('content-disposition'), /attachment; filename="out\.json"/);
  assert.equal(await bundle.text(), MOCK.toString('utf8'), 'collector output is stored and returned verbatim');
});

test('customers are matched ignoring case; same file twice is a duplicate; another customer can reuse it', async (t) => {
  const s = await start(); t.after(s.close);
  const a = await (await s.post('Acme Corp', MOCK)).json();
  const dup = await (await s.post('  acme   CORP ', MOCK)).json();
  assert.equal(dup.duplicate, true);
  assert.equal(dup.report.id, a.report.id);
  const other = await (await s.post('Globex', MOCK)).json();
  assert.equal(other.duplicate, false);
  const customers = await (await fetch(`${s.base}/api/customers`)).json();
  assert.deepEqual(customers.map((c) => [c.name, c.reports]), [['Acme Corp', 1], ['Globex', 1]]);
  // a second, different collection for the same customer
  const second = await (await s.post('acme corp', REAL)).json();
  assert.equal(second.duplicate, false);
  assert.equal(second.report.customer, 'Acme Corp');
  const list = await (await fetch(`${s.base}/api/reports?customer_id=${a.report.customer_id}`)).json();
  assert.equal(list.total, 2);
});

test('zip, gzip and BOM-prefixed uploads all work and dedupe against the plain json', async (t) => {
  const s = await start(); t.after(s.close);
  const plain = await (await s.post('Zed', MOCK)).json();
  const zipped = zipFiles([{ name: 'pstore.json', data: MOCK }]);
  assert.equal((await (await s.post('Zed', zipped)).json()).duplicate, true);
  assert.equal((await (await s.post('Zed', zlib.gzipSync(MOCK))).json()).duplicate, true);
  assert.equal((await (await s.post('Zed', Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), MOCK]))).json()).duplicate, true);
  assert.equal(plain.duplicate, false);
});

test('bad uploads get clear 4xx errors and create nothing', async (t) => {
  const s = await start(); t.after(s.close);
  const cases = [
    ['', Buffer.from('{}'), 400, /customer name/i],
    ['X', Buffer.alloc(0), 400, /empty/i],
    ['X', Buffer.from('hello world'), 400, /not collector output/i],
    ['X', Buffer.from('{"records": [1,2'), 400, /not valid JSON/i],
    ['X', Buffer.from('{"foo":1}'), 400, /not collector output/i],
    ['X', Buffer.from('{"vendor":"netapp","records":[]}'), 400, /PowerStore/i],
    ['X', Buffer.from('{"vendor":"dell-powerstore","schema_version":"9-x","records":[]}'), 400, /version/i],
    ['X', zipFiles([{ name: 'readme.txt', data: Buffer.from('hi') }]), 400, /does not contain a \.json/i],
  ];
  for (const [customer, body, status, re] of cases) {
    const res = await s.post(customer, body);
    assert.equal(res.status, status, `${customer}/${body.length}`);
    assert.match((await res.json()).error, re);
  }
  assert.equal((await (await fetch(`${s.base}/api/customers`)).json()).length, 0, 'failed uploads must not create customers');
  const big = await start({ maxUploadBytes: 1000 }); t.after(big.close);
  const res = await big.post('X', MOCK);
  assert.equal(res.status, 413);
  assert.match((await res.json()).error, /larger than the/);
});

test('regenerate rebuilds the report from the stored output', async (t) => {
  const s = await start(); t.after(s.close);
  const { report } = await (await s.post('Acme', MOCK)).json();
  s.db.raw.prepare("UPDATE reports SET analyzer_version = '0.0.1' WHERE id = ?").run(report.id);
  const res = await fetch(`${s.base}/api/reports/${report.id}/regenerate`, { method: 'POST' });
  assert.equal(res.status, 200);
  assert.equal((await res.json()).report.analyzer_version, require('../analyzer/version').ANALYZER_VERSION);
});

test('delete and rename require the PIN only when ADMIN_PIN is set', async (t) => {
  const open = await start(); t.after(open.close);
  const { report } = await (await open.post('Acme', MOCK)).json();
  assert.equal((await fetch(`${open.base}/api/reports/${report.id}`, { method: 'DELETE' })).status, 200);
  assert.equal((await fetch(`${open.base}/api/reports/${report.id}`)).status, 404);

  const locked = await start({ adminPin: '4321' }); t.after(locked.close);
  const r2 = (await (await locked.post('Acme', MOCK)).json()).report;
  const noPin = await fetch(`${locked.base}/api/reports/${r2.id}`, { method: 'DELETE' });
  assert.equal(noPin.status, 401);
  assert.equal((await noPin.json()).pinRequired, true);
  assert.equal((await fetch(`${locked.base}/api/reports/${r2.id}`, { method: 'DELETE', headers: { 'X-Admin-Pin': 'wrong' } })).status, 401);
  const jsonHdr = { 'Content-Type': 'application/json', 'X-Admin-Pin': '4321' };
  const ren = await fetch(`${locked.base}/api/customers/${r2.customer_id}`, { method: 'PATCH', headers: jsonHdr, body: JSON.stringify({ name: 'Acme Inc' }) });
  assert.equal(ren.status, 200);
  assert.equal((await ren.json()).name, 'Acme Inc');
  assert.equal((await fetch(`${locked.base}/api/reports/${r2.id}`, { method: 'DELETE', headers: { 'X-Admin-Pin': '4321' } })).status, 200);
});

test('renaming onto an existing customer is refused', async (t) => {
  const s = await start(); t.after(s.close);
  await s.post('Acme', MOCK);
  const g = (await (await s.post('Globex', MOCK)).json()).report;
  const res = await fetch(`${s.base}/api/customers/${g.customer_id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'ACME' }) });
  assert.equal(res.status, 409);
});

test('search and filters on the report list', async (t) => {
  const s = await start(); t.after(s.close);
  await s.post('Acme', MOCK, '&note=pre-renewal%20site%20A');
  await s.post('Globex', REAL);
  const q = async (qs) => (await (await fetch(`${s.base}/api/reports?${qs}`)).json());
  assert.equal((await q('q=renewal')).total, 1);
  assert.equal((await q('q=globex')).total, 1);
  assert.equal((await q('q=SVCTAG1')).total, 2);
  assert.equal((await q('q=nomatch')).total, 0);
  assert.equal((await q('q=%25')).total, 0, 'LIKE wildcards are escaped');
  assert.equal((await q('limit=1')).rows.length, 1);
});

test('names with markup are escaped in the report', async (t) => {
  const s = await start(); t.after(s.close);
  const { report } = await (await s.post('<img src=x onerror=alert(1)>', MOCK)).json();
  const html = await (await fetch(`${s.base}/api/reports/${report.id}/html`)).text();
  assert.ok(!html.includes('<img src=x'));
  assert.ok(html.includes('&lt;img src=x'));
});

test('collector downloads: catalog, availability, binary and generated source zip', async (t) => {
  const s = await start(); t.after(s.close);
  const list = await (await fetch(`${s.base}/api/downloads`)).json();
  const by = Object.fromEntries(list.map((d) => [d.id, d]));
  assert.equal(by.windows.available, true);
  assert.equal(by.windows.size, 'MZ-fake-exe'.length);
  assert.match(by.windows.sha256, /^[0-9a-f]{64}$/);
  assert.equal(by.linux.available, false);
  assert.match(by.linux.note, /downloads folder/);
  assert.equal(by.source.available, true);

  const exe = await fetch(`${s.base}/download/windows`);
  assert.equal(exe.status, 200);
  assert.match(exe.headers.get('content-disposition'), /pstore-assess-win-x64\.exe/);
  assert.equal(await exe.text(), 'MZ-fake-exe');
  assert.equal((await fetch(`${s.base}/download/linux`)).status, 404);
  assert.equal((await fetch(`${s.base}/download/nope`)).status, 404);

  const zip = Buffer.from(await (await fetch(`${s.base}/download/source`)).arrayBuffer());
  const names = [];
  const eocd = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  let p = zip.readUInt32LE(eocd + 16);
  for (let i = 0; i < zip.readUInt16LE(eocd + 10); i++) {
    const n = zip.readUInt16LE(p + 28);
    names.push(zip.toString('utf8', p + 46, p + 46 + n));
    p += 46 + n + zip.readUInt16LE(p + 30) + zip.readUInt16LE(p + 32);
  }
  for (const f of ['README.txt', 'package.json', 'src/cli.js', 'src/collect.js', 'src/guard.js']) assert.ok(names.includes(f), `${f} missing from ${names}`);
  assert.match(unzipFirstJson(zip, 1e6).toString(), /pstore-assess-collector/);

  const stats = await (await fetch(`${s.base}/api/downloads`)).json();
  assert.equal(stats.find((d) => d.id === 'windows').downloads, 1, 'downloads are counted');
});

test('page and config', async (t) => {
  const s = await start({ portalUrl: 'http://portal.example' }); t.after(s.close);
  const page = await (await fetch(`${s.base}/`)).text();
  assert.ok(page.includes('PowerStore Assessment') && page.includes('Download the collector') && page.includes('Generate report'));
  assert.equal((await fetch(`${s.base}/css/app.css`)).status, 200);
  assert.equal((await fetch(`${s.base}/js/app.js`)).status, 200);
  const cfg = await (await fetch(`${s.base}/api/config`)).json();
  assert.equal(cfg.portalUrl, 'http://portal.example');
  assert.equal(cfg.pinRequired, false);
  assert.equal((await fetch(`${s.base}/api/nothing`)).status, 404);
});

test('decodeUpload unit checks', () => {
  assert.throws(() => decodeUpload(Buffer.from('<html></html>')), /not collector output/);
  assert.equal(decodeUpload(Buffer.from('{"a":1}')), '{"a":1}');
  assert.throws(() => decodeUpload(zlib.gzipSync(Buffer.alloc(5000, 0x7b)), { maxBytes: 100 }), /too large/);
});

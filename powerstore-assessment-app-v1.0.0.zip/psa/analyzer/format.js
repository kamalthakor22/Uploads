'use strict';
// Shared formatting helpers for the report.

const { fmtBytes, pct } = require('./rules');

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const n2 = (x, d = 2) => (x == null || !Number.isFinite(Number(x)) ? 'n/a' : Number(x).toLocaleString('en-US', { maximumFractionDigits: d }));
const ratio = (x) => (x == null || x === 0 ? 'n/a' : `${n2(x, 1)}:1`);
const ms = (us, d = 2) => (us == null ? 'n/a' : `${n2(us / 1000, d)} ms`);
const mibs = (bps) => (bps == null ? 'n/a' : Math.abs(bps) < 1048576 ? `${n2(bps / 1024, 1)} KiB/s` : `${n2(bps / 1048576, 1)} MiB/s`);
const kiops = (v) => (v == null ? 'n/a' : v >= 1000 ? `${n2(v / 1000, 1)} kIOPS` : `${n2(v, 1)} IOPS`);
const kib = (b) => (b == null ? 'n/a' : `${n2(b / 1024, 1)} KiB`);
const when = (iso) => (iso ? String(iso).replace('T', ' ').replace(/(\.\d+)?Z$/, ' UTC') : 'n/a');
const day = (iso) => (iso ? String(iso).slice(0, 10) : 'n/a');
const decTB = (b) => (b == null ? 'n/a' : `${n2(b / 1e12, 2)} TB`);
const dash = (x) => (x == null || x === '' || (Array.isArray(x) && x.length === 0) ? '&ndash;' : esc(Array.isArray(x) ? x.join(', ') : x));
const days = (d) => (d == null ? 'no projected date' : d === 0 ? 'already past' : d > 3650 ? '> 10 years' : `${Math.round(d)} days`);
const ago = (s) => (s == null ? 'n/a' : s < 3600 ? `${Math.round(s / 60)} min ago` : s < 172800 ? `${Math.round(s / 3600)} h ago` : `${Math.round(s / 86400)} days ago`);

module.exports = { esc, n2, ratio, ms, mibs, kiops, kib, when, day, decTB, dash, days, ago, fmtBytes, pct };

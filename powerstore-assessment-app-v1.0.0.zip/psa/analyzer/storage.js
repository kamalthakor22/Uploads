'use strict';
// Normalization for everything beyond cluster/appliance/node/drives: volumes,
// hosts, file services, protection, alerts, ports, growth, per-appliance views.
//
// Field names come from Dell's Go client (gopowerstore) and docs. Only the
// cluster/appliance/node/hardware/drive/metrics shapes are validated on a real
// array (4.4.0.0); everything here reads defensively and reports "n/a" rather
// than guessing when a field or resource is absent.

const { getCollection, metricPoints, buildCapacity, perfFor, linearFit, val, peakOf, num, mean, maxWithTime, ok, DAY_MS } = require('./normalize');

const plain = (q) => !q.includes('('); // ignore nested-select probes
const coll = (bundle, path) => getCollection(bundle, path, plain);
const probe = (bundle, path, marker) => getCollection(bundle, path, (q) => q.includes(marker));

/** True if the bundle holds a usable read of this resource (schema 2 coverage, or any OK record). */
function collected(bundle, name) {
  const cov = (bundle.coverage || []).find((c) => c.resource === name);
  if (cov) return cov.status === 'ok' || cov.status === 'partial' || cov.status === 'truncated';
  return bundle.records.some((r) => r.method === 'GET' && r.path === '/' + name && ok(r));
}

const byId = (rows) => new Map(rows.filter((r) => r && r.id != null).map((r) => [r.id, r]));
const names = (rows) => new Map(rows.filter((r) => r && r.id != null).map((r) => [r.id, r.name]));
const short = (id) => (id ? String(id).slice(0, 8) : null);
const pct = (a, b) => (b ? a / b : null);

// ---------------------------------------------------------------------------
// Storage objects
// ---------------------------------------------------------------------------

function buildVolumes(bundle) {
  const vols = coll(bundle, '/volume');
  const policies = names(coll(bundle, '/policy'));
  const perfPolicies = names(coll(bundle, '/performance_policy'));
  const vgs = coll(bundle, '/volume_group');
  const vgById = byId(vgs);
  const vgProbe = probe(bundle, '/volume', 'volume_groups(');
  const vgByVolume = new Map(vgProbe.map((v) => [v.id, (v.volume_groups || []).map((g) => g.name || (vgById.get(g.id) || {}).name).filter(Boolean)]));
  const vgPolicyByVolume = new Map(vgProbe.map((v) => [v.id, (v.volume_groups || []).some((g) => (vgById.get(g.id) || {}).protection_policy_id)]));
  const mappings = coll(bundle, '/host_volume_mapping');
  const mapTargets = new Map();
  for (const m of mappings) {
    const set = mapTargets.get(m.volume_id) || new Set();
    set.add(m.host_id || m.host_group_id);
    mapTargets.set(m.volume_id, set);
  }
  const perfName = (id) => (id == null ? null : perfPolicies.get(id) || String(id).replace(/^default_/, '').replace(/^./, (c) => c.toUpperCase()));

  const rows = vols.map((v) => {
    const own = v.protection_policy_id || null;
    return {
      id: v.id,
      name: v.name,
      type: v.type,
      state: v.state,
      wwn: v.wwn,
      sizeBytes: num(v.size),
      logicalUsedBytes: num(v.logical_used),
      protocol: v.nsid != null || v.nguid ? 'NVMe' : 'SCSI',
      hostMappings: (mapTargets.get(v.id) || new Set()).size,
      protectionPolicy: own ? policies.get(own) || short(own) : null,
      protectedByGroup: !own && !!vgPolicyByVolume.get(v.id),
      performancePolicy: perfName(v.performance_policy_id),
      volumeGroups: vgByVolume.get(v.id) || [],
      created: v.creation_timestamp || null,
      replicationDestination: !!v.is_replication_destination,
      sourceId: v.protection_data ? v.protection_data.source_id : null,
    };
  });
  const primary = rows.filter((r) => r.type === 'Primary');
  const live = rows.filter((r) => r.type !== 'Snapshot'); // PowerStore Manager's Volumes list excludes snapshots
  const summary = {
    total: rows.length,
    primary: primary.length,
    clones: rows.filter((r) => r.type === 'Clone').length,
    snapshots: rows.filter((r) => r.type === 'Snapshot').length,
    listed: live.length,
    provisionedBytes: live.reduce((a, r) => a + (r.sizeBytes || 0), 0),
    logicalUsedBytes: live.reduce((a, r) => a + (r.logicalUsedBytes || 0), 0),
    snapshotLogicalUsedBytes: rows.filter((r) => r.type === 'Snapshot').reduce((a, r) => a + (r.logicalUsedBytes || 0), 0),
    unprotected: primary.filter((r) => !r.protectionPolicy && !r.protectedByGroup && !r.replicationDestination).map((r) => r.name),
    unmapped: primary.filter((r) => r.hostMappings === 0 && !r.replicationDestination && r.volumeGroups.length === 0).map((r) => r.name),
  };
  const topConsumers = [...live].sort((a, b) => (b.logicalUsedBytes || 0) - (a.logicalUsedBytes || 0)).slice(0, 10);

  const memberCount = new Map();
  for (const names_ of vgByVolume.values()) for (const n of names_) memberCount.set(n, (memberCount.get(n) || 0) + 1);
  const volumeGroups = vgs.map((g) => ({
    id: g.id,
    name: g.name,
    type: g.type,
    members: vgProbe.length ? memberCount.get(g.name) || 0 : Array.isArray(g.volumes) ? g.volumes.length : null,
    protectionPolicy: g.protection_policy_id ? policies.get(g.protection_policy_id) || short(g.protection_policy_id) : null,
    writeOrderConsistent: g.is_write_order_consistent,
    created: g.creation_timestamp || null,
    replicationDestination: !!g.is_replication_destination,
  }));
  return { rows, summary, topConsumers, volumeGroups };
}

function buildHosts(bundle) {
  const hosts = coll(bundle, '/host');
  const groups = coll(bundle, '/host_group');
  const initProbe = new Map(probe(bundle, '/host', 'host_initiators(').map((h) => [h.id, h.host_initiators || []]));
  const mappings = coll(bundle, '/host_volume_mapping');
  const directCount = new Map();
  const groupCount = new Map();
  for (const m of mappings) {
    if (m.host_id) directCount.set(m.host_id, (directCount.get(m.host_id) || 0) + 1);
    if (m.host_group_id) groupCount.set(m.host_group_id, (groupCount.get(m.host_group_id) || 0) + 1);
  }
  const groupName = names(groups);
  const initsOf = (h) => initProbe.get(h.id) || h.host_initiators || [];
  const types = (inits) => [...new Set(inits.map((i) => i.port_type).filter(Boolean))];

  const hostRows = hosts.map((h) => {
    const inits = initsOf(h);
    return {
      kind: 'Host',
      id: h.id,
      name: h.name,
      os: h.os_type,
      initiatorTypes: types(inits),
      initiators: inits.length,
      volumeMappings: directCount.get(h.id) || 0,
      viaGroup: h.host_group_id ? groupCount.get(h.host_group_id) || 0 : 0,
      group: h.host_group_id ? groupName.get(h.host_group_id) || short(h.host_group_id) : null,
      connectivity: h.host_connectivity || null,
    };
  });
  const groupRows = groups.map((g) => {
    const members = hostRows.filter((h) => hosts.find((x) => x.id === h.id && x.host_group_id === g.id));
    return {
      kind: 'Host Group',
      id: g.id,
      name: g.name,
      os: [...new Set(members.map((m) => m.os).filter(Boolean))].join(', ') || null,
      initiatorTypes: [...new Set(members.flatMap((m) => m.initiatorTypes))],
      initiators: members.reduce((a, m) => a + m.initiators, 0),
      volumeMappings: groupCount.get(g.id) || 0,
      viaGroup: 0,
      group: null,
      members: members.length,
      connectivity: g.host_connectivity || null,
    };
  });
  return { rows: [...hostRows, ...groupRows], hostCount: hostRows.length, groupCount: groupRows.length };
}

function buildFile(bundle, nodeNames) {
  const nas = coll(bundle, '/nas_server');
  const fsRaw = coll(bundle, '/file_system');
  const policies = names(coll(bundle, '/policy'));
  const nasName = names(nas);
  const fsName = names(fsRaw);
  const fsPerNas = new Map();
  for (const f of fsRaw) fsPerNas.set(f.nas_server_id, (fsPerNas.get(f.nas_server_id) || 0) + 1);
  const policyName = (id) => (id ? policies.get(id) || short(id) : null);
  return {
    nasServers: nas.map((n) => ({
      id: n.id, name: n.name, status: n.operational_status, node: nodeNames.get(n.current_node_id) || n.current_node_id || null,
      fileSystems: fsPerNas.get(n.id) || 0, protectionPolicy: policyName(n.protection_policy_id), replicationDestination: !!n.is_replication_destination,
    })),
    fileSystems: fsRaw.map((f) => ({
      id: f.id, name: f.name, configType: f.config_type, type: f.filesystem_type, sizeUsedBytes: num(f.size_used), sizeTotalBytes: num(f.size_total),
      usedPct: pct(num(f.size_used), num(f.size_total)), nasServer: nasName.get(f.nas_server_id) || short(f.nas_server_id),
      protectionPolicy: policyName(f.protection_policy_id), flrMode: (f.flr_attributes && f.flr_attributes.mode) || 'None',
      created: f.creation_timestamp || null, lastRefreshed: f.last_refresh_timestamp || null,
    })),
    nfsExports: coll(bundle, '/nfs_export').map((e) => ({ id: e.id, name: e.name, path: e.path, fileSystem: fsName.get(e.file_system_id) || short(e.file_system_id), defaultAccess: e.default_access })),
    smbShares: coll(bundle, '/smb_share').map((e) => ({ id: e.id, name: e.name, path: e.path, fileSystem: fsName.get(e.file_system_id) || short(e.file_system_id), encryption: e.is_encryption_enabled })),
    nfsServers: coll(bundle, '/nfs_server').length,
  };
}

function buildProtection(bundle, volumes, file, startedAt) {
  const remote = coll(bundle, '/remote_system');
  const remoteName = names(remote);
  const policies = coll(bundle, '/policy');
  const rules = coll(bundle, '/replication_rule');
  const now = Date.parse(startedAt) || Date.now();

  // Resolve a session's local resource id to a name across every replicable resource type.
  const lookup = new Map();
  for (const v of volumes.rows) lookup.set(v.id, v.name);
  for (const g of volumes.volumeGroups) lookup.set(g.id, g.name);
  for (const n of file.nasServers) lookup.set(n.id, n.name);
  for (const f of file.fileSystems) lookup.set(f.id, f.name);

  const sessions = coll(bundle, '/replication_session').map((s) => {
    const last = s.last_sync_timestamp ? Date.parse(s.last_sync_timestamp) : null;
    return {
      id: s.id,
      source: lookup.get(s.local_resource_id) || short(s.local_resource_id),
      resourceType: s.resource_type,
      sourceSystem: 'Current System',
      destinationSystem: remoteName.get(s.remote_system_id) || short(s.remote_system_id),
      destinationResource: short(s.remote_resource_id),
      role: s.role,
      replicationType: s.type,
      state: s.state,
      transferState: s.data_transfer_state,
      lastSync: s.last_sync_timestamp || null,
      lastSyncAgeSeconds: last && Number.isFinite(last) ? Math.max(0, Math.round((now - last) / 1000)) : null,
    };
  });
  const protectedPct = (items) => {
    const n = items.length;
    return n ? items.filter((i) => i.protectionPolicy || i.protectedByGroup).length / n : null;
  };
  return {
    sessions,
    policies: policies.map((p) => ({ id: p.id, name: p.name, type: p.type, description: p.description, managedBy: p.managed_by })),
    snapshotRules: coll(bundle, '/snapshot_rule').map((r) => ({ name: r.name, interval: r.interval, timeOfDay: r.time_of_day, retention: r.desired_retention })),
    replicationRules: rules.map((r) => ({ name: r.name, rpo: r.rpo, remoteSystem: remoteName.get(r.remote_system_id) || short(r.remote_system_id), alertThreshold: r.alert_threshold })),
    remoteSystems: remote.map((r) => ({ name: r.name, type: r.type, address: r.management_address, state: r.data_connection_state, latency: r.data_network_latency })),
    coverage: {
      volumes: protectedPct(volumes.rows.filter((v) => v.type === 'Primary' && !v.replicationDestination)),
      volumeGroups: protectedPct(volumes.volumeGroups.filter((g) => !g.replicationDestination)),
      fileSystems: protectedPct(file.fileSystems),
    },
  };
}

const SEV_ORDER = { Critical: 0, Major: 1, Minor: 2, Info: 3 };

function buildAlerts(bundle) {
  const rows = coll(bundle, '/alert').map((a) => ({
    id: a.id, severity: a.severity, state: a.state, acknowledged: !!a.is_acknowledged, resource: a.resource_name, resourceType: a.resource_type,
    description: a.description_l10n, raised: a.raised_timestamp || a.generated_timestamp || null, cleared: a.cleared_timestamp || null, code: a.event_code,
    active: !a.cleared_timestamp && String(a.state || '').toUpperCase() !== 'CLEARED',
  }));
  rows.sort((a, b) => (SEV_ORDER[a.severity] ?? 9) - (SEV_ORDER[b.severity] ?? 9) || String(b.raised).localeCompare(String(a.raised)));
  const counts = { Critical: 0, Major: 0, Minor: 0, Info: 0 };
  for (const a of rows.filter((x) => x.active)) if (a.severity in counts) counts[a.severity]++;
  return { rows, counts, active: rows.filter((r) => r.active).length, unacknowledged: rows.filter((r) => r.active && !r.acknowledged && r.severity !== 'Info').length };
}

function buildPorts(bundle, nodeNames) {
  const node = (id) => nodeNames.get(id) || id || null;
  const fc = coll(bundle, '/fc_port').map((p) => ({ id: p.id, applianceId: p.appliance_id, name: p.name, node: node(p.node_id), linkUp: p.is_link_up, speed: p.current_speed, wwn: p.wwn, inUse: true }));
  const eth = coll(bundle, '/eth_port').map((p) => ({ id: p.id, applianceId: p.appliance_id, name: p.name, node: node(p.node_id), linkUp: p.is_link_up, speed: p.current_speed, mac: p.mac_address, inUse: !!p.is_in_use }));
  const all = [...fc, ...eth];
  return { fc, eth, up: all.filter((p) => p.linkUp).length, down: all.filter((p) => p.linkUp === false).length, downInUse: all.filter((p) => p.linkUp === false && p.inUse).map((p) => p.name) };
}

// ---------------------------------------------------------------------------
// Capacity per appliance, growth, performance extras
// ---------------------------------------------------------------------------

function growthOf(daily, key, totalOf) {
  const pts = daily.filter((d) => d[key] != null);
  if (pts.length < 2) return null;
  const t0 = pts[0].t;
  const fit = linearFit(pts.map((d) => (d.t - t0) / DAY_MS), pts.map((d) => d[key]));
  if (!fit) return null;
  const used = pts.at(-1)[key];
  const total = totalOf ? totalOf(pts.at(-1)) : null;
  const daysTo = (frac) => (total == null ? null : used >= frac * total ? 0 : fit.slope > 0 ? (frac * total - used) / fit.slope : null);
  return {
    bytesPerDay: fit.slope, r2: fit.r2, points: pts.length, historyDays: Math.round((pts.at(-1).t - t0) / DAY_MS), used, total, intercept: fit.intercept, t0,
    daysTo80: daysTo(0.8), daysTo90: daysTo(0.9), daysTo100: daysTo(1.0),
  };
}

function dailyRows(cap) {
  return (cap ? cap.daily : []).map((d) => ({ ...d, system: d.physicalUsed != null && d.dataPhysicalUsed != null ? d.physicalUsed - d.dataPhysicalUsed : null }));
}

function buildGrowth(capacity, capacityByAppliance, appliances) {
  const forCap = (cap) => {
    const d = dailyRows(cap);
    return {
      physical: growthOf(d, 'physicalUsed', (x) => x.physicalTotal),
      logical: growthOf(d, 'logicalUsed', null),
      user: growthOf(d, 'dataPhysicalUsed', null),
      system: growthOf(d, 'system', null),
    };
  };
  return {
    cluster: capacity ? forCap(capacity) : null,
    appliances: appliances.map((a) => ({ id: a.id, name: a.name, ...(capacityByAppliance[a.id] ? forCap(capacityByAppliance[a.id]) : { physical: null, logical: null, user: null, system: null }) })),
  };
}

function buildVolumeMetrics(bundle, volumeRows) {
  const out = [];
  for (const v of volumeRows) {
    const space = metricPoints(bundle, 'space_metrics_by_volume', v.id, 'One_Day');
    const perf = metricPoints(bundle, 'performance_metrics_by_volume', v.id, 'One_Day');
    if (!space.length && !perf.length) continue;
    const pts = space.map((p) => ({ t: Date.parse(p.timestamp), used: num(val(p, 'logical_used')) })).filter((p) => p.used != null && Number.isFinite(p.t));
    let growth = null;
    if (pts.length >= 2) {
      const fit = linearFit(pts.map((p) => (p.t - pts[0].t) / DAY_MS), pts.map((p) => p.used));
      if (fit) growth = { bytesPerDay: fit.slope, pctPerDay: pts.at(-1).used ? fit.slope / pts.at(-1).used : null, r2: fit.r2, days: Math.round((pts.at(-1).t - pts[0].t) / DAY_MS) };
    }
    const iopsAvg = perf.map((p) => num(p.avg_total_iops)).filter((x) => x !== null);
    out.push({
      id: v.id, name: v.name, logicalUsedBytes: v.logicalUsedBytes, provisionedBytes: v.sizeBytes, growth,
      peakIops: maxWithTime(perf, 'total_iops'), avgIops: mean(iopsAvg),
      avgLatencyUs: mean(perf.map((p) => num(p.avg_latency)).filter((x) => x !== null)), peakBandwidth: maxWithTime(perf, 'total_bandwidth'),
    });
  }
  return out;
}

/** Latest sample (newest 5-minute bucket, else the finest available) for an entity. */
function latestPerf(bundle, entity, id) {
  for (const iv of ['Five_Mins', 'One_Hour', 'One_Day']) {
    const pts = metricPoints(bundle, entity, id, iv);
    if (pts.length) {
      const p = pts.at(-1);
      return { at: p.timestamp, interval: iv, latencyUs: num(p.avg_latency), ioSize: num(p.avg_io_size), iops: num(p.avg_total_iops), bandwidth: num(p.avg_total_bandwidth),
        readLatencyUs: num(p.avg_read_latency), writeLatencyUs: num(p.avg_write_latency) };
    }
  }
  return null;
}

/** Chart timelines: PowerStore Manager's four views, mapped onto the intervals we collect. */
function timelines(bundle, entity, id) {
  const five = metricPoints(bundle, entity, id, 'Five_Mins');
  const hour = metricPoints(bundle, entity, id, 'One_Hour');
  const day = metricPoints(bundle, entity, id, 'One_Day');
  const t = {};
  if (five.length) {
    t['Last hour'] = { points: five.slice(-12), bucket: '5 min' };
    t['Last 24 hours'] = { points: five, bucket: '5 min' };
  }
  if (hour.length) t['Last 1 month'] = { points: hour, bucket: '1 hour' };
  if (day.length) t['Last 2 years'] = { points: day, bucket: '1 day' };
  return t;
}

// ---------------------------------------------------------------------------

function buildStorageModel(bundle, inventory) {
  const nodeNames = new Map(inventory.nodes.map((n) => [n.id, n.name || n.id]));
  const volumes = buildVolumes(bundle);
  const hosts = buildHosts(bundle);
  const file = buildFile(bundle, nodeNames);
  const protection = buildProtection(bundle, volumes, file, bundle.started_at);
  const alerts = buildAlerts(bundle);
  const ports = buildPorts(bundle, nodeNames);
  const vms = coll(bundle, '/virtual_machine');

  const capacityByAppliance = {};
  for (const a of inventory.appliances) {
    const c = buildCapacity(bundle, a.id, 'space_metrics_by_appliance');
    if (c) capacityByAppliance[a.id] = c;
  }
  const clusterId = inventory.cluster ? inventory.cluster.id : '0';
  const clusterCap = buildCapacity(bundle, clusterId);
  const growth = buildGrowth(clusterCap, capacityByAppliance, inventory.appliances);

  const topForMetrics = volumes.rows.filter((v) => v.type !== 'Snapshot');
  const volumeMetrics = buildVolumeMetrics(bundle, topForMetrics);

  const latest = {
    cluster: latestPerf(bundle, 'performance_metrics_by_cluster', clusterId),
    appliances: Object.fromEntries(inventory.appliances.map((a) => [a.id, latestPerf(bundle, 'performance_metrics_by_appliance', a.id)])),
    nodes: Object.fromEntries(inventory.nodes.map((n) => [n.id, latestPerf(bundle, 'performance_metrics_by_node', n.id)])),
    file: latestPerf(bundle, 'performance_metrics_file_by_cluster', clusterId),
  };
  const filePerf = collected(bundle, 'file_system') && file.fileSystems.length ? perfFor(bundle, 'performance_metrics_file_by_cluster', clusterId) : null;

  const timeline = {
    space: timelines(bundle, 'space_metrics_by_cluster', clusterId),
    cluster: timelines(bundle, 'performance_metrics_by_cluster', clusterId),
    file: filePerf && Object.keys(filePerf.windows).length ? timelines(bundle, 'performance_metrics_file_by_cluster', clusterId) : {},
    appliances: Object.fromEntries(inventory.appliances.map((a) => [a.id, timelines(bundle, 'performance_metrics_by_appliance', a.id)])),
    nodes: Object.fromEntries(inventory.nodes.map((n) => [n.id, timelines(bundle, 'performance_metrics_by_node', n.id)])),
  };

  const have = {};
  for (const r of ['volume', 'volume_group', 'host', 'host_group', 'file_system', 'nas_server', 'nfs_export', 'smb_share', 'replication_session', 'policy', 'alert', 'fc_port', 'eth_port', 'virtual_machine', 'storage_container', 'remote_system']) have[r] = collected(bundle, r);

  return {
    have, volumes, hosts, file, protection, alerts, ports, vms: vms.map((v) => ({ id: v.id, name: v.name, type: v.type })),
    storageContainers: coll(bundle, '/storage_container').map((c) => ({ id: c.id, name: c.name, quota: c.quota, protocol: c.storage_protocol, highWaterMark: c.high_water_mark })),
    inventoryCounts: {
      volumeGroups: volumes.volumeGroups.length, volumes: volumes.summary.listed, hosts: hosts.hostCount, hostGroups: hosts.groupCount,
      virtualMachines: vms.length, fileSystems: file.fileSystems.length, smbShares: file.smbShares.length, nfsExports: file.nfsExports.length, nasServers: file.nasServers.length,
    },
    capacity: clusterCap, capacityByAppliance, growth, volumeMetrics, latest, filePerf, timeline,
  };
}

module.exports = { buildStorageModel, collected, growthOf };

'use strict';
// Dashboards modelled on PowerStore Manager: Appliances, Drives, Hosts, Storage, Protection, Alerts, Collection.

const { esc, n2, ratio, ms, mibs, kiops, when, day, decTB, dash, ago, fmtBytes, pct } = require('./format');
const { switcher, table, bar, status, card, stat, na } = require('./ui');
const { donut } = require('./charts');
const { timelineSwitcher, tib } = require('./views-core');

// ---------------------------------------------------------------------------
// Appliances (hardware)
// ---------------------------------------------------------------------------

function portsTable(ports) {
  const rows = ports.map((p) => [esc(p.name), dash(p.node), p.linkUp === true ? status('ok', 'Up') : p.linkUp === false ? status(p.inUse ? 'bad' : 'warn', 'Down') : '&ndash;', dash(p.speed), dash(p.wwn || p.mac), p.inUse ? 'yes' : 'no']);
  return table(['Port', 'Node', 'Link', 'Speed', 'WWN / MAC', 'In use'], rows, { empty: 'No ports collected.' });
}

function appliances(model) {
  const inv = model.inventory;
  const S = model.storage;
  const comp = inv.componentCounts;
  const compTotal = Object.values(comp).reduce((a, b) => a + b, 0);
  const sections = inv.appliances.map((a) => {
    const cap = S.capacityByAppliance[a.id];
    const L = S.latest.appliances[a.id];
    const nodes = inv.nodes.filter((n) => n.applianceId === a.id);
    const badHw = inv.unhealthy.length;
    const capCard = cap
      ? `<div class="capmini">${donut(cap.derived.physicalUsedPct, pct(cap.derived.physicalUsedPct, 1))}<div class="stats">${stat(tib(cap.derived.physicalFreeBytes), 'Free')}${stat(tib(cap.latest.physicalTotal), 'Physical')}</div></div>`
      : '<p class="empty">No appliance space metrics.</p>';
    const perfCard = `<div class="stats">${stat(L ? ms(L.latencyUs) : 'n/a', 'Latency')}${stat(L ? kiops(L.iops) : 'n/a', 'IOPS')}${stat(L ? mibs(L.bandwidth) : 'n/a', 'Bandwidth')}</div>`;
    const alertCard = S.have.alert ? `<div class="stats">${stat(S.alerts.counts.Critical, 'Critical', S.alerts.counts.Critical ? 'bad' : '')}${stat(S.alerts.counts.Major, 'Major', S.alerts.counts.Major ? 'warn' : '')}${stat(S.alerts.counts.Minor, 'Minor')}</div><p class="note">Cluster-wide counts.</p>` : '<p class="empty">Not collected.</p>';
    const compCard = `<div class="stats">${stat(esc(compTotal - badHw), 'Healthy or empty', 'ok')}${stat(esc(badHw), 'Not healthy', badHw ? 'bad' : '')}</div><p class="note">${esc(compTotal)} hardware objects in the inventory.</p>`;

    const nodeRows = nodes.map((n) => {
      const l = S.latest.nodes[n.id];
      const perf = model.performance.nodes.find((x) => x.id === n.id);
      const w = perf && (perf.windows.One_Day || perf.windows.One_Hour || perf.windows.Five_Mins);
      return [esc(n.name || n.id), dash(n.cpuModel), esc(`${n.cpuSockets ?? '?'} x ${n.cpuCores ?? '?'}`), n.memoryGB != null ? `${n.memoryGB} GB` : 'n/a', ms(l && l.latencyUs), kiops(l && l.iops), mibs(l && l.bandwidth), w && w.cpu && w.cpu.max ? n2(w.cpu.max.value, 3) : 'n/a'];
    });
    const charts = switcher(
      [
        { label: a.name, html: timelineSwitcher(S.timeline.appliances[a.id] || {}) },
        ...nodes.map((n) => ({ label: n.name || n.id, html: timelineSwitcher(S.timeline.nodes[n.id] || {}) })),
      ],
      'pill',
    );
    const ports = [...S.ports.fc, ...S.ports.eth].filter((p) => !p.applianceId || p.applianceId === a.id);
    return `<div class="appl"><h3>${esc(a.name)} <small>${esc(a.model)} &middot; service tag ${esc(a.serviceTag || 'n/a')} &middot; PowerStoreOS ${esc(a.osVersions.join(', ') || 'unknown')}</small></h3>
      <div class="grid4">${card('Capacity', capCard)}${card('Performance (latest)', perfCard)}${card('Alerts', alertCard)}${card('Components', compCard)}</div>
      ${card('Nodes', table(['Node', 'CPU', ['Sockets x cores'], ['Memory'], ['Latency'], ['IOPS'], ['Bandwidth'], ['Max I/O CPU (raw)']], nodeRows, { empty: 'No nodes.' }) + '<p class="note">I/O-workload CPU utilization is shown as the array reports it; its unit is not yet confirmed.</p>', 'wide')}
      ${card('Performance charts', charts, 'wide')}
      ${S.have.fc_port || S.have.eth_port ? card('Ports', portsTable(ports), 'wide') : ''}</div>`;
  });
  const enc = inv.enclosures;
  const hw = `<p>${esc(enc.base)} base enclosure(s), ${esc(enc.expansion)} expansion enclosure(s) detected; ${esc(enc.linkControlCards)} link control card object(s) in the inventory (expansion enclosures were not present on the validation array, so how they appear is unconfirmed). ${esc(inv.bootDrives)} boot module(s).</p>`;
  const compTable = table(['Hardware type', ['Count']], Object.entries(comp).sort((a, b) => b[1] - a[1]).map(([k, v]) => [esc(k), esc(v)]));
  return `<h2>Appliances and hardware</h2>${card('Hardware summary', hw, 'wide')}${sections.join('')}${card('All hardware objects by type', compTable, 'wide')}`;
}

// ---------------------------------------------------------------------------
// Drives
// ---------------------------------------------------------------------------

function drives(model) {
  const inv = model.inventory;
  const ds = inv.driveSummary;
  const rows = inv.drives.map((d) => [
    esc(d.name), dash(d.enclosure), esc(d.slot ?? ''), dash(d.driveType), decTB(d.sizeBytes), dash(d.firmware), dash(d.lifecycle), dash(d.usage), dash(d.encryption),
    d.enduranceRemaining == null ? 'n/a' : `${bar(d.enduranceRemaining / 100, d.enduranceRemaining <= 20 ? 'bad' : d.enduranceRemaining <= 50 ? 'warn' : '')} ${n2(d.enduranceRemaining, 0)}%${d.enduranceMin != null && d.enduranceMin !== d.enduranceRemaining ? ` <small>(min ${n2(d.enduranceMin, 0)}%)</small>` : ''}`,
    d.wearLevelUsed == null ? 'n/a' : `${esc(d.wearLevelUsed)}%`,
  ]);
  const groups = ds.groups.map((g) => `${g.count} x ${esc(g.driveType)} ${decTB(g.sizeBytes)}`).join(', ');
  const worn = inv.drives.filter((d) => d.enduranceRemaining != null);
  const lowest = worn.length ? Math.min(...worn.map((d) => d.enduranceRemaining)) : null;
  return `<h2>Drives</h2>
    <div class="cards">${stat(esc(ds.count), 'Drives')}${stat(fmtBytes(ds.totalRawBytes), 'Raw capacity (binary)')}${stat(decTB(ds.totalRawBytes), 'Raw capacity (decimal)')}${stat(lowest == null ? 'n/a' : `${n2(lowest, 0)}%`, 'Lowest endurance remaining')}${stat(esc(inv.bootDrives), 'Boot modules')}</div>
    ${card(`Drive inventory${groups ? ': ' + groups : ''}`, table(['Drive', 'Enclosure', ['Slot'], 'Type', ['Size'], 'Firmware', 'State', 'Usage', 'Encryption', 'Endurance remaining', ['HW wear used']], rows, { empty: 'No drives in the hardware inventory.' }) + '<p class="note">Endurance comes from the daily wear metric; "HW wear used" is the drive object\'s own wear level. Drive counts exclude boot modules. Free drive slots are not shown because the enclosure slot count is not in the data collected.</p>', 'wide')}`;
}

// ---------------------------------------------------------------------------
// Hosts
// ---------------------------------------------------------------------------

function hosts(model) {
  const S = model.storage;
  if (!S.have.host) return `<h2>Host information</h2>${na('Hosts')}`;
  const rows = S.hosts.rows.map((h) => [esc(h.name), esc(h.kind), dash(h.os), dash(h.initiatorTypes), esc(h.initiators), esc(h.volumeMappings), h.kind === 'Host' ? esc(h.viaGroup) : esc(h.members ?? ''), dash(h.group), dash(h.connectivity)]);
  return `<h2>Host information</h2>${card(`${S.hosts.hostCount} hosts, ${S.hosts.groupCount} host groups`, table(['Name', 'Host / Host group', 'OS', 'Initiator type', ['Initiators'], ['Volume mappings'], ['Via group / members'], 'Host group', 'Connectivity'], rows, { empty: 'No hosts.' }) + '<p class="note">"Volume mappings" counts direct mappings to that host or group; hosts in a group also inherit the group\'s mappings ("via group"). Initiator type comes from the host initiators; vSphere host names are not collected.</p>', 'wide')}`;
}

// ---------------------------------------------------------------------------
// Storage
// ---------------------------------------------------------------------------

function storage(model) {
  const S = model.storage;
  const V = S.volumes;
  const volRows = [...V.rows].sort((a, b) => (a.type === 'Snapshot') - (b.type === 'Snapshot') || String(a.name).localeCompare(String(b.name))).map((v) => [
    esc(v.name), esc(v.type), dash(v.state), `<small>${dash(v.wwn)}</small>`, fmtBytes(v.logicalUsedBytes), fmtBytes(v.sizeBytes), esc(v.hostMappings), esc(v.protocol),
    v.protectionPolicy ? esc(v.protectionPolicy) : v.protectedByGroup ? '<small>via volume group</small>' : '&ndash;', dash(v.performancePolicy), dash(v.volumeGroups),
  ]);
  const vs = V.summary;
  const volumes = S.have.volume
    ? `<div class="cards">${stat(esc(vs.listed), 'Volumes (excl. snapshots)')}${stat(esc(vs.snapshots), 'Snapshots')}${stat(fmtBytes(vs.provisionedBytes), 'Provisioned')}${stat(fmtBytes(vs.logicalUsedBytes), 'Logical used')}</div>${table(['Name', 'Type', 'State', 'WWN', ['Logical used'], ['Provisioned'], ['Host mappings'], 'Protocol', 'Protection policy', 'Performance policy', 'Volume group'], volRows, { empty: 'No volumes.' })}`
    : na('Volumes');
  const vgs = S.have.volume_group ? table(['Name', 'Type', ['Members'], 'Protection policy', 'Write-order consistent', 'Created'], V.volumeGroups.map((g) => [esc(g.name), dash(g.type), g.members == null ? 'n/a' : esc(g.members), dash(g.protectionPolicy), g.writeOrderConsistent ? 'yes' : 'no', esc(day(g.created))]), { empty: 'No volume groups.' }) : na('Volume groups');
  const fsRows = S.file.fileSystems.map((f) => [esc(f.name), dash(f.configType), fmtBytes(f.sizeUsedBytes), fmtBytes(f.sizeTotalBytes), f.usedPct == null ? 'n/a' : `${bar(f.usedPct, f.usedPct >= 0.9 ? 'bad' : f.usedPct >= 0.8 ? 'warn' : '')} ${pct(f.usedPct, 0)}`, dash(f.nasServer), dash(f.protectionPolicy), dash(f.flrMode), esc(day(f.lastRefreshed))]);
  const fs = S.have.file_system ? table(['Name', 'Config type', ['Size used'], ['Total size'], 'Used', 'NAS server', 'Protection policy', 'FLR mode', 'Last refreshed'], fsRows, { empty: 'No file systems.' }) : na('File systems');
  const nas = S.have.nas_server ? table(['Name', 'Status', 'Node', ['File systems'], 'Protection policy', 'Replication destination'], S.file.nasServers.map((n) => [esc(n.name), dash(n.status), dash(n.node), esc(n.fileSystems), dash(n.protectionPolicy), n.replicationDestination ? 'yes' : 'no']), { empty: 'No NAS servers.' }) : na('NAS servers');
  const smb = S.have.smb_share ? table(['Share', 'Path', 'File system', 'Encryption'], S.file.smbShares.map((x) => [esc(x.name), dash(x.path), dash(x.fileSystem), x.encryption ? 'yes' : 'no']), { empty: 'No SMB shares.' }) : na('SMB shares');
  const nfs = S.have.nfs_export ? table(['Export', 'Path', 'File system', 'Default access'], S.file.nfsExports.map((x) => [esc(x.name), dash(x.path), dash(x.fileSystem), dash(x.defaultAccess)]), { empty: 'No NFS exports.' }) : na('NFS exports');
  const other = `${S.have.storage_container ? table(['Storage container', 'Protocol', ['Quota'], ['High-water mark']], S.storageContainers.map((c) => [esc(c.name), dash(c.protocol), c.quota ? fmtBytes(c.quota) : 'none', c.highWaterMark == null ? 'n/a' : `${esc(c.highWaterMark)}%`]), { empty: 'No storage containers.' }) : na('Storage containers')}
    ${S.have.virtual_machine ? `<h4>Virtual machines (${S.vms.length})</h4>${table(['Name', 'Type'], S.vms.map((v) => [esc(v.name), dash(v.type)]), { empty: 'No virtual machines.' })}` : ''}`;
  return `<h2>Storage</h2>${card('Storage objects', switcher([
    { label: `Volumes (${S.have.volume ? vs.listed : '-'})`, html: volumes },
    { label: `Volume groups (${S.have.volume_group ? V.volumeGroups.length : '-'})`, html: vgs },
    { label: `File systems (${S.have.file_system ? S.file.fileSystems.length : '-'})`, html: fs },
    { label: `NAS servers (${S.have.nas_server ? S.file.nasServers.length : '-'})`, html: nas },
    { label: `SMB shares (${S.have.smb_share ? S.file.smbShares.length : '-'})`, html: smb },
    { label: `NFS exports (${S.have.nfs_export ? S.file.nfsExports.length : '-'})`, html: nfs },
    { label: 'Containers and VMs', html: other },
  ], 'pill wrap'), 'wide')}`;
}

// ---------------------------------------------------------------------------
// Protection
// ---------------------------------------------------------------------------

function protection(model) {
  const S = model.storage;
  const P = S.protection;
  const cov = (label, v) => stat(v == null ? 'n/a' : pct(v, 0), label);
  const sessions = S.have.replication_session
    ? table(['Source resource', 'Session status', 'Source system', 'Resource type', 'Destination system', 'Destination resource', 'Local role', 'Replication type', 'Last synchronization'],
      P.sessions.map((x) => [esc(x.source), /(pause|fail|error|degrad|critical|unhealthy)/i.test(String(x.state)) ? status('bad', x.state) : status('ok', x.state || 'n/a'), esc(x.sourceSystem), dash(x.resourceType), dash(x.destinationSystem), `<small>${dash(x.destinationResource)}</small>`, dash(x.role), dash(x.replicationType), x.lastSync ? `${esc(when(x.lastSync))}<br><small>${esc(ago(x.lastSyncAgeSeconds))} at collection</small>` : '&ndash;']), { empty: 'No replication sessions.' })
    : na('Replication sessions');
  const rules = table(['Replication rule', 'RPO', 'Remote system', ['Alert threshold']], P.replicationRules.map((r) => [esc(r.name), dash(r.rpo), dash(r.remoteSystem), r.alertThreshold == null ? 'n/a' : esc(r.alertThreshold)]), { empty: 'No replication rules.' });
  const snaps = table(['Snapshot rule', 'Interval', 'Time of day', ['Retention (hours)']], P.snapshotRules.map((r) => [esc(r.name), dash(r.interval), dash(r.timeOfDay), r.retention == null ? 'n/a' : esc(r.retention)]), { empty: 'No snapshot rules.' });
  const pols = table(['Protection policy', 'Type', 'Description', 'Managed by'], P.policies.map((p) => [esc(p.name), dash(p.type), dash(p.description), dash(p.managedBy)]), { empty: 'No protection policies.' });
  const remote = table(['Remote system', 'Type', 'Address', 'Data connection', 'Latency'], P.remoteSystems.map((r) => [esc(r.name), dash(r.type), dash(r.address), dash(r.state), dash(r.latency)]), { empty: 'No remote systems.' });
  return `<h2>Protection and replication</h2>
    <div class="cards">${cov('Primary volumes with a policy', P.coverage.volumes)}${cov('Volume groups with a policy', P.coverage.volumeGroups)}${cov('File systems with a policy', P.coverage.fileSystems)}${stat(esc(P.sessions.length), 'Replication sessions')}</div>
    ${card('Replication', sessions + '<p class="note">Destination resources are shown by id prefix (their names live on the remote system). Next-synchronization times are not collected.</p>', 'wide')}
    <div class="grid2">${card('Replication rules', rules)}${card('Snapshot rules', snaps)}</div>
    <div class="grid2">${card('Protection policies', pols)}${card('Remote systems', remote)}</div>`;
}

// ---------------------------------------------------------------------------
// Alerts
// ---------------------------------------------------------------------------

function alerts(model) {
  const S = model.storage;
  if (!S.have.alert) return `<h2>Alerts</h2>${na('Alerts')}`;
  const sevKind = { Critical: 'bad', Major: 'warn', Minor: 'info', Info: 'info' };
  const rows = S.alerts.rows.map((a) => [status(sevKind[a.severity] || 'info', a.severity || 'n/a'), a.active ? 'active' : 'cleared', a.acknowledged ? 'yes' : 'no', dash(a.resource), dash(a.resourceType), esc(a.description || ''), esc(when(a.raised)), `<small>${dash(a.code)}</small>`]);
  const c = S.alerts.counts;
  return `<h2>Alerts</h2><div class="cards">${stat(c.Critical, 'Critical', c.Critical ? 'bad' : '')}${stat(c.Major, 'Major', c.Major ? 'warn' : '')}${stat(c.Minor, 'Minor')}${stat(c.Info, 'Info')}${stat(S.alerts.unacknowledged, 'Unacknowledged (not Info)')}</div>
    ${card('Alerts collected', table(['Severity', 'State', 'Acknowledged', 'Resource', 'Resource type', 'Description', 'Raised', 'Code'], rows, { empty: 'No alerts.' }) + '<p class="note">Counts are active alerts (not cleared). At most 1000 alerts are collected; events are not collected.</p>', 'wide')}`;
}

// ---------------------------------------------------------------------------
// Collection (data quality)
// ---------------------------------------------------------------------------

function collection(model) {
  const col = model.collection;
  const checks = model.definitionChecks.map((c) => [esc(c.name), `<small>${esc(c.formula)}</small>`, n2(c.expected, 3), n2(c.reported, 3), c.ok ? status('ok', 'matches') : status('warn', 'differs')]);
  const cov = (col.coverage || []).map((c) => [esc(c.resource), `<small>${esc(c.select)}</small>`, esc(c.items), c.status === 'ok' ? status('ok', 'ok') : c.status === 'unavailable' ? status('info', 'not offered') : status(c.status === 'denied' ? 'bad' : 'warn', c.status)]);
  const skipped = (col.skipped || []).map((s) => [esc(s.name), esc(s.reason)]);
  const unavailable = (col.unavailable || []).map((u) => [esc(u.name), esc(u.reason)]);
  const list = (arr) => (arr.length ? `<ul>${arr.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p class="empty">None.</p>');
  return `<h2>Collection and data quality</h2>
    ${card('This run', `<ul>
      <li>Collector ${esc(col.tool && col.tool.name)} ${esc(col.tool && col.tool.version)}, bundle schema ${esc(col.schemaVersion)}; run as user <code>${esc(col.user)}</code>; TLS verified: ${col.tlsVerified ? 'yes' : 'no'}.</li>
      <li>${esc(col.calls.ok)} calls OK, ${esc(col.calls.failed)} failed; PowerStoreOS ${esc((col.detectedOS || []).join(', ') || 'unknown')}.</li>
      <li>History in this bundle: ${col.historyDays != null ? `${esc(col.historyDays)} days of daily samples (oldest ${esc(col.oldestDailySample)})` : 'unknown'}. Windows: 5-minute (about 24 h), 1-hour, 1-day.</li>
      <li>Not collected: warranty and support end dates (look up by service tag), events, host and network configuration beyond what the dashboards show.</li></ul>
      <h4>Warnings (${col.warnings.length})</h4>${list(col.warnings)}`, 'wide')}
    <div class="grid2">${card('Resource coverage', table(['Resource', 'Select', ['Objects'], 'Result'], cov, { empty: 'This bundle predates per-resource coverage (schema 1).' }))}
    ${card('Not collected on purpose or not offered', `<h4>Not offered by this release (${unavailable.length})</h4>${table(['Resource', 'Reason'], unavailable, { empty: 'None.' })}<h4>Skipped (${skipped.length})</h4>${table(['Resource', 'Reason'], skipped, { empty: 'None.' })}`)}</div>
    ${card('Metric relationships re-tested on this data', (checks.length ? table(['Metric', 'Formula', ['Computed'], ['Reported'], 'Result'], checks) : '<p class="empty">Not enough data to test.</p>') + '<p class="note">If an array has snapshots, overall efficiency and thin savings may legitimately differ from these simple ratios.</p>', 'wide')}
    ${card('Collector assumptions not yet validated', list(col.provisionalNotes), 'wide')}`;
}

module.exports = { appliances, drives, hosts, storage, protection, alerts, collection };

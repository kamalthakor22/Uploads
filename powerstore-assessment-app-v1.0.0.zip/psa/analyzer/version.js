'use strict';
module.exports = { ANALYZER_VERSION: '0.3.0' };

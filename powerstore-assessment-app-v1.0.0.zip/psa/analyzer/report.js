'use strict';
// Self-contained, script-free HTML report laid out like PowerStore Manager: one
// dashboard per tab. Tabs and toggles are CSS-only, so the file also works when
// scripts are stripped. Print shows every dashboard in sequence.

const { esc } = require('./format');
const { switcher, switcherCss } = require('./ui');
const { healthChecklist } = require('./rules');
const core = require('./views-core');
const infra = require('./views-infra');

const CSS = `
:root{--bg:#f2f3f5;--fg:#1b1f24;--muted:#5b6570;--line:#d7dce1;--card:#fff;--soft:#f5f7f9;--accent:#0672cb;--accent-fg:#fff;--ok:#1e8e3e;--warn:#b54708;--bad:#b42318;--info:#175cd3;
--c-total:#1aa39a;--c-read:#7b3fa0;--c-write:#2f7fd3;--c-peak:#e0752d;--c-lat:#1b1f24;--c-phys:#1b1f24;--c-used:#0672cb;--c-fc:#8a8f98;--f1:#12355b;--f2:#8ec1e8;--f3:#0672cb;--head:#0672cb}
@media (prefers-color-scheme:dark){:root{--bg:#101418;--fg:#e6e9ed;--muted:#9aa5b1;--line:#2c343d;--card:#171c22;--soft:#1d242c;--accent:#4aa3f0;--accent-fg:#0b1218;--ok:#6fd08a;--warn:#ffb74d;--bad:#ff8a80;--info:#82b1ff;
--c-total:#3ccfc4;--c-read:#b784d6;--c-write:#6aaeff;--c-peak:#ff9a56;--c-lat:#e6e9ed;--c-phys:#e6e9ed;--c-used:#4aa3f0;--c-fc:#8a8f98;--f1:#7ab0e0;--f2:#2c4a66;--f3:#4aa3f0;--head:#0b3f73}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
header.top{background:var(--head);color:#fff;padding:10px 20px;display:flex;gap:16px;align-items:baseline;flex-wrap:wrap}
header.top b{font-size:17px;font-weight:600}header.top b.cust{font-weight:400;padding-left:14px;border-left:1px solid rgba(255,255,255,.45)}header.top span{opacity:.85;font-size:13px}
main{padding:0 20px 28px;max-width:1280px;margin:0 auto}
h2{font-size:22px;font-weight:400;margin:18px 0 12px}h3{font-size:15px;margin:0 0 8px;font-weight:600}h4{font-size:13px;margin:12px 0 6px;color:var(--muted);font-weight:600}
h3 small,h4 small{font-weight:400;color:var(--muted)}
.muted,.note,small,.sub{color:var(--muted)}.note{font-size:12px;margin:6px 0}.empty{color:var(--muted);font-style:italic}
code{font-size:12px}
.tabs>.swbar{display:flex;flex-wrap:wrap;gap:0;background:var(--card);border-bottom:1px solid var(--line);margin:0 -20px;padding:0 20px;position:sticky;top:0;z-index:5}
.tabs>.swbar>label{padding:11px 14px;cursor:pointer;border-bottom:3px solid transparent;color:var(--fg);font-size:14px;background:none;border-radius:0}
.tabs>input:checked~.swbar>label{background:none}
.pill>.swbar{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}.pill>.swbar>label{padding:3px 11px;border:1px solid var(--line);border-radius:14px;cursor:pointer;font-size:12px;background:var(--soft)}
.pill.small>.swbar>label{padding:2px 9px;font-size:11px}
.card{background:var(--card);border:1px solid var(--line);border-radius:4px;padding:12px 16px;margin:0 0 16px;min-width:0}
.card.wide{width:100%}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:16px}.grid2>.card{margin:0}
.grid4{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin-bottom:12px}.grid4>.card{margin:0}
.cols4{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:0}.cols4>div{padding:0 18px;border-left:1px solid var(--line)}.cols4>div:first-child{border-left:0;padding-left:0}
.stats{display:flex;gap:22px;flex-wrap:wrap}.stat{text-align:center;min-width:64px}.stat b{display:block;font-size:24px;font-weight:300;color:var(--info);line-height:1.2}.stat span{font-size:12px;color:var(--muted)}
.stat.ok b{color:var(--ok)}.stat.warn b{color:var(--warn)}.stat.bad b{color:var(--bad)}
.cards{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 16px}.cards>.stat{background:var(--card);border:1px solid var(--line);border-radius:4px;padding:10px 18px}
.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.tile{text-align:left}.tile b{display:block;font-size:22px;font-weight:300;color:var(--info)}.tile span{font-size:12px;color:var(--muted)}
.healthgrid{display:flex;gap:28px;align-items:center;flex-wrap:wrap}.issues b{display:block;font-size:34px;font-weight:300}.issues span{color:var(--muted);font-size:12px}
.checks{list-style:none;padding:0;margin:0}.checks li{padding:2px 0}
.st b{font-weight:700}.st-ok{color:var(--ok)}.st-warn{color:var(--warn)}.st-bad{color:var(--bad)}.st-info{color:var(--info)}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border-bottom:1px solid var(--line);padding:6px 9px;text-align:left;vertical-align:top}th{background:var(--soft);font-weight:600;white-space:nowrap}
td.r,th.r{text-align:right}table.kv th{background:none;border:0;padding:3px 10px 3px 0}table.kv td{border:0;padding:3px 0}table.kv .sub{padding-left:14px}
.bar{display:inline-block;width:70px;height:8px;background:var(--line);border-radius:4px;vertical-align:middle;margin-right:6px;overflow:hidden}.bar i{display:block;height:100%;background:var(--ok)}.bar.warn i{background:var(--warn)}.bar.bad i{background:var(--bad)}
.capwrap{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.donut{width:150px;height:150px}.capmini{display:flex;gap:12px;align-items:center}.capmini .donut{width:90px;height:90px}
.dn-free,.dn-used{fill:none;stroke-width:18}.dn-free{stroke:var(--line)}.dn-used{stroke:var(--accent)}.dn-t{font-size:30px;fill:var(--fg);font-weight:300}.dn-s{font-size:13px;fill:var(--muted)}
.savings{display:flex;gap:24px;flex-wrap:wrap;align-items:center}.savings dl{margin:0;min-width:300px}.savings dl div{display:flex;justify-content:space-between;gap:20px;padding:2px 0;border-bottom:1px solid var(--line)}.savings dt{color:var(--muted);white-space:nowrap}.savings dd{margin:0;font-weight:600}
.funnel{width:300px;max-width:100%}.f1{fill:var(--f1)}.f2{fill:var(--f2)}.f3{fill:var(--f3)}.lg i.f1b{background:var(--f1)}.lg i.f2b{background:var(--f2)}.lg i.f3b{background:var(--f3)}
.panel{margin:0 0 6px}.panel figcaption{font-size:12px;color:var(--muted);margin-bottom:2px}.chart{width:100%;height:auto;display:block}
.grid{stroke:var(--line);stroke-width:1}.ax{fill:var(--muted);font-size:10px}.ln{fill:none;stroke-width:1.6;stroke-linejoin:round}.area{opacity:.14;stroke:none}.ln.dash{stroke-dasharray:5 4}
.s-total{stroke:var(--c-total)}.s-read{stroke:var(--c-read)}.s-write{stroke:var(--c-write)}.s-peak{stroke:var(--c-peak)}.s-lat{stroke:var(--c-lat)}.s-phys{stroke:var(--c-phys)}.s-used{stroke:var(--c-used)}.s-fc{stroke:var(--c-fc)}
.area.s-total{fill:var(--c-total)}.area.s-read{fill:var(--c-read)}.area.s-write{fill:var(--c-write)}.area.s-lat{fill:var(--c-lat)}.area.s-used{fill:var(--c-used)}.area.s-phys{fill:var(--c-phys)}
.lg{display:flex;flex-wrap:wrap;gap:14px;font-size:12px;margin:2px 0 4px}.lg i{display:inline-block;width:16px;height:3px;margin-right:5px;vertical-align:middle}
.lg i.s-total{background:var(--c-total)}.lg i.s-read{background:var(--c-read)}.lg i.s-write{background:var(--c-write)}.lg i.s-peak{background:var(--c-peak)}.lg i.s-lat{background:var(--c-lat)}.lg i.s-phys{background:var(--c-phys)}.lg i.s-used{background:var(--c-used)}.lg i.s-fc{background:none;border-top:3px dashed var(--c-fc);height:0}.lg i.dash{background:none;border-top:3px dashed currentColor;height:0}
ul.findings{list-style:none;padding:0}ul.findings li{border:1px solid var(--line);border-left-width:5px;border-radius:4px;padding:8px 12px;margin:8px 0;background:var(--card)}
.sev-action{border-left-color:var(--bad)}.sev-attention{border-left-color:var(--warn)}.sev-info{border-left-color:var(--info)}
.badge{font-size:11px;font-weight:700;letter-spacing:.04em}.sev-action .badge{color:var(--bad)}.sev-attention .badge{color:var(--warn)}.sev-info .badge{color:var(--info)}
.cat{font-size:11px;color:var(--muted);text-transform:uppercase;margin-right:6px}li p{margin:4px 0}.ev{font-size:12px;color:var(--muted)}
ul.mini{list-style:none;padding:0;margin:0}ul.mini li{padding:3px 0 3px 10px;border-left:4px solid var(--line);margin:4px 0}ul.mini li.sev-action{border-left-color:var(--bad)}ul.mini li.sev-attention{border-left-color:var(--warn)}
.appl{margin-bottom:24px}
@media (max-width:760px){.tiles{grid-template-columns:repeat(2,1fr)}.cols4>div{border-left:0;padding:8px 0}}
@media print{body{background:#fff}.sw>.swpanes>.pane{display:block!important;page-break-inside:avoid}.sw>.swbar{display:none}.tabs>.swpanes>.pane{page-break-before:always}header.top{color:#000;background:#fff}}
${switcherCss()}`;

function render(model, findings) {
  const inv = model.inventory;
  const a0 = inv.appliances[0] || {};
  const col = model.collection;
  const health = healthChecklist(findings);
  const nonInfo = findings.filter((f) => f.severity !== 'info').length;
  const S = model.storage;

  const tabs = [
    { label: 'Overview', html: core.overview(model, findings, health) },
    { label: `Signals (${nonInfo}/${findings.length})`, html: core.signals(findings) },
    { label: 'Capacity', html: core.capacity(model) },
    { label: 'Growth', html: core.growth(model) },
    { label: 'Performance', html: core.performance(model) },
    { label: 'Appliances', html: infra.appliances(model) },
    { label: 'Drives', html: infra.drives(model) },
    { label: 'Hosts', html: infra.hosts(model) },
    { label: 'Storage', html: infra.storage(model) },
    { label: 'Protection', html: infra.protection(model) },
    { label: `Alerts${S.have.alert ? ` (${S.alerts.active})` : ''}`, html: infra.alerts(model) },
    { label: 'Collection', html: infra.collection(model) },
  ];
  const customer = col.customer || '';
  const title = `PowerStore assessment - ${customer ? customer + ' - ' : ''}${inv.cluster ? inv.cluster.name : 'unknown cluster'}`;
  const sub = [a0.model, a0.serviceTag ? `service tag ${a0.serviceTag}` : null, `PowerStoreOS ${(col.detectedOS || []).join(', ') || 'unknown'}`, `collected ${String(col.startedAt || '').replace('T', ' ').replace(/(\.\d+)?Z$/, ' UTC')}`, `pstore-assess ${col.tool && col.tool.version}`, col.analyzerVersion ? `analyzer ${col.analyzerVersion}` : null].filter(Boolean).join(' \u00b7 ');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<style>${CSS}</style></head><body>
<header class="top"><b>PowerStore Assessment</b>${customer ? `<b class="cust">${esc(customer)}</b>` : ''}<span>${esc(inv.cluster ? inv.cluster.name : '')}</span><span>${esc(sub)}</span></header>
<main>
${switcher(tabs, 'tabs')}
</main>
</body></html>
`;
}

module.exports = { render };

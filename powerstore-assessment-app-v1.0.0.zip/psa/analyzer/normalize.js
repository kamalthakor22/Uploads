'use strict';
// Turns a raw collector bundle into a normalized PowerStore model.
//
// Field names and relationships below were VALIDATED on PowerStoreOS 4.4.0.0
// (PowerStore 500T). On other releases, checkDefinitions() re-tests the
// efficiency relationships against the data and reports drift instead of
// silently trusting them.

const DAY_MS = 86400000;

// ---------------------------------------------------------------------------
// Loading
// ---------------------------------------------------------------------------

/** Parse a bundle file; counts integers above 2^53 that JSON.parse had to round. */
function parseBundle(text) {
  let unsafeInts = 0;
  const bundle = JSON.parse(text, (k, v, ctx) => {
    if (typeof v === 'number' && ctx && typeof ctx.source === 'string' && /^-?\d+$/.test(ctx.source) && !Number.isSafeInteger(v)) unsafeInts++;
    return v;
  });
  if (!bundle || !Array.isArray(bundle.records)) throw new Error('not a pstore-assess bundle (no records array)');
  if (bundle.vendor !== 'dell-powerstore') throw new Error(`unsupported vendor ${JSON.stringify(bundle.vendor)}`);
  return { bundle, unsafeInts };
}

// ---------------------------------------------------------------------------
// Record helpers
// ---------------------------------------------------------------------------

const ok = (r) => !r.error && r.status >= 200 && r.status < 300;

/** Concatenate the bodies of all successful GETs for a path (handles paged reads). */
function getCollection(bundle, path, queryTest = () => true) {
  const out = [];
  for (const r of bundle.records) {
    if (r.method === 'GET' && r.path === path && ok(r) && Array.isArray(r.body) && queryTest(r.query || '')) out.push(...r.body);
  }
  return out;
}

function metricPoints(bundle, entity, entityId, interval) {
  const out = [];
  for (const r of bundle.records) {
    const q = r.request_body;
    if (r.method === 'POST' && r.path === '/metrics/generate' && ok(r) && q && q.entity === entity && q.entity_id === entityId && q.interval === interval && Array.isArray(r.body)) {
      out.push(...r.body);
    }
  }
  return out.sort((a, b) => (a.timestamp < b.timestamp ? -1 : a.timestamp > b.timestamp ? 1 : 0));
}

// Plain samples carry "x"; rollups carry "last_x" and "max_x".
const val = (p, f) => (p[f] !== undefined ? p[f] : p['last_' + f]);
const peakOf = (p, f) => (p['max_' + f] !== undefined ? p['max_' + f] : p[f]);

const num = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : null);
const mean = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);

function percentile(xs, p) {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.ceil((p / 100) * s.length) - 1)];
}

function maxWithTime(points, field) {
  let best = null;
  for (const p of points) {
    const v = num(peakOf(p, field));
    if (v !== null && (best === null || v > best.value)) best = { value: v, at: p.timestamp };
  }
  return best;
}

// ---------------------------------------------------------------------------
// Inventory
// ---------------------------------------------------------------------------

function buildInventory(bundle) {
  const discovery = (q) => !q.includes('(');
  const clusterRaw = getCollection(bundle, '/cluster', discovery)[0] || null;
  const applianceRaw = getCollection(bundle, '/appliance', discovery);
  const probe = getCollection(bundle, '/appliance', (q) => q.includes('software_installed('));
  const nodesRaw = getCollection(bundle, '/node', discovery);
  const hardware = getCollection(bundle, '/hardware', discovery);
  const byId = new Map(hardware.map((h) => [h.id, h]));

  const osByAppliance = new Map(probe.map((a) => [a.id, (a.software_installed || []).map((s) => s.release_version).filter(Boolean)]));

  const appliances = applianceRaw.map((a) => ({
    id: a.id,
    name: a.name,
    model: a.model,
    serviceTag: a.service_tag,
    expressServiceCode: a.express_service_code,
    mode: a.mode,
    nodeCount: a.node_count,
    driveFailureTolerance: a.drive_failure_tolerance_level,
    storageClass: a.storage_class,
    osVersions: osByAppliance.get(a.id) || [],
  }));

  const hwNodes = hardware.filter((h) => h.type === 'Node');
  const nodes = nodesRaw.map((n) => {
    // Join /node to its hardware object by appliance + slot.
    const h = hwNodes.find((x) => x.appliance_id === n.appliance_id && x.slot === n.slot) || {};
    const e = h.extra_details || {};
    return {
      id: n.id,
      applianceId: n.appliance_id,
      slot: n.slot,
      name: h.name || null,
      cpuModel: e.cpu_model || null,
      cpuCores: e.cpu_cores ?? null,
      cpuSockets: e.cpu_sockets ?? null,
      memoryGB: e.physical_memory_size_gb ?? null,
    };
  });

  const enclosureOf = (h) => {
    const p = byId.get(h.parent_id);
    return p ? p.name : null;
  };
  const wear = new Map();
  for (const h of hardware.filter((x) => x.type === 'Drive')) {
    const pts = metricPoints(bundle, 'wear_metrics_by_drive', h.id, 'One_Day');
    const vals = pts.map((p) => num(p.percent_endurance_remaining)).filter((v) => v !== null);
    wear.set(h.id, vals.length ? { latest: vals[vals.length - 1], min: Math.min(...vals), points: vals.length } : null);
  }
  const drives = hardware
    .filter((h) => h.type === 'Drive')
    .map((h) => {
      const e = h.extra_details || {};
      const w = wear.get(h.id);
      return {
        id: h.id,
        name: h.name,
        applianceId: h.appliance_id,
        enclosure: enclosureOf(h),
        slot: h.slot,
        lifecycle: h.lifecycle_state,
        sizeBytes: e.size ?? null,
        driveType: e.drive_type ?? null,
        firmware: e.firmware_version ?? null,
        usage: e.drive_usage_status ?? null,
        encryption: e.encryption_status ?? null,
        fips: e.fips_status ?? null,
        wearLevelUsed: e.drive_wear_level ?? null,
        enduranceRemaining: w ? w.latest : null,
        enduranceMin: w ? w.min : null,
      };
    })
    .sort((a, b) => (a.applianceId + a.slot).localeCompare(b.applianceId + b.slot, undefined, { numeric: true }));

  const groups = new Map();
  for (const d of drives) {
    const k = `${d.driveType}|${d.sizeBytes}`;
    const g = groups.get(k) || { driveType: d.driveType, sizeBytes: d.sizeBytes, count: 0 };
    g.count++;
    groups.set(k, g);
  }

  const componentCounts = {};
  for (const h of hardware) componentCounts[h.type] = (componentCounts[h.type] || 0) + 1;

  // Expansion enclosures were not present on the validation array, so how they
  // appear is unconfirmed: count any non-base "*Enclosure*" hardware type, and
  // report Link_Control_Card objects separately rather than guessing.
  const expansionEnclosures = hardware.filter((h) => /enclosure/i.test(h.type) && h.type !== 'Base_Enclosure').length;

  const unhealthy = hardware
    .filter((h) => h.lifecycle_state && !['Healthy', 'Empty'].includes(h.lifecycle_state))
    .map((h) => ({ name: h.name, type: h.type, state: h.lifecycle_state }));

  return {
    cluster: clusterRaw && {
      id: clusterRaw.id,
      name: clusterRaw.name,
      state: clusterRaw.state,
      managementAddress: clusterRaw.management_address,
      applianceCount: clusterRaw.appliance_count,
      encryptionEnabled: clusterRaw.is_encryption_enabled,
      compatibilityLevel: clusterRaw.compatibility_level,
      systemTime: clusterRaw.system_time,
    },
    appliances,
    nodes,
    enclosures: {
      base: hardware.filter((h) => h.type === 'Base_Enclosure').length,
      expansion: expansionEnclosures,
      linkControlCards: componentCounts.Link_Control_Card || 0,
    },
    drives,
    driveSummary: {
      count: drives.length,
      totalRawBytes: drives.reduce((a, d) => a + (d.sizeBytes || 0), 0),
      groups: [...groups.values()],
    },
    bootDrives: componentCounts.M2_Drive || 0,
    componentCounts,
    unhealthy,
  };
}

// ---------------------------------------------------------------------------
// Capacity and efficiency
// ---------------------------------------------------------------------------

function linearFit(xs, ys) {
  const n = xs.length;
  if (n < 2) return null;
  const mx = mean(xs);
  const my = mean(ys);
  let sxx = 0;
  let sxy = 0;
  let syy = 0;
  for (let i = 0; i < n; i++) {
    sxx += (xs[i] - mx) ** 2;
    sxy += (xs[i] - mx) * (ys[i] - my);
    syy += (ys[i] - my) ** 2;
  }
  if (sxx === 0) return null;
  const slope = sxy / sxx;
  return { slope, intercept: my - slope * mx, r2: syy === 0 ? 1 : (sxy * sxy) / (sxx * syy), n };
}

function buildCapacity(bundle, clusterId, entity = 'space_metrics_by_cluster') {
  const id = clusterId ?? '0';
  const e = entity;
  const five = metricPoints(bundle, e, id, 'Five_Mins');
  const hour = metricPoints(bundle, e, id, 'One_Hour');
  const day = metricPoints(bundle, e, id, 'One_Day');
  const latestPoint = five.at(-1) || hour.at(-1) || day.at(-1) || null;
  if (!latestPoint) return null;

  const g = (f) => num(val(latestPoint, f));
  const latest = {
    at: latestPoint.timestamp,
    source: five.length ? 'Five_Mins' : hour.length ? 'One_Hour' : 'One_Day',
    logicalProvisioned: g('logical_provisioned'),
    logicalUsed: g('logical_used'),
    physicalTotal: g('physical_total'),
    physicalUsed: g('physical_used'),
    dataPhysicalUsed: g('data_physical_used'),
    unreducibleData: g('unreducible_data'),
    overallDRR: g('data_reduction'),
    reducibleDRR: g('reducible_data_reduction'),
    thinSavings: g('thin_savings'),
    snapshotSavings: g('snapshot_savings'),
    efficiencyRatio: g('efficiency_ratio'),
    systemFreeSpace: g('system_free_space'),
  };
  const derived = {
    physicalUsedPct: latest.physicalTotal ? latest.physicalUsed / latest.physicalTotal : null,
    physicalFreeBytes: latest.physicalTotal != null && latest.physicalUsed != null ? latest.physicalTotal - latest.physicalUsed : null,
    // physical_used includes system space on top of user data (data_physical_used).
    systemSpaceBytes: latest.physicalUsed != null && latest.dataPhysicalUsed != null ? latest.physicalUsed - latest.dataPhysicalUsed : null,
    unreducibleShare: latest.dataPhysicalUsed ? (latest.unreducibleData ?? 0) / latest.dataPhysicalUsed : null,
  };

  // Daily history (rollups: last_* values) for growth.
  const daily = day
    .map((p) => ({
      t: Date.parse(p.timestamp),
      date: p.timestamp.slice(0, 10),
      physicalUsed: num(val(p, 'physical_used')),
      physicalTotal: num(val(p, 'physical_total')),
      logicalUsed: num(val(p, 'logical_used')),
      dataPhysicalUsed: num(val(p, 'data_physical_used')),
      overallDRR: num(val(p, 'data_reduction')),
    }))
    .filter((d) => d.physicalTotal > 0 && d.physicalUsed != null);

  let growth = null;
  if (daily.length >= 2) {
    const t0 = daily[0].t;
    const fit = linearFit(daily.map((d) => (d.t - t0) / DAY_MS), daily.map((d) => d.physicalUsed));
    if (fit) {
      const total = latest.physicalTotal;
      const used = latest.physicalUsed;
      const daysTo = (frac) => (used >= frac * total ? 0 : fit.slope > 0 ? (frac * total - used) / fit.slope : null);
      growth = {
        bytesPerDay: fit.slope,
        r2: fit.r2,
        points: fit.n,
        historyDays: Math.round((daily.at(-1).t - t0) / DAY_MS),
        daysTo80: daysTo(0.8),
        daysTo100: daysTo(1.0),
      };
    }
  }

  const peakPhysicalUsed = day.length ? Math.max(...day.map((p) => num(peakOf(p, 'physical_used')) ?? 0)) : null;
  return { entityId: id, latest, derived, growth, daily, peakPhysicalUsed, pointCounts: { Five_Mins: five.length, One_Hour: hour.length, One_Day: day.length } };
}

/** Re-test the efficiency relationships seen on 4.4.0.0 against this bundle's data. */
function checkDefinitions(capacity) {
  if (!capacity) return [];
  const L = capacity.latest;
  const tests = [];
  const add = (name, formula, expected, reported) => {
    if (expected == null || reported == null || !Number.isFinite(expected)) return;
    const rel = reported === 0 ? Math.abs(expected) : Math.abs(expected - reported) / Math.abs(reported);
    tests.push({ name, formula, expected, reported, ok: rel <= 0.02 });
  };
  if (L.dataPhysicalUsed) {
    add('data_reduction (overall DRR)', 'logical_used / data_physical_used', L.logicalUsed / L.dataPhysicalUsed, L.overallDRR);
    add('efficiency_ratio', 'logical_provisioned / data_physical_used', L.logicalProvisioned / L.dataPhysicalUsed, L.efficiencyRatio);
    const redPhys = L.dataPhysicalUsed - (L.unreducibleData ?? 0);
    if (redPhys > 0) add('reducible_data_reduction', '(logical_used - unreducible_data) / (data_physical_used - unreducible_data)', (L.logicalUsed - (L.unreducibleData ?? 0)) / redPhys, L.reducibleDRR);
  }
  if (L.logicalUsed) add('thin_savings', 'logical_provisioned / logical_used', L.logicalProvisioned / L.logicalUsed, L.thinSavings);
  return tests;
}

// ---------------------------------------------------------------------------
// Performance
// ---------------------------------------------------------------------------

const BUCKET = { Five_Mins: { seconds: 300, label: '5-minute buckets (last ~24 h)' }, One_Hour: { seconds: 3600, label: '1-hour buckets (up to ~30 days)' }, One_Day: { seconds: 86400, label: '1-day buckets (up to ~2 years)' } };

function perfWindow(points, interval) {
  if (!points.length) return null;
  const avgIops = points.map((p) => num(p.avg_total_iops)).filter((v) => v !== null);
  const avgBw = points.map((p) => num(p.avg_total_bandwidth)).filter((v) => v !== null);
  const avgLat = points.map((p) => num(p.avg_latency)).filter((v) => v !== null);
  const readIops = points.map((p) => num(p.avg_read_iops)).filter((v) => v !== null);
  const cpuAvg = points.map((p) => num(p.avg_io_workload_cpu_utilization)).filter((v) => v !== null);
  const cpuMax = maxWithTime(points, 'io_workload_cpu_utilization');
  const totalIops = avgIops.reduce((a, b) => a + b, 0);
  return {
    interval,
    bucket: BUCKET[interval],
    points: points.length,
    from: points[0].timestamp,
    to: points.at(-1).timestamp,
    peakIops: maxWithTime(points, 'total_iops'),
    peakReadIops: maxWithTime(points, 'read_iops'),
    peakWriteIops: maxWithTime(points, 'write_iops'),
    peakBandwidth: maxWithTime(points, 'total_bandwidth'), // bytes/s
    worstAvgLatencyUs: maxWithTime(points, 'avg_latency'), // microseconds
    avgIops: mean(avgIops),
    p95AvgIops: percentile(avgIops, 95),
    avgBandwidth: mean(avgBw),
    avgLatencyUs: mean(avgLat),
    readShare: totalIops > 0 ? readIops.reduce((a, b) => a + b, 0) / totalIops : null,
    cpu: cpuAvg.length ? { avg: mean(cpuAvg), max: cpuMax } : null,
  };
}

function perfFor(bundle, entity, id) {
  const windows = {};
  for (const iv of ['Five_Mins', 'One_Hour', 'One_Day']) {
    const w = perfWindow(metricPoints(bundle, entity, id, iv), iv);
    if (w) windows[iv] = w;
  }
  let overallPeakIops = null;
  for (const w of Object.values(windows)) {
    if (w.peakIops && (!overallPeakIops || w.peakIops.value > overallPeakIops.value)) overallPeakIops = { ...w.peakIops, window: w.interval };
  }
  return { entity, id, windows, overallPeakIops };
}

function buildPerformance(bundle, inventory) {
  const clusterId = inventory.cluster ? inventory.cluster.id : '0';
  return {
    cluster: perfFor(bundle, 'performance_metrics_by_cluster', clusterId),
    appliances: inventory.appliances.map((a) => ({ name: a.name, ...perfFor(bundle, 'performance_metrics_by_appliance', a.id) })),
    nodes: inventory.nodes.map((n) => ({ name: n.name || n.id, ...perfFor(bundle, 'performance_metrics_by_node', n.id) })),
  };
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

function normalize(bundle, { unsafeInts = 0 } = {}) {
  const inventory = buildInventory(bundle);
  const capacity = buildCapacity(bundle, inventory.cluster ? inventory.cluster.id : '0');
  const performance = buildPerformance(bundle, inventory);
  const calls = bundle.records.reduce((a, r) => (ok(r) ? { ...a, ok: a.ok + 1 } : { ...a, failed: a.failed + 1 }), { ok: 0, failed: 0 });
  const oldest = capacity && capacity.daily.length ? capacity.daily[0].date : null;
  return {
    collection: {
      tool: bundle.tool,
      schemaVersion: bundle.schema_version,
      host: bundle.target && bundle.target.host,
      user: bundle.target && bundle.target.user,
      tlsVerified: bundle.target && bundle.target.tls_verified,
      startedAt: bundle.started_at,
      finishedAt: bundle.finished_at,
      detectedOS: bundle.detected_os || [],
      calls,
      warnings: bundle.warnings || [],
      provisionalNotes: bundle.provisional_notes || [],
      unsafeIntegers: unsafeInts,
      oldestDailySample: oldest,
      historyDays: capacity && capacity.growth ? capacity.growth.historyDays : null,
    },
    inventory,
    capacity,
    definitionChecks: checkDefinitions(capacity),
    performance,
  };
}

module.exports = {
  parseBundle, normalize, checkDefinitions, linearFit, percentile, metricPoints, getCollection,
  buildCapacity, perfWindow, perfFor, val, peakOf, num, mean, maxWithTime, ok, DAY_MS,
};

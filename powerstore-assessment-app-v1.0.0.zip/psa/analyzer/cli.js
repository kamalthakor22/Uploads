#!/usr/bin/env node
'use strict';
// Analyze a pstore-assess bundle: node analyzer/cli.js <bundle.json> [--out report.html] [--json model.json]

const fs = require('node:fs');
const path = require('node:path');
const { parseArgs } = require('node:util');
const { parseBundle } = require('./normalize');
const { buildModel, exportable } = require('./model');
const { evaluate } = require('./rules');
const { render } = require('./report');

function main(argv) {
  const { values, positionals } = parseArgs({ args: argv, allowPositionals: true, options: { out: { type: 'string' }, json: { type: 'string' }, help: { type: 'boolean', short: 'h' } } });
  if (values.help || positionals.length !== 1) {
    console.error('Usage: node analyzer/cli.js <bundle.json> [--out report.html] [--json model.json]');
    return values.help ? 0 : 2;
  }
  const file = positionals[0];
  let parsed;
  try {
    parsed = parseBundle(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    console.error(`error: ${file}: ${e.message}`);
    return 1;
  }
  const model = buildModel(parsed.bundle, { unsafeInts: parsed.unsafeInts });
  const findings = evaluate(model);
  const out = values.out || path.join(path.dirname(file), path.basename(file, '.json') + '-report.html');
  fs.writeFileSync(out, render(model, findings));
  if (values.json) fs.writeFileSync(values.json, exportable(model, findings));

  const counts = findings.reduce((a, f) => ({ ...a, [f.severity]: (a[f.severity] || 0) + 1 }), {});
  console.error(`Report: ${out}`);
  console.error(`Signals: ${counts.action || 0} action, ${counts.attention || 0} attention, ${counts.info || 0} info`);
  for (const f of findings) console.error(`  [${f.severity}] ${f.title}`);
  return 0;
}

process.exitCode = main(process.argv.slice(2));

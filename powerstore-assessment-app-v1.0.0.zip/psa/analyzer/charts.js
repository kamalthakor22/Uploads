'use strict';
// Static SVG charts (no scripts, no external requests). Colors come from CSS classes so the
// charts follow light/dark mode.

const { esc } = require('./format');

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** points -> [{t, v}] from raw metric points; skips missing values. */
function pts(points, field, scale = 1) {
  const out = [];
  for (const p of points) {
    const v = p[field] !== undefined ? p[field] : p['last_' + field];
    const t = Date.parse(p.timestamp);
    if (typeof v === 'number' && Number.isFinite(v) && Number.isFinite(t)) out.push({ t, v: v * scale });
  }
  return out;
}

/** Reduce to at most `max` points; 'max' keeps spikes, 'avg' smooths. */
function decimate(points, max = 150, mode = 'avg') {
  if (points.length <= max) return points;
  const size = Math.ceil(points.length / max);
  const out = [];
  for (let i = 0; i < points.length; i += size) {
    const b = points.slice(i, i + size);
    const v = mode === 'max' ? Math.max(...b.map((x) => x.v)) : b.reduce((a, x) => a + x.v, 0) / b.length;
    out.push({ t: b[Math.floor(b.length / 2)].t, v });
  }
  return out;
}

function niceStep(raw) {
  const p = 10 ** Math.floor(Math.log10(raw || 1));
  const f = raw / p;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
}

function xLabel(t, spanMs) {
  const d = new Date(t);
  const p = (n) => String(n).padStart(2, '0');
  if (spanMs <= 36 * 3600e3) return `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`;
  if (spanMs <= 120 * 86400e3) return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]}`;
  return `${MONTHS[d.getUTCMonth()]} ${String(d.getUTCFullYear()).slice(2)}`;
}

/**
 * series: [{name, cls, points:[{t,v}], dash?:bool, area?:bool, mode?:'avg'|'max'}]
 * Gaps (missing buckets) break the line instead of being interpolated.
 */
function lineChart({ series, yFmt = (v) => String(v), height = 190, label = 'chart', yMax = null, xRange = null }) {
  const W = 900;
  const L = 64;
  const R = 12;
  const T = 8;
  const B = 24;
  const live = series.filter((s) => s.points.length);
  if (!live.length) return '<p class="empty">No data points for this view.</p>';
  const drawn = live.map((s) => ({ ...s, points: decimate(s.points, 150, s.mode || 'avg') }));
  const all = drawn.flatMap((s) => s.points);
  const tmin = xRange ? xRange[0] : Math.min(...all.map((p) => p.t));
  const tmax = xRange ? xRange[1] : Math.max(...all.map((p) => p.t));
  const vmax = yMax != null ? yMax : Math.max(...all.map((p) => p.v), 0);
  const step = niceStep((vmax || 1) / 4);
  const top = Math.max(step, Math.ceil((vmax || 1) / step) * step);
  const X = (t) => L + (tmax === tmin ? (W - L - R) / 2 : ((t - tmin) / (tmax - tmin)) * (W - L - R));
  const Y = (v) => T + (1 - v / top) * (height - T - B);

  let g = '';
  for (let v = 0; v <= top + step / 100; v += step) {
    g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}"/><text class="ax" x="${L - 6}" y="${(Y(v) + 3).toFixed(1)}" text-anchor="end">${esc(yFmt(v, step))}</text>`;
  }
  const span = tmax - tmin;
  for (let k = 0; k <= 5; k++) {
    const t = tmin + (span * k) / 5;
    g += `<text class="ax" x="${X(t).toFixed(1)}" y="${height - 6}" text-anchor="${k === 0 ? 'start' : k === 5 ? 'end' : 'middle'}">${esc(xLabel(t, span))}</text>`;
  }
  for (const s of drawn) {
    const dts = s.points.slice(1).map((p, i) => p.t - s.points[i].t).sort((a, b) => a - b);
    const gap = (dts[Math.floor(dts.length / 2)] || 1) * 2.5;
    let d = '';
    let areaD = '';
    s.points.forEach((p, i) => {
      const brk = i === 0 || (!s.continuous && p.t - s.points[i - 1].t > gap);
      d += `${brk ? 'M' : 'L'}${X(p.t).toFixed(1)} ${Y(p.v).toFixed(1)}`;
      if (s.area) areaD += `${brk ? `${i ? 'L' + X(s.points[i - 1].t).toFixed(1) + ' ' + Y(0) + ' ' : ''}M${X(p.t).toFixed(1)} ${Y(0)} ` : ''}L${X(p.t).toFixed(1)} ${Y(p.v).toFixed(1)}`;
    });
    if (s.area && s.points.length > 1) g += `<path class="area ${s.cls}" d="${areaD}L${X(s.points.at(-1).t).toFixed(1)} ${Y(0)}Z"/>`;
    g += `<path class="ln ${s.cls}${s.dash ? ' dash' : ''}" d="${d}"><title>${esc(s.name)}</title></path>`;
  }
  return `<svg class="chart" viewBox="0 0 ${W} ${height}" role="img" aria-label="${esc(label)}" preserveAspectRatio="xMidYMid meet">${g}</svg>`;
}

const legend = (series) => `<div class="lg">${series.filter((s) => s.points.length).map((s) => `<span><i class="${s.cls}${s.dash ? ' dash' : ''}"></i>${esc(s.name)}</span>`).join('')}</div>`;

const panel = (title, series, opts) => `<figure class="panel"><figcaption>${esc(title)}</figcaption>${legend(series)}${lineChart({ series, label: title, ...opts })}</figure>`;

/** Donut: `frac` of the ring is "used". */
function donut(frac, centerText, sub = 'Used') {
  const r = 70;
  const c = 2 * Math.PI * r;
  const f = Math.max(0, Math.min(1, frac || 0));
  return `<svg class="donut" viewBox="0 0 180 180" role="img" aria-label="${esc(centerText)} ${esc(sub)}"><circle class="dn-free" cx="90" cy="90" r="${r}"/><circle class="dn-used" cx="90" cy="90" r="${r}" stroke-dasharray="${(c * f).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 90 90)"/><text class="dn-t" x="90" y="92" text-anchor="middle">${esc(centerText)}</text><text class="dn-s" x="90" y="112" text-anchor="middle">${esc(sub)}</text></svg>`;
}

/** Logical used -> data reduction -> physical used, like PowerStore Manager's Data Savings panel. */
function savingsFunnel(logical, physical) {
  if (!logical || physical == null) return '';
  const H = 110;
  const h2 = Math.max(4, (physical / logical) * H);
  const y2 = (H - h2) / 2 + 10;
  return `<svg class="funnel" viewBox="0 0 420 140" role="img" aria-label="Logical used to physical used"><rect class="f1" x="0" y="10" width="90" height="${H}"/><polygon class="f2" points="90,10 300,${y2} 300,${y2 + h2} 90,${10 + H}"/><rect class="f3" x="300" y="${y2}" width="90" height="${h2}"/></svg>`;
}

module.exports = { pts, lineChart, panel, legend, donut, savingsFunnel, decimate };

'use strict';
// Dashboards modelled on PowerStore Manager: Overview, Signals, Capacity, Growth, Performance.

const { esc, n2, ratio, ms, mibs, kiops, kib, when, day, dash, days, fmtBytes, pct } = require('./format');
const { switcher, table, bar, status, card, stat, na } = require('./ui');
const { pts, panel, donut, savingsFunnel, lineChart, legend } = require('./charts');
const { THRESHOLDS } = require('./rules');

const TIB = 1024 ** 4;
const tib = (b) => (b == null ? 'n/a' : `${n2(b / TIB, 2)} TiB`);
const axisBytes = (v) => {
  const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
  let i = 0;
  let x = v;
  while (Math.abs(x) >= 1024 && i < u.length - 1) { x /= 1024; i++; }
  return `${x.toFixed(x < 10 && i > 0 ? 1 : 0)} ${u[i]}`;
};

// ---------------------------------------------------------------------------
// Overview
// ---------------------------------------------------------------------------

function overview(model, findings, health) {
  const inv = model.inventory;
  const S = model.storage;
  const cap = model.capacity;
  const L = S.latest.cluster;
  const offline = inv.unhealthy.filter((u) => u.type === 'Appliance').length;
  const online = inv.appliances.length - offline;

  const summary = `<div class="cols4">
    <div><h4>Appliances</h4><div class="stats">${stat(esc(online), 'Online', 'ok')}${stat(esc(offline), 'Not healthy', offline ? 'warn' : '')}</div></div>
    <div><h4>Capacity</h4><div class="stats">${stat(cap ? pct(cap.derived.physicalUsedPct) : 'n/a', 'Used')}${stat(cap ? pct(1 - cap.derived.physicalUsedPct) : 'n/a', 'Free')}${stat(cap ? tib(cap.latest.physicalTotal) : 'n/a', 'Physical')}</div></div>
    <div><h4>Performance <small>(latest ${L ? esc(L.interval === 'Five_Mins' ? '5-min' : L.interval) : ''} sample)</small></h4><div class="stats">${stat(L ? ms(L.latencyUs) : 'n/a', 'Latency')}${stat(L ? kiops(L.iops) : 'n/a', 'IOPS')}${stat(L ? mibs(L.bandwidth) : 'n/a', 'Bandwidth')}</div></div>
    <div><h4>Alerts <small>(active)</small></h4>${S.have.alert ? `<div class="stats">${stat(S.alerts.counts.Critical, 'Critical', S.alerts.counts.Critical ? 'bad' : '')}${stat(S.alerts.counts.Major, 'Major', S.alerts.counts.Major ? 'warn' : '')}${stat(S.alerts.counts.Minor, 'Minor')}</div>` : '<p class="empty">Alerts not collected.</p>'}</div>
  </div>`;

  const issues = health.reduce((a, h) => a + h.issues, 0);
  const healthCard = `<div class="healthgrid"><div class="issues"><b>${issues}</b><span>${issues === 1 ? 'issue' : 'issues'} flagged</span></div><ul class="checks">${health
    .map((h) => `<li>${status(h.status === 'ok' ? 'ok' : h.status === 'action' ? 'bad' : 'warn', h.name)}${h.issues ? ` <span class="muted">${h.issues} signal${h.issues === 1 ? '' : 's'}</span>` : ''}</li>`)
    .join('')}</ul></div>
    <p class="note">This is the assessment's own view, built from the Signals tab. PowerStore Manager's numeric health score is not available through the REST resources this tool reads.</p>`;

  const c = S.inventoryCounts;
  const tile = (n, label, have) => `<div class="tile"><b>${have ? esc(n) : '&ndash;'}</b><span>${esc(label)}</span></div>`;
  const inventory = `<div class="tiles">${tile(c.volumeGroups, 'Volume groups', S.have.volume_group)}${tile(c.volumes, 'Volumes', S.have.volume)}${tile(c.hosts, 'Hosts', S.have.host)}${tile(c.virtualMachines, 'Virtual machines', S.have.virtual_machine)}${tile(c.fileSystems, 'File systems', S.have.file_system)}${tile(c.smbShares, 'SMB shares', S.have.smb_share)}${tile(c.nfsExports, 'NFS exports', S.have.nfs_export)}${tile(c.nasServers, 'NAS servers', S.have.nas_server)}</div>`;

  const top = findings.filter((f) => f.severity !== 'info').slice(0, 5);
  const topHtml = top.length
    ? `<ul class="mini">${top.map((f) => `<li class="sev-${f.severity}"><b>${esc(f.severity.toUpperCase())}</b> ${esc(f.title)}</li>`).join('')}</ul>`
    : '<p class="empty">No action or attention signals.</p>';

  return `<h2>Overview</h2>
    ${card('Summary', summary, 'wide')}
    <div class="grid2">${card('Health (assessment view)', healthCard)}${card('Inventory', inventory)}</div>
    ${card('Top signals', topHtml + '<p class="note">Open the Signals tab for all signals and their evidence.</p>', 'wide')}`;
}

// ---------------------------------------------------------------------------
// Signals
// ---------------------------------------------------------------------------

function signals(findings) {
  const groups = ['action', 'attention', 'info'];
  const label = { action: 'Action', attention: 'Attention', info: 'Information' };
  const item = (f) => `<li class="sev-${f.severity}"><span class="badge">${esc(label[f.severity].toUpperCase())}</span> <span class="cat">${esc(f.category)}</span>
    <strong>${esc(f.title)}</strong><p>${esc(f.detail)}</p>
    <p class="ev">${Object.entries(f.evidence || {}).map(([k, v]) => `${esc(k)}: <code>${esc(v)}</code>`).join(' &middot; ')}</p></li>`;
  const body = groups
    .map((g) => {
      const items = findings.filter((f) => f.severity === g);
      return items.length ? `<h3>${label[g]} (${items.length})</h3><ul class="findings">${items.map(item).join('')}</ul>` : '';
    })
    .join('');
  return `<h2>Signals</h2><p class="note">Starting points for conversations, derived from the collected data. Thresholds are provisional (see <code>analyzer/rules.js</code>) and meant to be tuned after real customer runs.</p>${body || '<p class="empty">No signals.</p>'}`;
}

// ---------------------------------------------------------------------------
// Capacity
// ---------------------------------------------------------------------------

function usageChart(model) {
  const S = model.storage;
  const g = S.growth.cluster && S.growth.cluster.physical;
  const items = Object.entries(S.timeline.space).map(([label, t]) => {
    const phys = pts(t.points, 'physical_total');
    const used = pts(t.points, 'physical_used');
    const series = [
      { name: 'Physical', cls: 's-phys', points: phys, continuous: true },
      { name: 'Used', cls: 's-used', points: used, area: true },
    ];
    let xRange = null;
    if (g && used.length && /month|years/.test(label)) {
      const last = used.at(-1);
      const horizon = (label === 'Last 2 years' ? 365 : 90) * 86400e3;
      const slope = g.bytesPerDay / 86400e3;
      const cap = phys.at(-1) ? phys.at(-1).v : null;
      const proj = [last, { t: last.t + horizon, v: cap != null ? Math.min(cap * 1.02, last.v + slope * horizon) : last.v + slope * horizon }];
      series.push({ name: 'Forecast (linear fit)', cls: 's-fc', points: proj, dash: true });
      xRange = [Math.min(...phys.concat(used).map((p) => p.t)), last.t + horizon];
      if (phys.length) phys.push({ t: xRange[1], v: phys.at(-1).v });
    }
    return { label, html: `${legend(series)}${lineChart({ series, yFmt: axisBytes, label: `Physical capacity history, ${label}`, xRange })}<p class="note">${esc(t.bucket)} samples${xRange ? '. The forecast is this tool\'s linear projection, not Dell\'s.' : ''}</p>` };
  });
  const month = items.findIndex((i) => i.label === 'Last 1 month');
  return items.length ? switcher(items, 'pill', month >= 0 ? month : 0) : '<p class="empty">No capacity history in this bundle.</p>';
}

function dataSavings(cap) {
  const L = cap.latest;
  const total = L.logicalUsed != null && L.dataPhysicalUsed != null ? L.logicalUsed - L.dataPhysicalUsed : null;
  const rows = [
    ['Overall DRR', ratio(L.overallDRR)], ['Reducible DRR', ratio(L.reducibleDRR)], ['Unreducible data', fmtBytes(L.unreducibleData)], ['Total savings', fmtBytes(total)],
    ['Overall efficiency', ratio(L.efficiencyRatio)], ['Snap savings', ratio(L.snapshotSavings)], ['Thin savings', ratio(L.thinSavings)],
  ];
  return `<div class="savings"><dl>${rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
    <div>${savingsFunnel(L.logicalUsed, L.dataPhysicalUsed)}<div class="lg"><span><i class="f1b"></i>Logical used ${esc(fmtBytes(L.logicalUsed))}</span><span><i class="f2b"></i>Data reduction</span><span><i class="f3b"></i>Physical used ${esc(fmtBytes(L.dataPhysicalUsed))}</span></div></div></div>
    <p class="note">Overall DRR = logical used / data physical used (includes unreducible data); reducible DRR excludes it. Overall efficiency, thin and snapshot savings are the array's own figures (checked against these relationships on 4.4.0.0 without snapshots; the Collection tab re-tests them for this bundle).</p>`;
}

function capacity(model) {
  const cap = model.capacity;
  const S = model.storage;
  if (!cap) return `<h2>Capacity</h2>${na('Space metrics')}`;
  const L = cap.latest;
  const D = cap.derived;
  const freeSys = L.systemFreeSpace;
  const freeUser = D.physicalFreeBytes != null && freeSys != null ? D.physicalFreeBytes - freeSys : null;
  const physical = `<div class="capwrap">${donut(D.physicalUsedPct, pct(D.physicalUsedPct, 1))}
    <table class="kv"><tbody>
      <tr><th>Used</th><td>${fmtBytes(L.physicalUsed)}</td></tr><tr><td class="sub">User</td><td>${fmtBytes(L.dataPhysicalUsed)}</td></tr><tr><td class="sub">System</td><td>${fmtBytes(D.systemSpaceBytes)}</td></tr>
      <tr><th>Free</th><td>${fmtBytes(D.physicalFreeBytes)}</td></tr>${freeUser != null ? `<tr><td class="sub">User</td><td>${fmtBytes(freeUser)}</td></tr><tr><td class="sub">System</td><td>${fmtBytes(freeSys)}</td></tr>` : ''}
      <tr><th>Physical total</th><td>${fmtBytes(L.physicalTotal)}</td></tr></tbody></table></div>
    <p class="note">Sampled ${esc(when(L.at))}. Sizes use binary units (KiB, MiB, GiB, TiB). User = data physical used; System = physical used minus user data.</p>`;

  const vols = S.volumes.topConsumers;
  const consumers = switcher(
    [
      { label: 'Volume', html: S.have.volume ? table(['Volume name', ['Logical used'], ['Provisioned']], vols.map((v) => [esc(v.name), fmtBytes(v.logicalUsedBytes), fmtBytes(v.sizeBytes)]), { empty: 'No volumes.' }) : na('Volumes') },
      { label: 'File system', html: S.have.file_system ? table(['File system', ['Size used'], ['Total size']], [...S.file.fileSystems].sort((a, b) => (b.sizeUsedBytes || 0) - (a.sizeUsedBytes || 0)).slice(0, 10).map((f) => [esc(f.name), fmtBytes(f.sizeUsedBytes), fmtBytes(f.sizeTotalBytes)]), { empty: 'No file systems.' }) : na('File systems') },
    ],
    'pill',
  );

  return `<h2>Capacity</h2>
    <div class="grid2">${card('Physical capacity', physical)}${card('Historical usage', usageChart(model))}</div>
    <div class="grid2">${card('Top consumers', consumers)}${card('Data savings', dataSavings(cap))}</div>`;
}

// ---------------------------------------------------------------------------
// Growth
// ---------------------------------------------------------------------------

function growthRows(scope, g) {
  const rows = [];
  const add = (metric, x, thresholds) => {
    if (!x) { rows.push([esc(scope), esc(metric), '&ndash;', '&ndash;', '&ndash;', '&ndash;', '&ndash;', '&ndash;', '&ndash;', '&ndash;', '&ndash;']); return; }
    const reliable = x.historyDays >= THRESHOLDS.forecastMinHistoryDays && x.r2 >= THRESHOLDS.forecastMinR2;
    const cell = (d) => (thresholds ? esc(days(d)) : '&ndash;');
    rows.push([
      esc(scope), esc(metric), fmtBytes(x.used), `${x.bytesPerDay >= 0 ? '+' : '-'}${fmtBytes(Math.abs(x.bytesPerDay))}`, `${x.bytesPerDay >= 0 ? '+' : '-'}${fmtBytes(Math.abs(x.bytesPerDay) * 30)}`,
      esc(`${x.historyDays} d`), n2(x.r2, 2), reliable ? status('ok', 'usable') : status('warn', 'low'), cell(x.daysTo80), cell(x.daysTo90), cell(x.daysTo100),
    ]);
  };
  add('Physical used', g.physical, true);
  add('Logical used', g.logical, false);
  add('User data (physical)', g.user, false);
  add('System space', g.system, false);
  return rows;
}

function growth(model) {
  const S = model.storage;
  const G = S.growth;
  if (!G.cluster) return `<h2>Growth rate</h2>${na('Capacity history')}`;
  const head = ['Scope', 'Metric', ['Current'], ['Per day'], ['Per 30 days'], ['History'], ['R&sup2;'.replace('&sup2;', '2')], 'Fit', ['To 80%'], ['To 90%'], ['To 100%']];
  const rows = [...growthRows('Cluster', G.cluster), ...(G.appliances.length > 1 ? G.appliances.flatMap((a) => growthRows(a.name, a)) : [])];

  // Forecast chart from the daily history.
  const d = model.capacity.daily;
  const g = G.cluster.physical;
  let chart = '<p class="empty">Not enough daily history to chart a trend.</p>';
  if (g && d.length >= 2) {
    const used = d.map((x) => ({ t: x.t, v: x.physicalUsed }));
    const total = d.map((x) => ({ t: x.t, v: x.physicalTotal }));
    const last = used.at(-1);
    const horizon = 180 * 86400e3;
    const proj = [last, { t: last.t + horizon, v: Math.min(model.capacity.latest.physicalTotal * 1.02, last.v + (g.bytesPerDay / 86400e3) * horizon) }];
    total.push({ t: last.t + horizon, v: total.at(-1).v });
    const series = [{ name: 'Physical total', cls: 's-phys', points: total, continuous: true }, { name: 'Physical used', cls: 's-used', points: used, area: true }, { name: 'Forecast, 180 days (linear fit)', cls: 's-fc', points: proj, dash: true }];
    chart = `${legend(series)}${lineChart({ series, yFmt: axisBytes, label: 'Physical used with forecast', xRange: [used[0].t, last.t + horizon] })}`;
  }

  const vm = S.volumeMetrics.filter((v) => v.growth).sort((a, b) => b.growth.bytesPerDay - a.growth.bytesPerDay);
  const vTable = S.volumeMetrics.length
    ? table(['Volume', ['Logical used'], ['Growth / day'], ['% / day'], ['History'], ['Peak IOPS'], ['Avg latency']], vm.slice(0, 15).map((v) => [esc(v.name), fmtBytes(v.logicalUsedBytes), `${v.growth.bytesPerDay >= 0 ? '+' : '-'}${fmtBytes(Math.abs(v.growth.bytesPerDay))}`, v.growth.pctPerDay == null ? 'n/a' : `${n2(v.growth.pctPerDay * 100, 2)}%`, esc(`${v.growth.days} d`), v.peakIops ? n2(v.peakIops.value, 1) : 'n/a', ms(v.avgLatencyUs)]), { empty: 'No volumes with usable history.' })
    : na('Per-volume space metrics');

  return `<h2>Growth rate</h2>
    ${card('Capacity growth and forecast', `${table(head, rows)}<p class="note">Linear fits over the daily history (R2 = goodness of fit). "To 80/90/100%" apply to physical used against physical total. Fits with under ${THRESHOLDS.forecastMinHistoryDays} days of history or R2 below ${THRESHOLDS.forecastMinR2} are marked low confidence. On new arrays, growth is often dominated by system space rather than user data.</p>`, 'wide')}
    ${card('Physical used with forecast', chart, 'wide')}
    ${card('Fastest-growing volumes', `${vTable}<p class="note">Per-volume history exists only for the largest volumes (collector option <code>--top-volumes</code>).</p>`, 'wide')}`;
}

// ---------------------------------------------------------------------------
// Performance
// ---------------------------------------------------------------------------

const firstField = (points, ...names) => names.find((n) => points.some((p) => typeof p[n] === 'number')) || names[0];

function perfView(points) {
  const f = (...n) => firstField(points, ...n);
  const bw = [
    { name: 'Total bandwidth', cls: 's-total', points: pts(points, f('avg_total_bandwidth', 'avg_bandwidth'), 1 / 1048576), area: true },
    { name: 'Read bandwidth', cls: 's-read', points: pts(points, 'avg_read_bandwidth', 1 / 1048576) },
    { name: 'Write bandwidth', cls: 's-write', points: pts(points, 'avg_write_bandwidth', 1 / 1048576) },
  ];
  const io = [
    { name: 'Total IOPS', cls: 's-total', points: pts(points, f('avg_total_iops', 'avg_iops')), area: true },
    { name: 'Read IOPS', cls: 's-read', points: pts(points, 'avg_read_iops') },
    { name: 'Write IOPS', cls: 's-write', points: pts(points, 'avg_write_iops') },
    { name: 'Peak total IOPS (bucket max)', cls: 's-peak', points: pts(points, f('max_total_iops', 'max_iops')), dash: true, mode: 'max' },
  ];
  const lat = [{ name: 'Latency', cls: 's-lat', points: pts(points, 'avg_latency', 1 / 1000) }];
  const lat3 = [
    { name: 'Average latency', cls: 's-lat', points: pts(points, 'avg_latency', 1 / 1000) },
    { name: 'Read latency', cls: 's-read', points: pts(points, 'avg_read_latency', 1 / 1000) },
    { name: 'Write latency', cls: 's-write', points: pts(points, 'avg_write_latency', 1 / 1000) },
  ];
  const dec = (step) => (step >= 1 ? 0 : Math.min(3, Math.ceil(-Math.log10(step))));
  const fmtMs = (v, st) => `${v.toFixed(dec(st))} ms`;
  const fmtMib = (v, st) => `${v.toFixed(dec(st))} MiB/s`;
  const fmtIo = (v, st) => (v >= 1000 ? `${(v / 1000).toFixed(st >= 1000 ? 0 : 1)}k` : v.toFixed(dec(st)));
  return switcher(
    [
      { label: 'Bandwidth', html: panel('Bandwidth', bw, { yFmt: fmtMib, height: 170 }) + panel('Latency', lat, { yFmt: fmtMs, height: 110 }) },
      { label: 'IOPS', html: panel('IOPS', io, { yFmt: fmtIo, height: 170 }) + panel('Latency', lat, { yFmt: fmtMs, height: 110 }) },
      { label: 'Latency', html: panel('Latency (read / write / average)', lat3, { yFmt: fmtMs, height: 200 }) },
    ],
    'pill small',
  );
}

function timelineSwitcher(tl) {
  const items = Object.entries(tl).map(([label, t]) => ({ label, html: `${perfView(t.points)}<p class="note">${esc(t.bucket)} buckets; lines are bucket averages, the dashed line is the largest sample maximum in each bucket.</p>` }));
  if (!items.length) return '<p class="empty">No performance samples in this bundle.</p>';
  const month = items.findIndex((i) => i.label === 'Last 1 month');
  return switcher(items, 'pill', month >= 0 ? month : 0);
}

function impactTables(model) {
  const S = model.storage;
  const inv = model.inventory;
  const peakOf = (perf) => perf && (perf.windows.One_Hour || perf.windows.One_Day || perf.windows.Five_Mins);
  const latestRow = (name, l, extra = '') => [esc(name), ms(l && l.latencyUs), kib(l && l.ioSize), kiops(l && l.iops), mibs(l && l.bandwidth), extra];
  const peakRow = (name, perf, extra = '') => {
    const w = peakOf(perf);
    return [esc(name), ms(w && w.worstAvgLatencyUs && w.worstAvgLatencyUs.value), w ? esc(w.bucket.label.split(' (')[0]) : 'n/a', kiops(w && w.peakIops && w.peakIops.value), mibs(w && w.peakBandwidth && w.peakBandwidth.value), extra];
  };
  const appPerf = new Map(model.performance.appliances.map((a) => [a.id, a]));
  const nodePerf = new Map(model.performance.nodes.map((n) => [n.id, n]));
  const nodeName = (n) => n.name || n.id;
  const apps = inv.appliances;
  const nodes = inv.nodes;
  const appName = new Map(apps.map((a) => [a.id, a.name]));

  const latestApp = table(['Appliance name', ['Latency'], ['I/O size'], ['IOPS'], ['Bandwidth'], ''], apps.map((a) => latestRow(a.name, S.latest.appliances[a.id])), { empty: 'No appliances.' });
  const latestNode = table(['Node name', ['Latency'], ['I/O size'], ['IOPS'], ['Bandwidth'], 'Appliance'], nodes.map((n) => latestRow(nodeName(n), S.latest.nodes[n.id], esc(appName.get(n.applianceId) || ''))), { empty: 'No nodes.' });
  const peakApp = table(['Appliance name', ['Worst avg latency'], 'Window', ['Peak IOPS'], ['Peak bandwidth'], ''], apps.map((a) => peakRow(a.name, appPerf.get(a.id))), { empty: 'No appliances.' });
  const peakNode = table(['Node name', ['Worst avg latency'], 'Window', ['Peak IOPS'], ['Peak bandwidth'], 'Appliance'], nodes.map((n) => peakRow(nodeName(n), nodePerf.get(n.id), esc(appName.get(n.applianceId) || ''))), { empty: 'No nodes.' });
  return switcher(
    [
      { label: 'Latest', html: `<h4>Appliances</h4>${latestApp}<h4>Nodes</h4>${latestNode}` },
      { label: 'Peak (last month)', html: `<h4>Appliances</h4>${peakApp}<h4>Nodes</h4>${peakNode}<p class="note">Worst avg latency is the highest bucket-average latency; peak IOPS and bandwidth are the largest sample maxima.</p>` },
    ],
    'pill',
  );
}

function peakSummary(model) {
  const perf = model.performance.cluster;
  const rows = ['Five_Mins', 'One_Hour', 'One_Day'].map((k) => perf.windows[k]).filter(Boolean).map((w) => [
    esc(w.bucket.label), `${esc(when(w.from))} to ${esc(when(w.to))}<br><small>${w.points} points</small>`,
    w.peakIops ? `${n2(w.peakIops.value, 1)} <small>@ ${esc(when(w.peakIops.at))}</small>` : 'n/a', `${n2(w.avgIops, 1)} <small>(p95 ${n2(w.p95AvgIops, 1)})</small>`,
    mibs(w.peakBandwidth && w.peakBandwidth.value), `${ms(w.avgLatencyUs)} <small>(worst ${ms(w.worstAvgLatencyUs && w.worstAvgLatencyUs.value)})</small>`, w.readShare == null ? 'n/a' : pct(w.readShare, 0),
  ]);
  return `${table(['Window', 'Range', ['Peak total IOPS'], ['Avg IOPS'], ['Peak bandwidth'], ['Avg latency'], ['Read share']], rows)}<p class="note">Times are bucket timestamps exactly as the array reports them; whether a timestamp marks the start or the end of its bucket is not confirmed, so a 1-day peak is only known to within that day. Where several windows report the same peak, the finest window is the best guide to when it happened.</p>`;
}

function performance(model) {
  const S = model.storage;
  const file = Object.keys(S.timeline.file).length ? card('File performance', timelineSwitcher(S.timeline.file) + '<p class="note">File-protocol metric field names are unvalidated; panels use whichever standard fields are present.</p>', 'wide') : '';
  return `<h2>Performance</h2>
    ${card('Overall performance', timelineSwitcher(S.timeline.cluster), 'wide')}
    ${file}
    ${card('Performance impact indicators', impactTables(model), 'wide')}
    ${card('Cluster peaks by window', peakSummary(model), 'wide')}`;
}

module.exports = { overview, signals, capacity, growth, performance, timelineSwitcher, tib, axisBytes };

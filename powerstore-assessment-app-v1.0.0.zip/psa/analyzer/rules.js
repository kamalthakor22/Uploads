'use strict';
// Signals for presales. These are conversation starters backed by evidence from
// the bundle, NOT recommendations: thresholds are starting points to be tuned
// after real customer runs (marked PROVISIONAL), and every finding carries the
// numbers it was derived from.

const THRESHOLDS = {
  // PROVISIONAL - tune against real customer arrays.
  capacityInfoPct: 0.7,
  capacityAttentionPct: 0.8,
  capacityActionPct: 0.9,
  daysToFullAttention: 365, // projected days until 80% physical used
  daysToFullAction: 180,
  forecastMinHistoryDays: 14,
  forecastMinR2: 0.8,
  enduranceAttentionPct: 50, // percent endurance remaining at or below
  enduranceActionPct: 20,
  unreducibleAttentionShare: 0.5,
  minLogicalUsedForEfficiency: 1024 ** 4, // 1 TiB; below this DRR figures are not meaningful
  unprotectedAttentionShare: 0.25, // share of primary volumes without a protection policy
  replicationStaleSeconds: 24 * 3600, // last sync older than this
  filesystemFullPct: 0.9,
};

const SEVERITY_ORDER = { action: 0, attention: 1, info: 2 };

const fmtBytes = (b) => {
  if (b == null) return 'n/a';
  const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
  let i = 0;
  let v = b;
  while (Math.abs(v) >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i === 0 ? 0 : 2)} ${u[i]}`;
};
const pct = (x, d = 1) => (x == null ? 'n/a' : `${(x * 100).toFixed(d)}%`);

function evaluate(model, t = THRESHOLDS) {
  const f = [];
  const add = (x) => f.push(x);
  const cap = model.capacity;
  const inv = model.inventory;

  // --- Capacity -----------------------------------------------------------
  if (cap && cap.derived.physicalUsedPct != null) {
    const p = cap.derived.physicalUsedPct;
    const evidence = { physicalUsed: fmtBytes(cap.latest.physicalUsed), physicalTotal: fmtBytes(cap.latest.physicalTotal), usedPct: pct(p) };
    if (p >= t.capacityActionPct) add({ id: 'capacity-high', severity: 'action', category: 'expansion', title: `Physical capacity ${pct(p, 0)} used`, detail: 'Above the action threshold: expansion or data movement needs planning now.', evidence });
    else if (p >= t.capacityAttentionPct) add({ id: 'capacity-high', severity: 'attention', category: 'expansion', title: `Physical capacity ${pct(p, 0)} used`, detail: 'Above the attention threshold: open a capacity-planning conversation.', evidence });
    else if (p >= t.capacityInfoPct) add({ id: 'capacity-watch', severity: 'info', category: 'expansion', title: `Physical capacity ${pct(p, 0)} used`, detail: 'Approaching the attention threshold.', evidence });
    else add({ id: 'capacity-ok', severity: 'info', category: 'expansion', title: `Physical capacity ${pct(p, 1)} used`, detail: 'Plenty of headroom today.', evidence });
  }

  // --- Growth forecast -----------------------------------------------------
  if (cap && cap.growth) {
    const g = cap.growth;
    const reliable = g.historyDays >= t.forecastMinHistoryDays && g.r2 >= t.forecastMinR2;
    const evidence = { historyDays: g.historyDays, growthPerDay: fmtBytes(g.bytesPerDay), r2: g.r2.toFixed(2), daysTo80pct: g.daysTo80 == null ? 'no growth' : Math.round(g.daysTo80) };
    if (!reliable) {
      add({ id: 'forecast-low-confidence', severity: 'info', category: 'data-quality', title: 'Capacity forecast has low confidence', detail: `Needs at least ${t.forecastMinHistoryDays} days of history and a good linear fit (R2 >= ${t.forecastMinR2}).`, evidence });
    } else if (g.daysTo80 != null && g.daysTo80 < t.daysToFullAction) {
      add({ id: 'forecast-soon', severity: 'action', category: 'expansion', title: `Projected to reach 80% in about ${Math.round(g.daysTo80)} days`, detail: 'Linear projection of physical used space.', evidence });
    } else if (g.daysTo80 != null && g.daysTo80 < t.daysToFullAttention) {
      add({ id: 'forecast-soon', severity: 'attention', category: 'expansion', title: `Projected to reach 80% in about ${Math.round(g.daysTo80)} days`, detail: 'Linear projection of physical used space.', evidence });
    }
  }

  // --- Drive wear / health --------------------------------------------------
  const worn = inv.drives.filter((d) => d.enduranceRemaining != null);
  if (worn.length) {
    const lowest = worn.reduce((a, d) => (d.enduranceRemaining < a.enduranceRemaining ? d : a));
    const evidence = { drivesMeasured: worn.length, lowestEnduranceRemaining: `${lowest.enduranceRemaining}%`, drive: lowest.name };
    if (lowest.enduranceRemaining <= t.enduranceActionPct) add({ id: 'drive-wear', severity: 'action', category: 'refresh', title: `Drive endurance down to ${lowest.enduranceRemaining}% remaining`, detail: 'Plan replacement or refresh.', evidence });
    else if (lowest.enduranceRemaining <= t.enduranceAttentionPct) add({ id: 'drive-wear', severity: 'attention', category: 'refresh', title: `Drive endurance down to ${lowest.enduranceRemaining}% remaining`, detail: 'Worth monitoring; refresh timing may be approaching.', evidence });
    else add({ id: 'drive-wear-ok', severity: 'info', category: 'refresh', title: `All ${worn.length} drives at or above ${Math.floor(lowest.enduranceRemaining)}% endurance remaining`, detail: 'No wear-driven refresh signal.', evidence });
  }
  if (inv.unhealthy.length) {
    add({ id: 'hardware-state', severity: 'attention', category: 'refresh', title: `${inv.unhealthy.length} hardware component(s) not Healthy`, detail: inv.unhealthy.slice(0, 5).map((u) => `${u.name} (${u.state})`).join('; '), evidence: { count: inv.unhealthy.length } });
  }

  // --- Efficiency ------------------------------------------------------------
  if (cap) {
    const L = cap.latest;
    if (L.logicalUsed == null || L.logicalUsed < t.minLogicalUsedForEfficiency) {
      add({ id: 'efficiency-too-little-data', severity: 'info', category: 'data-quality', title: 'Too little data to judge efficiency', detail: `Only ${fmtBytes(L.logicalUsed)} logical used (threshold ${fmtBytes(t.minLogicalUsedForEfficiency)}); DRR figures are not meaningful yet.`, evidence: { logicalUsed: fmtBytes(L.logicalUsed), overallDRR: L.overallDRR } });
    } else if (cap.derived.unreducibleShare != null && cap.derived.unreducibleShare >= t.unreducibleAttentionShare) {
      add({ id: 'unreducible-high', severity: 'attention', category: 'optimization', title: `${pct(cap.derived.unreducibleShare, 0)} of stored data is unreducible`, detail: 'Overall DRR is held down by data that cannot be reduced (for example already-compressed or encrypted data). Review the workload before treating low DRR as an array problem; check the terms of any DRR guarantee, which Dell documents as applying to reducible data.', evidence: { overallDRR: L.overallDRR, reducibleDRR: L.reducibleDRR, unreducible: fmtBytes(L.unreducibleData), dataPhysicalUsed: fmtBytes(L.dataPhysicalUsed) } });
    } else {
      add({ id: 'efficiency-ok', severity: 'info', category: 'optimization', title: `Overall DRR ${L.overallDRR?.toFixed(2)}:1 (reducible data ${L.reducibleDRR?.toFixed(2)}:1)`, detail: 'No efficiency signal.', evidence: { unreducibleShare: pct(cap.derived.unreducibleShare, 0) } });
    }
  }

  // --- Storage, protection, alerts, ports (v0.3 resources; field names unvalidated live) ----
  const st = model.storage;
  if (st) {
    const c = st.alerts.counts;
    if (st.have.alert && (c.Critical || c.Major || c.Minor)) {
      const evidence = { critical: c.Critical, major: c.Major, minor: c.Minor, unacknowledged: st.alerts.unacknowledged };
      if (c.Critical) add({ id: 'alerts-active', severity: 'action', category: 'health', title: `${c.Critical} critical alert(s) active`, detail: `Plus ${c.Major} major and ${c.Minor} minor. See the Alerts tab.`, evidence });
      else if (c.Major) add({ id: 'alerts-active', severity: 'attention', category: 'health', title: `${c.Major} major alert(s) active`, detail: `Plus ${c.Minor} minor. See the Alerts tab.`, evidence });
      else add({ id: 'alerts-active', severity: 'info', category: 'health', title: `${c.Minor} minor alert(s) active`, detail: 'See the Alerts tab.', evidence });
    }

    const vs = st.volumes.summary;
    const primaryCount = vs.primary;
    if (st.have.volume && primaryCount > 0 && vs.unprotected.length > 0) {
      const share = vs.unprotected.length / primaryCount;
      add({
        id: 'protection-gaps', severity: share >= t.unprotectedAttentionShare ? 'attention' : 'info', category: 'data-protection',
        title: `${vs.unprotected.length} of ${primaryCount} primary volumes have no protection policy`,
        detail: `Includes ${vs.unprotected.slice(0, 5).join(', ')}${vs.unprotected.length > 5 ? ', ...' : ''}. A data-protection conversation starter; some (test, scratch) may be intentional.`,
        evidence: { unprotectedShare: pct(share, 0), checkedVolumeGroupPolicies: st.volumes.rows.some((v) => v.volumeGroups.length > 0) },
      });
    }
    if (st.have.volume && vs.unmapped.length > 0) {
      add({ id: 'unmapped-volumes', severity: 'info', category: 'optimization', title: `${vs.unmapped.length} volume(s) have no host mapping`, detail: `${vs.unmapped.slice(0, 5).join(', ')}${vs.unmapped.length > 5 ? ', ...' : ''}: possible reclaim candidates (confirm before acting).`, evidence: { count: vs.unmapped.length } });
    }

    const sessions = st.protection.sessions;
    const bad = sessions.filter((x) => /(pause|fail|error|degrad|critical|unhealthy)/i.test(String(x.state)));
    if (bad.length) add({ id: 'replication-unhealthy', severity: 'attention', category: 'data-protection', title: `${bad.length} replication session(s) not in a healthy state`, detail: bad.slice(0, 5).map((x) => `${x.source} (${x.state})`).join('; '), evidence: { sessions: sessions.length } });
    const stale = sessions.filter((x) => x.lastSyncAgeSeconds != null && x.lastSyncAgeSeconds > t.replicationStaleSeconds);
    if (stale.length) add({ id: 'replication-stale', severity: 'attention', category: 'data-protection', title: `${stale.length} replication session(s) last synchronized more than ${Math.round(t.replicationStaleSeconds / 3600)} h before collection`, detail: stale.slice(0, 5).map((x) => `${x.source} (${Math.round(x.lastSyncAgeSeconds / 3600)} h)`).join('; '), evidence: {} });
    if (st.have.volume && st.have.replication_session && sessions.length === 0 && st.protection.remoteSystems.length === 0) {
      add({ id: 'no-replication', severity: 'info', category: 'data-protection', title: 'No replication sessions or remote systems configured', detail: 'Disaster-recovery posture is a possible conversation (confirm whether DR is handled elsewhere).', evidence: {} });
    }

    if (st.ports.downInUse.length) add({ id: 'ports-down', severity: 'attention', category: 'health', title: `${st.ports.downInUse.length} port(s) marked in use have no link`, detail: st.ports.downInUse.slice(0, 5).join('; '), evidence: { linkUp: st.ports.up, linkDown: st.ports.down } });

    const full = st.file.fileSystems.filter((f) => f.usedPct != null && f.usedPct >= t.filesystemFullPct);
    if (full.length) add({ id: 'filesystem-full', severity: 'attention', category: 'expansion', title: `${full.length} file system(s) at ${Math.round(t.filesystemFullPct * 100)}% or more of their size`, detail: full.slice(0, 5).map((f) => `${f.name} (${pct(f.usedPct, 0)})`).join('; '), evidence: {} });

    for (const a of model.inventory.appliances) {
      const cap2 = st.capacityByAppliance[a.id];
      if (cap2 && model.inventory.appliances.length > 1 && cap2.derived.physicalUsedPct >= t.capacityAttentionPct) {
        add({ id: 'appliance-capacity', severity: cap2.derived.physicalUsedPct >= t.capacityActionPct ? 'action' : 'attention', category: 'expansion', title: `Appliance ${a.name} physical capacity ${pct(cap2.derived.physicalUsedPct, 0)} used`, detail: 'Per-appliance capacity can hit limits before the cluster total does.', evidence: { appliance: a.name } });
      }
    }

    const L2 = cap && cap.latest;
    if (L2 && L2.logicalProvisioned != null && L2.physicalTotal != null && L2.logicalUsed >= t.minLogicalUsedForEfficiency && L2.overallDRR) {
      if (L2.logicalProvisioned > L2.physicalTotal * L2.overallDRR) {
        add({ id: 'thin-overcommit', severity: 'attention', category: 'expansion', title: 'Provisioned capacity exceeds physical capacity at the current DRR', detail: 'If volumes fill, the array could run out of physical space before hosts run out of logical space.', evidence: { logicalProvisioned: fmtBytes(L2.logicalProvisioned), physicalTotal: fmtBytes(L2.physicalTotal), overallDRR: L2.overallDRR } });
      }
    }

    const growers = st.volumeMetrics.filter((v) => v.growth && v.growth.bytesPerDay > 0).sort((a, b) => b.growth.bytesPerDay - a.growth.bytesPerDay).slice(0, 3);
    if (growers.length) add({ id: 'fastest-growing-volumes', severity: 'info', category: 'expansion', title: `Fastest-growing volume: ${growers[0].name} (+${fmtBytes(growers[0].growth.bytesPerDay)}/day logical)`, detail: growers.map((v) => `${v.name} +${fmtBytes(v.growth.bytesPerDay)}/day`).join('; '), evidence: { volumesWithHistory: st.volumeMetrics.length } });
  }

  // --- Data quality ----------------------------------------------------------
  for (const c of model.definitionChecks.filter((x) => !x.ok)) {
    add({ id: 'definition-drift', severity: 'attention', category: 'data-quality', title: `Metric relationship differs on this release: ${c.name}`, detail: `Expected ${c.formula} = ${c.expected.toFixed(3)} but the array reported ${c.reported}. Mappings validated on 4.4.0.0 may not hold here.`, evidence: { formula: c.formula } });
  }
  if (model.collection.warnings.length) {
    add({ id: 'collector-warnings', severity: 'attention', category: 'data-quality', title: `${model.collection.warnings.length} collector warning(s)`, detail: model.collection.warnings.slice(0, 5).join(' | '), evidence: {} });
  }
  if (model.collection.unavailable && model.collection.unavailable.length) {
    add({ id: 'resources-unavailable', severity: 'info', category: 'data-quality', title: `${model.collection.unavailable.length} optional resource(s) not offered by this release`, detail: model.collection.unavailable.slice(0, 8).map((u) => u.name).join(', '), evidence: {} });
  }
  if (model.collection.unsafeIntegers > 0) {
    add({ id: 'precision', severity: 'attention', category: 'data-quality', title: `${model.collection.unsafeIntegers} integer(s) exceeded 2^53 and were rounded`, detail: 'Byte counters above ~9 PB lose precision in this analyzer.', evidence: {} });
  }
  if (model.collection.tlsVerified === false) {
    add({ id: 'tls-unverified', severity: 'info', category: 'data-quality', title: 'Collected with TLS verification disabled', detail: 'Expected for arrays with self-signed certificates.', evidence: {} });
  }

  return f.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);
}

// PowerStore Manager shows a health score with five categories. Its score source is not exposed
// in the REST resources this tool reads, so this is the assessment's own view: each category is the
// worst severity among the signals that belong to it.
const HEALTH_MAP = {
  'System health': ['hardware-state', 'alerts-active', 'ports-down', 'drive-wear'],
  Configuration: ['unmapped-volumes', 'thin-overcommit', 'definition-drift', 'collector-warnings'],
  Capacity: ['capacity-high', 'forecast-soon', 'appliance-capacity', 'filesystem-full'],
  Performance: ['perf-latency'],
  'Data protection': ['protection-gaps', 'replication-unhealthy', 'replication-stale', 'no-replication'],
};

function healthChecklist(findings) {
  return Object.entries(HEALTH_MAP).map(([name, ids]) => {
    const hits = findings.filter((f) => ids.includes(f.id) && f.severity !== 'info');
    const worst = hits.some((f) => f.severity === 'action') ? 'action' : hits.length ? 'attention' : 'ok';
    return { name, status: worst, issues: hits.length };
  });
}

module.exports = { THRESHOLDS, evaluate, healthChecklist, fmtBytes, pct };

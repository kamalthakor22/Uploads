'use strict';
// Small HTML building blocks. Tabs and toggles are pure CSS (radio inputs), so the report
// needs no scripts and keeps working when scripts are stripped (mail gateways, viewers).

const { esc } = require('./format');

let uid = 0;
const MAX_TOGGLES = 14;

/** items: [{label, html}]. Returns a CSS-only switcher; the first item is selected. */
function switcher(items, cls = '', selected = 0) {
  const g = `sw${++uid}`;
  const shown = items.filter((i) => i && i.html != null);
  const sel = selected < shown.length ? selected : 0;
  const inputs = shown.map((_, k) => `<input type="radio" name="${g}" id="${g}-${k}"${k === sel ? ' checked' : ''}>`).join('');
  const labels = shown.map((it, k) => `<label for="${g}-${k}">${esc(it.label)}</label>`).join('');
  const panes = shown.map((it) => `<div class="pane">${it.html}</div>`).join('');
  return `<div class="sw ${cls}">${inputs}<div class="swbar">${labels}</div><div class="swpanes">${panes}</div></div>`;
}

/** CSS for every nth toggle position (generated, since selectors cannot be parameterized). */
function switcherCss() {
  const rules = ['.sw>input{position:absolute;opacity:0;pointer-events:none}', '.sw>.swpanes>.pane{display:none}'];
  for (let k = 1; k <= MAX_TOGGLES; k++) {
    rules.push(`.sw>input:nth-of-type(${k}):checked~.swpanes>.pane:nth-child(${k}){display:block}`);
    rules.push(`.sw>input:nth-of-type(${k}):checked~.swbar>label:nth-child(${k}){background:var(--accent);color:var(--accent-fg);border-color:var(--accent)}`);
    rules.push(`.sw>input:nth-of-type(${k}):focus-visible~.swbar>label:nth-child(${k}){outline:2px solid var(--fg);outline-offset:1px}`);
  }
  return rules.join('\n');
}

/** head: strings, or [text,'r'] for right-aligned numeric columns. rows: arrays of HTML strings. */
function table(head, rows, { empty = 'Nothing to show.', max = 500 } = {}) {
  if (!rows.length) return `<p class="empty">${esc(empty)}</p>`;
  const h = head.map((c) => (Array.isArray(c) ? `<th class="r">${esc(c[0])}</th>` : `<th>${esc(c)}</th>`));
  const right = head.map((c) => Array.isArray(c));
  const body = rows.slice(0, max).map((r) => `<tr>${r.map((c, i) => `<td${right[i] ? ' class="r"' : ''}>${c}</td>`).join('')}</tr>`).join('');
  const more = rows.length > max ? `<p class="note">Showing the first ${max} of ${rows.length} rows; the rest are in the bundle.</p>` : '';
  return `<div class="tw"><table><thead><tr>${h.join('')}</tr></thead><tbody>${body}</tbody></table></div>${more}`;
}

const bar = (frac, cls = '') => (frac == null ? '&ndash;' : `<span class="bar ${cls}"><i style="width:${Math.max(0, Math.min(1, frac)) * 100}%"></i></span>`);
const status = (kind, text) => `<span class="st st-${kind}"><b aria-hidden="true">${{ ok: '&#10003;', warn: '&#9888;', bad: '&#10006;', info: '&#8505;' }[kind] || ''}</b> ${esc(text)}</span>`;
const card = (title, inner, cls = '') => `<section class="card ${cls}"><h3>${esc(title)}</h3>${inner}</section>`;
const stat = (value, label, cls = '') => `<div class="stat ${cls}"><b>${value}</b><span>${esc(label)}</span></div>`;
const na = (what) => `<p class="empty">${esc(what)} was not collected in this bundle (the resource was unavailable, skipped, or the bundle predates this version).</p>`;

module.exports = { switcher, switcherCss, table, bar, status, card, stat, na };

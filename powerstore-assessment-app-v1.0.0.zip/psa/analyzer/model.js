'use strict';
// Builds the full analysis model from a parsed bundle: the validated core
// (inventory, capacity, performance; normalize.js) plus storage objects,
// protection, alerts, ports, growth and chart timelines (storage.js).

const { normalize } = require('./normalize');
const { buildStorageModel } = require('./storage');

function buildModel(bundle, opts = {}) {
  const model = normalize(bundle, opts);
  model.storage = buildStorageModel(bundle, model.inventory);
  // Resources the bundle did not (or could not) collect, for the Collection tab.
  model.collection.coverage = bundle.coverage || [];
  model.collection.unavailable = bundle.unavailable || [];
  model.collection.skipped = bundle.skipped_resources || [];
  model.collection.schemaVersion = bundle.schema_version;
  return model;
}

/** JSON-safe export (drops the bulky chart timelines). */
function exportable(model, findings) {
  return JSON.stringify({ model, findings }, (k, v) => (k === 'timeline' ? undefined : v), 2);
}

module.exports = { buildModel, exportable };

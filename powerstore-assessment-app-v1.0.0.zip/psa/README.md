# PowerStore Assessment (web app) v1.0.0

Teknicor presales tool. One page, three jobs:

1. **Download the collector** (Windows .exe, Linux binary, or the Node.js source) and run it against a PowerStore.
2. **Upload the collector output**, type the customer name, click **Generate report**: the 12-dashboard assessment appears on the same page.
3. **Reports by customer**: every upload is kept in SQLite, with the collector output and the report, per customer.

Stack: Node.js + Express, SQLite via the built-in `node:sqlite`, plain HTML/CSS/JS front end, no build step. Same look as QuoteDelta and Quote Summary (blue bar with the Teknicor logo and app name, cards, no sidebar).

## Install and run (Windows Server VM, Node v24 or any Node 22.13+)

    cd powerstore-assessment-app
    npm install
    copy .env.example .env          (optional; every setting has a default)
    npm start                       -> http://<hostname>:3015

Default port 3015 (QuoteDelta uses 3005, Quote Summary 3006, Bookmarks Hub 3010: change `PORT` if 3015 is taken).
Allow the port in Windows Firewall to reach it from other machines. All page URLs are relative, so the app also works behind a path-based reverse proxy.

### The Teknicor logo
No logo file is included. Copy `teknicor-logo.png` from the `public/img` folder of QuoteDelta or Quote Summary into `public/img/`, or set `LOGO_URL` in `.env`, or run
`npm run fetch-logo -- <logo-image-url>` on a machine with internet access. Until then the blue bar shows the word TEKNICOR. The bar color is `--bar` in `public/css/theme.css`; set it to the exact blue of the other tools if it differs.

### Settings (.env)
| Setting | Default | Meaning |
|---|---|---|
| `PORT` | 3015 | listen port |
| `DB_PATH` | `./data/assessments.sqlite` | database file (created on first start) |
| `DOWNLOADS_DIR` | `./downloads` | collector files offered for download |
| `MAX_UPLOAD_MB` | 200 | largest upload accepted |
| `ADMIN_PIN` | empty | if set, deleting a report or renaming a customer asks for it (empty = no PIN, like QuoteDelta) |
| `LOGO_URL` | empty | logo URL instead of `public/img/teknicor-logo.png` |
| `PORTAL_URL` | empty | adds a "Tools Portal" link in the blue bar |

## Collector downloads
`downloads/` holds `pstore-assess-win-x64.exe` and `pstore-assess-linux-x64` (collector 0.3.0-dev, unsigned, 55 and 71 MB; they embed Node). The Node.js source zip is built on request from `collector/`. To update the binaries, build them in the collector project (`npm run build`) and copy the files over; the page shows each file's size and SHA-256 and counts downloads. A missing file shows as "Not available" with the reason.

## What is stored
Database `data/assessments.sqlite`:
- `customers`: name (unique, case-insensitive).
- `reports`: one row per customer and collector output: customer, upload time, optional note, original file name, SHA-256 of the output, collector and analyzer versions, cluster, model, service tag, PowerStoreOS, collection time, signal counts, **the collector output (gzip)** and **the generated report (gzip)**.
- `download_log`: which collector file was downloaded and when.

Uploading the same output again for the same customer is detected (by SHA-256) and shows the stored report instead of adding a row. A different customer can use the same file. **Regenerate** rebuilds a report from the stored output with the analyzer built into the server, so improvements to the analyzer apply to old uploads. The database holds customer infrastructure details (names, IPs, service tags): keep `data/` on a protected volume and back it up (copy the `.sqlite` file while the app is stopped).

Accepted uploads: the collector's `.json`, the `.zip` it writes with `--zip` (or a Windows "Send to compressed folder" zip containing the .json), or a `.gz`.

## Security notes
- No sign-in, like QuoteDelta. Anyone who can reach the page can upload and view reports. Set `ADMIN_PIN` to protect deleting and renaming.
- Reports are served with a policy that blocks scripts, and are shown in a sandboxed frame. All names from uploaded data are HTML-escaped.
- The collector itself is read-only (GET and the metrics query only).

## Updating the analyzer
`analyzer/` is a copy of the analyzer from the collector project (v0.3.0); `collector/` is a copy of the collector source used for the source download. After changing either project, copy the folders over and restart.

## Tests
    npm test        (12 tests: upload, zip/gzip, duplicates, errors, regenerate, PIN, search, downloads, page)

## Layout
    server.js  src/ (config, db, app, reports, bundle-input, downloads, zipmulti)
    public/ (index.html, css/theme.css, css/app.css, js/app.js, img/)
    analyzer/  collector/  downloads/  data/  test/  scripts/
